param([string]$Task = 'build', [switch]$SmokeTest, [switch]$LocalVisualTest)
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$env:JAVA_HOME = (Get-ChildItem -LiteralPath (Join-Path $taskRoot 'tools') -Directory -Filter 'jdk-17*' | Select-Object -First 1).FullName
if (-not $env:JAVA_HOME) { throw 'Missing JDK 17 in tools.' }
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$env:GRADLE_USER_HOME = Join-Path $taskRoot '.gradle-cache'
$env:TEMP = Join-Path $taskRoot '.tmp'
$env:TMP = $env:TEMP
$env:JAVA_TOOL_OPTIONS = '-Duser.home="' + (Join-Path $taskRoot '.home') + '" -Djava.io.tmpdir="' + $env:TEMP + '"'
New-Item -ItemType Directory -Force -Path (Join-Path $taskRoot '.home') | Out-Null
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
Push-Location (Join-Path $taskRoot 'flame-talisman')
try {
    $taskArgs = @($Task, '--no-daemon', '--console=plain')
    if ($Task -eq 'runGameTestServer') { $taskArgs += @('-x', 'downloadAssets') }
    if ($SmokeTest) { $taskArgs += '-PflameSmoke=true' }
    if ($LocalVisualTest) { $taskArgs += '-PlocalVisualTest=true' }
    & (Join-Path $taskRoot 'tools/gradle-8.8/bin/gradle.bat') @taskArgs
    if ($LASTEXITCODE -ne 0) { throw "Gradle failed: $LASTEXITCODE" }
} finally { Pop-Location }
