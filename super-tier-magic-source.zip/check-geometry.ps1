$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$jdk = (Get-ChildItem -LiteralPath "$taskRoot/tools" -Directory -Filter 'jdk-17*' | Select-Object -First 1).FullName
$output = Join-Path $taskRoot 'downloads/check-classes'
New-Item -ItemType Directory -Force -Path $output | Out-Null
$env:TEMP = Join-Path $taskRoot '.tmp'; $env:TMP = $env:TEMP
& "$jdk/bin/javac.exe" -d $output "$taskRoot/flame-talisman/src/main/java/dev/flametalisman/SpellGeometry.java" "$taskRoot/flame-talisman/src/main/java/dev/flametalisman/BladeMath.java" "$taskRoot/flame-talisman/checks/SpellGeometryChecks.java"
if ($LASTEXITCODE -ne 0) { throw 'Check compilation failed' }
& "$jdk/bin/java.exe" "-Djava.io.tmpdir=$env:TEMP" -cp $output SpellGeometryChecks
if ($LASTEXITCODE -ne 0) { throw 'Geometry check failed' }
