$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$bitmap=[System.Drawing.Bitmap]::new(32,32)
function Pixel([int]$x,[int]$y,[string]$color){if($x -ge 0 -and $x -lt 32 -and $y -ge 0 -and $y -lt 32){$bitmap.SetPixel($x,$y,[System.Drawing.ColorTranslator]::FromHtml($color))}}
# A white shulker-like folded shell, open just enough to show its glowing core.
for($y=6;$y -le 12;$y++){for($x=5;$x -le 26;$x++){
    if(($y -eq 6 -or $y -eq 12)-and($x -lt 7 -or $x -gt 24)){continue}
    $color=if($y -eq 6 -or $x -eq 5 -or $x -eq 26){'#9FA9B3'}elseif($y -eq 7 -or $x -eq 6){'#FFFFFF'}elseif($y -eq 12){'#BDC7D1'}else{'#E5EDF3'}
    Pixel $x $y $color
}}
for($y=20;$y -le 27;$y++){for($x=5;$x -le 26;$x++){
    if($y -eq 27-and($x -lt 7-or$x -gt 24)){continue}
    $color=if($x -eq 5-or$x -eq 26-or$y -eq 27){'#929EA9'}elseif($y -eq 20-or$x -eq 6){'#F9FCFF'}elseif($y -gt 24){'#C0CCD6'}else{'#DFE8F0'}
    Pixel $x $y $color
}}
for($y=13;$y -le 20;$y++){for($x=11;$x -le 20;$x++){if(($y -eq 13-or$y -eq 20)-and($x -lt 13-or$x -gt 18)){continue};Pixel $x $y '#F4F9FF'}}
foreach($x in @(13,18)){Pixel $x 16 '#566D80';Pixel $x 17 '#728B9F';Pixel ($x+1) 16 '#C6E5F5'}
foreach($line in @(@(9,8,13),@(18,9,23),@(8,23,12),@(17,25,23))){for($x=$line[0];$x -le $line[2];$x++){Pixel $x $line[1] '#B1C2CF'}}
$asset=Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/assets/flametalisman/textures/item/air_talisman.png'
$bitmap.Save($asset,[System.Drawing.Imaging.ImageFormat]::Png)
$preview=[System.Drawing.Bitmap]::new(320,320);$g=[System.Drawing.Graphics]::FromImage($preview);$g.Clear([System.Drawing.Color]::FromArgb(255,49,58,72));$g.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor;$g.PixelOffsetMode=[System.Drawing.Drawing2D.PixelOffsetMode]::Half;$g.DrawImage($bitmap,0,0,320,320)
$preview.Save((Join-Path $PSScriptRoot 'release/air-talisman-preview.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$preview.Dispose();$bitmap.Dispose()
