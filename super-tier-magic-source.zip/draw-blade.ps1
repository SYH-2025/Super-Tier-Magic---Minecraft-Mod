$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$asset = Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/assets/flametalisman/textures/item'
$blade = [System.Drawing.Bitmap]::new(32,32)
function BladePixel([int]$x,[int]$y,[string]$hex) {
    if($x -ge 0 -and $x -lt 32 -and $y -ge 0 -and $y -lt 32) {
        $blade.SetPixel($x,$y,[System.Drawing.ColorTranslator]::FromHtml($hex))
    }
}
# Minecraft-style stepped diagonal blade: dark outline, golden bevel, pale hot edge.
for($t=0;$t -le 18;$t++) {
    $x=10+$t; $y=22-$t
    $curve=if($t -gt 12){1}else{0}
    for($w=-2;$w -le 2;$w++) {
        $color= switch($w) { -2 {'#6B3115'} -1 {'#D47717'} 0 {'#F7B62F'} 1 {'#FFE36B'} 2 {'#FFF8D7'} }
        BladePixel ($x+$curve) ($y+$w) $color
    }
    if($t -gt 7 -and $t%4 -eq 0) { BladePixel ($x-1+$curve) ($y-3) '#DE6211'; BladePixel ($x+$curve) ($y-4) '#FFCE41' }
}
BladePixel 29 2 '#FFF8D7'; BladePixel 30 1 '#FFE36B'; BladePixel 30 2 '#6B3115'
# Guard, charcoal grip with gold bindings, diamond-inlaid pommel.
for($i=0;$i -le 9;$i++) {
    BladePixel (6+$i) (17+$i) '#6B3115'; BladePixel (6+$i) (18+$i) '#D18A1D'; BladePixel (6+$i) (19+$i) '#FFE47B'
}
for($t=0;$t -le 7;$t++) {
    $x=10-$t; $y=23+$t
    BladePixel ($x-1) $y '#251B18'; BladePixel $x $y '#5B3020'; BladePixel ($x+1) $y '#251B18'
    if($t%2 -eq 0) { BladePixel $x $y '#EEB437' }
}
BladePixel 2 29 '#193D40'; BladePixel 3 29 '#46D8C6'; BladePixel 2 30 '#9EFFF0'; BladePixel 3 30 '#1A7374'
$blade.Save((Join-Path $asset 'flame_blade.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$preview=[System.Drawing.Bitmap]::new(320,320)
$g=[System.Drawing.Graphics]::FromImage($preview)
$g.Clear([System.Drawing.Color]::FromArgb(27,23,22))
$g.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode=[System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($blade,0,0,320,320)
$preview.Save((Join-Path $PSScriptRoot 'release/blade-preview.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$preview.Dispose();$blade.Dispose()
