$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$asset=Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/assets/flametalisman/textures/item'
function Px($bmp,[int]$x,[int]$y,[string]$color) { if($x -ge 0 -and $x -lt 32 -and $y -ge 0 -and $y -lt 32){$bmp.SetPixel($x,$y,[System.Drawing.ColorTranslator]::FromHtml($color))} }
$shard=[System.Drawing.Bitmap]::new(32,32)
$g=[System.Drawing.Graphics]::FromImage($shard)
# Upright lightning bolt: vertical silhouette, pointed ends, one angular central notch.
$bolt=[System.Drawing.Point[]]@([System.Drawing.Point]::new(16,2),[System.Drawing.Point]::new(23,2),[System.Drawing.Point]::new(17,13),[System.Drawing.Point]::new(23,13),[System.Drawing.Point]::new(12,30),[System.Drawing.Point]::new(15,18),[System.Drawing.Point]::new(9,18))
$fill=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#65DFFF'))
$g.FillPolygon($fill,$bolt);$fill.Dispose()
$core=[System.Drawing.Point[]]@([System.Drawing.Point]::new(18,4),[System.Drawing.Point]::new(20,4),[System.Drawing.Point]::new(14,15),[System.Drawing.Point]::new(20,15),[System.Drawing.Point]::new(15,24),[System.Drawing.Point]::new(17,16),[System.Drawing.Point]::new(12,16))
$fill=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#F0FCFF'))
$g.FillPolygon($fill,$core);$fill.Dispose();$g.Dispose()
$shard.Save((Join-Path $asset 'lightning_shard.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$paper=[System.Drawing.Bitmap]::new(32,32)
for($y=3;$y -le 28;$y++){for($x=8;$x -le 23;$x++){
    if(($y -eq 3 -and $x -gt 20)-or($y -eq 28 -and $x -lt 10)){continue}
    $color=if($x -eq 8 -or $x -eq 23 -or $y -eq 3 -or $y -eq 28){'#233C76'}elseif($x -eq 9 -or $y -eq 4){'#EDFAFF'}elseif($x -ge 21){'#7B99CF'}else{'#B2CEE9'}
    Px $paper $x $y $color
}}
for($y=6;$y -le 25;$y++){Px $paper 11 $y '#687AB3';Px $paper 20 $y '#687AB3'}
for($x=11;$x -le 20;$x++){Px $paper $x 6 '#687AB3';Px $paper $x 25 '#687AB3'}
foreach($p in @(@(17,8),@(18,8),@(16,9),@(17,9),@(15,10),@(16,10),@(14,11),@(15,11),@(14,12),@(15,12),@(16,12),@(17,12),@(18,12),@(17,13),@(16,14),@(15,15),@(14,16),@(13,17),@(14,17),@(15,17),@(16,17),@(15,18),@(14,19),@(13,20))){Px $paper $p[0] $p[1] '#2461B2'}
for($x=14;$x -le 17;$x++){Px $paper $x 22 '#6748A0';Px $paper $x 24 '#6748A0'}
Px $paper 14 23 '#6748A0';Px $paper 17 23 '#6748A0';Px $paper 15 23 '#ECFAFF';Px $paper 16 23 '#ECFAFF'
$paper.Save((Join-Path $asset 'lightning_talisman.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$sword=[System.Drawing.Bitmap]::new(32,32)
for($t=0;$t -le 19;$t++){
    $x=9+$t;$y=23-$t
    for($w=-2;$w -le 2;$w++){
        $color=switch($w){-2{'#222237'}-1{'#535C91'}0{'#7FD6F8'}1{'#DBF9FF'}2{'#FFFFFF'}}
        Px $sword $x ($y+$w) $color
    }
    if($t%4 -eq 1){Px $sword ($x-1) ($y-3) '#5B8CD6';Px $sword $x ($y-4) '#B5F7FF'}
}
Px $sword 29 2 '#DBF9FF';Px $sword 30 1 '#FFFFFF'
for($i=0;$i -le 9;$i++){Px $sword (5+$i) (18+$i) '#241E39';Px $sword (5+$i) (19+$i) '#76548E';Px $sword (5+$i) (20+$i) '#B8AAE4'}
for($t=0;$t -le 7;$t++){$x=9-$t;$y=24+$t;Px $sword ($x-1) $y '#171621';Px $sword $x $y '#3B3155';Px $sword ($x+1) $y '#171621';if($t%2 -eq 0){Px $sword $x $y '#9BDFF2'}}
Px $sword 2 29 '#B8AAE4';Px $sword 3 29 '#EEFBFF';Px $sword 2 30 '#FFFFFF';Px $sword 3 30 '#B8AAE4'
$sword.Save((Join-Path $asset 'thunderclap_blade.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$preview=[System.Drawing.Bitmap]::new(960,320);$g=[System.Drawing.Graphics]::FromImage($preview);$g.Clear([System.Drawing.Color]::FromArgb(20,24,34));$g.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor;$g.PixelOffsetMode=[System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($shard,0,0,320,320);$g.DrawImage($paper,320,0,320,320);$g.DrawImage($sword,640,0,320,320)
$preview.Save((Join-Path $PSScriptRoot 'release/lightning-items-preview.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$preview.Dispose();$shard.Dispose();$paper.Dispose();$sword.Dispose()
