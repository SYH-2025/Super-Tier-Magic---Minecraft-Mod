$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$atlas=[System.Drawing.Bitmap]::new(2048,1024)
$g=[System.Drawing.Graphics]::FromImage($atlas)
$g.TextRenderingHint=[System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$font=[System.Drawing.Font]::new('博洋草体一',92,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$fallbackFonts=@('博洋行书','华文行楷') | ForEach-Object { [System.Drawing.Font]::new($_,92,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel) }
$format=[System.Drawing.StringFormat]::new()
$format.Alignment=[System.Drawing.StringAlignment]::Center
$format.LineAlignment=[System.Drawing.StringAlignment]::Center
$glyphs='锋刃剑锋芒光寒冷霜雪冰风雷电火炎焰光影暗夜月星云天穹空虚灵魂魄神心意念志气血骨脉魂魄道法术诀印阵符咒斩劈刺挑削掠扫崩穿透断裂破碎灭绝封镇御守护引聚凝散化生转回御龙凤虎狼鹰鹤蛇麟鹏鲲尘尘烟雾潮浪潮潮潮潮'
for($i=0;$i -lt $glyphs.Length;$i++){
    $rect=[System.Drawing.RectangleF]::new(($i%16)*128,[Math]::Floor($i/16)*128,128,128)
    $hasInk=$false
    foreach($drawFont in (@($font)+$fallbackFonts)){
        $g.DrawString($glyphs[$i].ToString(),$drawFont,[System.Drawing.Brushes]::White,$rect,$format)
        $g.Flush()
        for($x=[int]$rect.X+4;$x -lt $rect.Right -and !$hasInk;$x+=4){
            for($y=[int]$rect.Y+4;$y -lt $rect.Bottom;$y+=4){
                if($atlas.GetPixel($x,$y).A -gt 0){$hasInk=$true;break}
            }
        }
        if($hasInk){break}
    }
    if(!$hasInk){throw "Missing calligraphy glyph: $($glyphs[$i])"}
}
$target=Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/assets/flametalisman/textures/effect'
New-Item -ItemType Directory -Force -Path $target | Out-Null
$atlas.Save((Join-Path $target 'sword_calligraphy.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$font.Dispose();$format.Dispose();$atlas.Dispose()
foreach($fallbackFont in $fallbackFonts){$fallbackFont.Dispose()}
