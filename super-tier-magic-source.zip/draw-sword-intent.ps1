$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$asset=Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/assets/flametalisman/textures'
$sword=[System.Drawing.Bitmap]::new(32,32)
function Pixel($bmp,$x,$y,$alpha,$r,$g,$b){if($x -ge 0 -and $x -lt $bmp.Width -and $y -ge 0 -and $y -lt $bmp.Height){$bmp.SetPixel($x,$y,[System.Drawing.Color]::FromArgb($alpha,$r,$g,$b))}}
# Broad white blade with translucent silver edges.
for($t=0;$t -le 18;$t++){
    $x=10+$t;$y=22-$t
    Pixel $sword $x ($y-3) 85 232 232 232
    Pixel $sword $x ($y-2) 130 245 245 245
    Pixel $sword $x ($y-1) 165 250 250 250
    Pixel $sword $x $y 195 255 255 255
    Pixel $sword $x ($y+1) 165 250 250 250
    Pixel $sword $x ($y+2) 130 245 245 245
    Pixel $sword $x ($y+3) 85 232 232 232
}
Pixel $sword 29 2 210 216 246 255
Pixel $sword 30 1 240 246 255 255
# Symmetric crossguard and a short translucent grip.
for($i=0;$i -le 10;$i++){
    Pixel $sword (5+$i) (17+$i) 130 130 194 232
    Pixel $sword (5+$i) (18+$i) 215 222 246 255
    Pixel $sword (5+$i) (19+$i) 155 160 211 249
}
for($t=0;$t -le 6;$t++){
    Pixel $sword (8-$t) (24+$t) 195 159 211 248
    Pixel $sword (9-$t) (24+$t) 225 229 247 255
    Pixel $sword (10-$t) (24+$t) 130 118 180 230
}
Pixel $sword 2 30 230 229 248 255
Pixel $sword 3 31 210 190 230 255
for($yy=0;$yy -lt 32;$yy++){for($xx=0;$xx -lt 32;$xx++){$old=$sword.GetPixel($xx,$yy);if($old.A -gt 0){$white=[Math]::Max($old.R,[Math]::Max($old.G,$old.B));$sword.SetPixel($xx,$yy,[System.Drawing.Color]::FromArgb([Math]::Min(195,[int]$old.A),$white,$white,$white))}}}
$sword.Save((Join-Path $asset 'item/sword_intent.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$icon=[System.Drawing.Bitmap]::new(18,18)
for($t=0;$t -le 10;$t++){
    Pixel $icon (5+$t) (12-$t) 255 255 214 110
    Pixel $icon (5+$t) (13-$t) 255 225 241 255
}
for($t=0;$t -le 6;$t++){Pixel $icon (3+$t) (9+$t) 255 223 236 255}
for($t=0;$t -le 3;$t++){Pixel $icon (4-$t) (13+$t) 255 253 224 155}
New-Item -ItemType Directory -Force -Path (Join-Path $asset 'mob_effect') | Out-Null
$icon.Save((Join-Path $asset 'mob_effect/sword_qi.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$preview=[System.Drawing.Bitmap]::new(320,320)
$graphics=[System.Drawing.Graphics]::FromImage($preview)
$graphics.Clear([System.Drawing.Color]::FromArgb(255,49,58,72))
$graphics.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$graphics.PixelOffsetMode=[System.Drawing.Drawing2D.PixelOffsetMode]::Half
$graphics.DrawImage($sword,0,0,320,320)
$preview.Save((Join-Path $PSScriptRoot 'release/sword-intent-preview.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$graphics.Dispose();$preview.Dispose();$sword.Dispose();$icon.Dispose()
