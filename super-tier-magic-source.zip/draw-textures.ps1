$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$assetRoot = Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/assets/flametalisman/textures'
New-Item -ItemType Directory -Force -Path "$assetRoot/item","$assetRoot/particle" | Out-Null
$paper = New-Object System.Drawing.Bitmap 32,32
function Pixel([int]$x,[int]$y,[string]$color) {
    $paper.SetPixel($x,$y,[System.Drawing.ColorTranslator]::FromHtml($color))
}
# Pixel-painted parchment, dark gold border, folded corner and vermilion seal.
for ($y=3; $y -le 28; $y++) {
    for ($x=8; $x -le 23; $x++) {
        if (($y -eq 3 -and $x -gt 20) -or ($y -eq 28 -and $x -lt 10)) { continue }
        $edge = $x -eq 8 -or $x -eq 23 -or $y -eq 3 -or $y -eq 28
        $shade = if ($edge) { '#9C641B' } elseif ($x -eq 9 -or $y -eq 4) { '#FFF3AD' } elseif ($x -ge 21) { '#D9A93B' } else { '#F3D36A' }
        Pixel $x $y $shade
    }
}
for ($y=6;$y -le 25;$y++) { Pixel 11 $y '#C88A24'; Pixel 20 $y '#C88A24' }
for ($x=11;$x -le 20;$x++) { Pixel $x 6 '#B77A20'; Pixel $x 25 '#B77A20' }
Pixel 21 4 '#FFF7C9'; Pixel 22 5 '#FFF7C9'; Pixel 22 4 '#B57E28'
$strokes = @(
 @(15,7),@(16,7),@(14,8),@(17,8),@(15,9),@(16,9),
 @(13,11),@(14,11),@(15,11),@(16,11),@(17,11),@(18,11),
 @(15,12),@(16,12),@(14,13),@(15,13),@(17,13),@(18,13),
 @(13,14),@(16,14),@(17,14),@(15,15),@(16,15),
 @(13,16),@(14,16),@(15,16),@(16,16),@(17,16),@(18,16),
 @(15,17),@(17,17),@(14,18),@(15,18),@(16,18),@(17,18),
 @(13,19),@(16,19),@(18,19),@(15,20),@(16,20),@(17,20)
)
foreach ($point in $strokes) { Pixel $point[0] $point[1] '#A6520F' }
for ($y=22;$y -le 24;$y++) { for($x=14;$x -le 17;$x++) { Pixel $x $y '#B73C16' } }
Pixel 15 23 '#FFDE75'; Pixel 16 23 '#FFDE75'
$paper.Save("$assetRoot/item/flame_talisman.png",[System.Drawing.Imaging.ImageFormat]::Png)
# Original flame sprite: tapered split tip, amber edge, white-gold core.
$flame = New-Object System.Drawing.Bitmap 16,16
for ($y=1;$y -le 14;$y++) {
    $width = if($y -lt 6) { [Math]::Max(1,[int]($y/2)) } elseif($y -lt 11) { 5 } else { [Math]::Max(1,14-$y) }
    $center = if($y -lt 6) { 8 + [int]([Math]::Sin($y)*2) } else { 8 }
    for($x=$center-$width;$x -le $center+$width;$x++) {
        if($x -lt 0 -or $x -ge 16) { continue }
        $dist = [Math]::Abs($x-$center)
        $color = if($dist -le 1 -and $y -ge 7) {'#FFFFE5'} elseif($dist -lt $width) {'#FFE66A'} else {'#FBC02A'}
        $flame.SetPixel($x,$y,[System.Drawing.ColorTranslator]::FromHtml($color))
    }
}
$flame.Save("$assetRoot/particle/gold_flame.png",[System.Drawing.Imaging.ImageFormat]::Png)
$preview = New-Object System.Drawing.Bitmap 320,320
$g = [System.Drawing.Graphics]::FromImage($preview)
$g.Clear([System.Drawing.Color]::FromArgb(32,26,20))
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($paper,0,0,320,320)
$preview.Save((Join-Path $PSScriptRoot 'downloads/talisman-preview.png'),[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $preview.Dispose(); $paper.Dispose(); $flame.Dispose()
