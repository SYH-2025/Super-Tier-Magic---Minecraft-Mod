import dev.flametalisman.AirGeometry;
import dev.flametalisman.SwordPercentageMath;
public final class AirAndSwordChecks {
    private static int checks;
    private static void check(boolean pass,String label){checks++;if(!pass)throw new AssertionError(label);}
    public static void main(String[]args){
        for(double start:new double[]{0,1,16,32,63.99,64}){
            double previous=start;
            for(int age=0;age<=8;age++){double r=AirGeometry.pushRadius(start,age);check(r>=previous-1e-8,"outward-only push");previous=r;}
            check(AirGeometry.pushRadius(start,8)>64,"every subject ends beyond 64");
            check(Math.abs(AirGeometry.vortexRadius(start,40)-1.6)<1e-8,"all subjects converge on same hold radius");
        }
        check(AirGeometry.progress(-1,40)==0,"no negative ascent progress");check(AirGeometry.progress(100,40)==1,"completed ascent remains clamped");
        double[]strength={0,.2,.6,1},percent={.05,.06,.08,.10};
        for(int i=0;i<4;i++)check(Math.abs(SwordPercentageMath.amount(1000,.05,.10,strength[i])-1000*percent[i])<.001,"percentage at skill "+i);
        for(int level=0;level<5;level++)check(Math.abs(SwordPercentageMath.amount(1000,.05,.10,level/4.0)-(50+12.5*level))<.001,"Sword Qi percentage at level "+level);
        check(SwordPercentageMath.amount(100,.1,.05,1)==10,"reversed config range clamps safely");check(SwordPercentageMath.amount(100,0,0,1)==0,"percentage disable by config");
        System.out.println("PASS: "+checks+" production air and sword percentage checks; no game launched.");
    }
}
