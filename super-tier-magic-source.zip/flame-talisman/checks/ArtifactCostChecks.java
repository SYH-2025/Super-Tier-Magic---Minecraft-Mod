import dev.flametalisman.ArtifactCostMath;
public final class ArtifactCostChecks {
    private static int count;
    private static void check(boolean result,String name){count++;if(!result)throw new AssertionError(name);}
    public static void main(String[]args){
        int[]levels={0,25,50,75,100,150};double[]expected={1,.75,.5,.25,0,0};
        for(int i=0;i<levels.length;i++){
            double factor=ArtifactCostMath.factor(levels[i],100);
            check(Math.abs(factor-expected[i])<1e-9,"linear factor at "+levels[i]);
            check(Math.abs(ArtifactCostMath.healthFloor(20,.8,factor)-(20-16*expected[i]))<1e-5,"health floor at "+levels[i]);
            double total=0;for(int j=0;j<10000;j++)total+=ArtifactCostMath.rounded(1*factor,(j+.5)/10000.0);
            check(Math.abs(total/10000-factor)<1e-5,"fractional one-point durability at "+levels[i]);
        }
        check(ArtifactCostMath.factor(-1,100)==1,"negative levels clamp to full cost");
        check(ArtifactCostMath.factor(50,50)==0,"configurable free level");
        check(ArtifactCostMath.rounded(100,0.5)==100,"integer cost remains exact");
        check(ArtifactCostMath.rounded(0,0)==0,"zero cost never rounds to one");
        System.out.println("PASS: "+count+" production cost interpolation checks; no game launched.");
    }
}
