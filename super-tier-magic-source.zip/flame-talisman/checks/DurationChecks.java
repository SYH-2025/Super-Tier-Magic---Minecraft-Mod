import dev.flametalisman.DurationMath;
public final class DurationChecks {
    private static int n;
    private static void check(boolean value,String label){n++;if(!value)throw new AssertionError(label);}
    public static void main(String[]args){
        check(DurationMath.fireRain(0)==300,"baseline fire rain");
        check(DurationMath.fireRain(20)==500,"max fire rain ~25 seconds");
        check(DurationMath.thunderRain(5)==500,"max thunder rain ~25 seconds");
        check(DurationMath.domain(5)==500,"max domain ~25 seconds");
        check(DurationMath.fall(5)==167,"giant sword descends for 8.35 seconds");
        check(DurationMath.extend(120,3,3)==200,"talisman rain 10 seconds");
        check(DurationMath.extend(200,3,3)==333,"tornado hold 16.65 seconds");
        check(DurationMath.fireRain(-1)==300&&DurationMath.fireRain(200)==500,"enchantment bounds");
        int previous=300;for(int i=0;i<=20;i++){int duration=DurationMath.fireRain(i);check(duration>=previous,"monotonic fire rain");previous=duration;}
        for(int i=0;i<=10;i++)check(DurationMath.flightRate(i,100)==1,"low-level flight costs 1 health per 2 seconds");
        check(DurationMath.flightRate(55,100)==.5,"level 55 flight costs 1 health per 4 seconds");
        check(Math.abs(DurationMath.flightRate(90,100)-1/9.0)<1e-10,"level 90 flight costs 1 health per 18 seconds");
        check(DurationMath.flightRate(100,100)==0&&DurationMath.flightRate(150,100)==0,"level 100+ flight is free");
        check(DurationMath.SKY_FADE==120,"sky visual fade lasts six seconds");
        System.out.println("PASS: "+n+" duration and flight-rate checks; no game launched.");
    }
}
