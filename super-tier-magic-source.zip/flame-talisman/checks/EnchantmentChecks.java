import dev.flametalisman.EnchantmentSpellMath;
public final class EnchantmentChecks {
    private static int checks;
    private static void check(boolean pass,String label){checks++;if(!pass)throw new AssertionError(label);}
    public static void main(String[]args){
        int[]range={32,51,70,90,109,128};
        for(int level=0;level<=5;level++){
            check(EnchantmentSpellMath.range(level)==range[level],"wave range at "+level);
            check(EnchantmentSpellMath.ghosts(level)==123+24*level,"ghost count at "+level);
            check(Math.abs(EnchantmentSpellMath.opacity(level)-(.82+.03*level))<1e-8,"ghost opacity at "+level);
            check(Math.abs(EnchantmentSpellMath.percentMultiplier(level)-(1+.1*level))<1e-8,"percentage multiplier at "+level);
            double nativeSharp=level>0?level*.5+.5:0;
            check(Math.abs(12+EnchantmentSpellMath.swordAttributeBonus(level)+nativeSharp-(12+3*level))<1e-8,"exact melee damage including native Sharpness");
            check(EnchantmentSpellMath.rays(level)>=Math.PI*range[level]/1.6,"no growing gaps in long wave sampling");
        }
        int count=0;for(int tick=0;tick<300;tick++)count+=EnchantmentSpellMath.rainThisTick(tick,20);
        check(count==750,"Fire Aspect XX rains 50 orbs per second for 15 seconds");
        for(int second=0;second<15;second++){count=0;for(int tick=second*20;tick<(second+1)*20;tick++)count+=EnchantmentSpellMath.rainThisTick(tick,20);check(count==50,"each Fire Aspect XX second quota");}
        count=0;for(int tick=0;tick<300;tick++)count+=EnchantmentSpellMath.rainThisTick(tick,0);check(count==300,"unenhanced rain preserved");
        check(EnchantmentSpellMath.fireBonus(20)==40,"Fire Aspect XX adds 40 direct damage");
        check(Math.abs(.10*EnchantmentSpellMath.percentMultiplier(5)-.15)<1e-8,"Sharpness V sky percentage is 15 percent");
        System.out.println("PASS: "+checks+" production enchantment scaling checks; no game launched.");
    }
}
