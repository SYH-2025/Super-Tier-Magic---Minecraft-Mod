import dev.flametalisman.SpellGeometry;
import dev.flametalisman.BladeMath;

/** Dependency-free regression checks for the real production geometry. */
public final class SpellGeometryChecks {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(SpellGeometry.inWave(16, 0, 14, 16, 0), "16 block endpoint must hit");
        check(!SpellGeometry.inWave(16.01, 0, 14, 16, 0), "must not hit beyond range");
        check(!SpellGeometry.inWave(-10, 0, 8, 10, 0), "must not hit behind caster");
        check(SpellGeometry.inWave(0, 16, 14, 16, 0), "semicircle right endpoint");
        check(SpellGeometry.inWave(0, -16, 14, 16, 0), "semicircle left endpoint");
        check(!SpellGeometry.inWave(10, 0, 12, 14, 0), "already passed wavefront");
        check(!SpellGeometry.inWave(16, 0, 12, 14, 0), "wavefront has not arrived");
        check(SpellGeometry.inWave(14.4, 0, 12, 14, 0.5), "entity bounding radius contact");
        for (int degree = -90; degree <= 90; degree++) {
            double a = Math.toRadians(degree);
            int hitCount = 0;
            for (int tick = 0; tick < SpellGeometry.WAVE_TICKS; tick++) {
                if (SpellGeometry.inWave(15.3 * Math.cos(a), 15.3 * Math.sin(a), tick * SpellGeometry.WAVE_SPEED, (tick+1)*SpellGeometry.WAVE_SPEED, 0)) hitCount++;
            }
            check(hitCount == 1, "no gaps or duplicate tick hits at angle " + degree);
        }
        check(SpellGeometry.inRain(8, 0, 0), "rain radius endpoint");
        check(!SpellGeometry.inRain(8.01, 0, 0), "rain outside footprint");
        check(!SpellGeometry.inRain(6, 6, 0), "rain uses circle, not square");
        check(SpellGeometry.CHARGE_TICKS == 4 * 20, "four second charge");
        check(SpellGeometry.RAIN_TICKS == 6 * 20, "six second rain");
        int hits = 0;
        for (int t = 0; t < 200; t++) {
            if (t >= SpellGeometry.CHARGE_TICKS && (t - SpellGeometry.CHARGE_TICKS) % SpellGeometry.HIT_INTERVAL == 0) hits++;
        }
        check(hits == 6, "six damage opportunities per target");
        int meteors = 0;
        for(int age=0;age<BladeMath.DURATION;age++) if(BladeMath.emitOrb(age)) meteors++;
        check(meteors==300,"twenty meteors per second for fifteen seconds");
        check(!BladeMath.emitOrb(199) && BladeMath.emitOrb(200),"ten second charge before meteor emission");
        check(!BladeMath.emitOrb(500),"emission ends after fifteen seconds");
        check(BladeMath.explosionDamage(0)==30 && BladeMath.explosionDamage(4)==15,"explosion linear damage falloff");
        check(BladeMath.explosionDamage(8)==0 && BladeMath.explosionDamage(12)==0,"explosion radius bounded at eight");
        check(BladeMath.drainedHealth(5,20)==4 && BladeMath.drainedHealth(3,20)==3,"health floor without healing");
        check(BladeMath.drainedHealth(21,100)==20,"health floor scales with max health");
        check(BladeMath.SPEED*BladeMath.WAVE_TICKS==64,"blade wave reaches exactly sixty four blocks");
        System.out.println("PASS: " + checks + " production geometry and timing checks");
    }
}
