import dev.flametalisman.SwordMotion;
import net.minecraft.world.phys.Vec3;
public final class SwordAimChecks {
    private static int checks;
    private static void check(boolean pass,String label){checks++;if(!pass)throw new AssertionError(label);}
    public static void main(String[]args){
        for(double yaw:new double[]{-179,-90,0,45,135})for(double pitch:new double[]{-90,-80,-45,0,45,80,90})for(double roll:new double[]{-80,-30,0,30,80}){
            double y=Math.toRadians(yaw),p=Math.toRadians(pitch);
            Vec3 forward=new Vec3(-Math.sin(y)*Math.cos(p),-Math.sin(p),Math.cos(y)*Math.cos(p));
            Vec3 side=SwordMotion.waveSide(forward,Math.toRadians(roll));
            check(Math.abs(side.lengthSqr()-1)<1e-8,"wave remains circular at steep pitch");
            check(Math.abs(forward.dot(side))<1e-8,"roll never changes firing direction");
            Vec3 tip=forward.scale(32);
            check(Math.abs(tip.length()-32)<1e-8,"32-block range preserved");
            check(pitch==0?Math.abs(tip.y)<1e-8:pitch<0?tip.y>0:tip.y<0,"crosshair elevation sign respected");
        }
        System.out.println("PASS: "+checks+" production 3D sword-wave checks; no game launched.");
    }
}
