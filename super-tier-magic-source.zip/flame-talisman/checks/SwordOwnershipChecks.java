import dev.flametalisman.SwordTargeting;
import java.util.UUID;

/** Checks the production guard used before direct damage, lingering damage and homing. */
public final class SwordOwnershipChecks {
    private static void check(boolean condition,String name){if(!condition)throw new AssertionError(name);}
    public static void main(String[]args){
        UUID caster=UUID.fromString("01800180-0180-4180-8180-018001800180");
        UUID npc=UUID.fromString("02800280-0280-4280-8280-028002800280");
        check(!SwordTargeting.canHit(caster,caster),"caster must never be a sword target");
        check(!SwordTargeting.canHit(caster,UUID.fromString(caster.toString())),"identity survives recreation of the UUID object");
        check(SwordTargeting.canHit(caster,npc),"a separate NPC remains eligible");
        check(SwordTargeting.canHit(npc,caster),"another caster's sword can hit this player");
        check(!SwordTargeting.canHit(null,npc),"missing owner cannot authorize damage");
        check(!SwordTargeting.canHit(caster,null),"missing target cannot authorize damage");
        System.out.println("PASS: 6 sword ownership checks; no Minecraft client launched.");
    }
}
