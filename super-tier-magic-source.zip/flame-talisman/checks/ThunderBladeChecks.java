import dev.flametalisman.ThunderBladeMath;
public final class ThunderBladeChecks {
    private static int checks;
    private static void check(boolean pass,String label){checks++;if(!pass)throw new AssertionError(label);}
    public static void main(String[]args){
        int[]length={72,109,146,182,219,256},depth={64,77,90,102,115,128};
        for(int level=0;level<=5;level++){
            check(ThunderBladeMath.length(level)==length[level],"length at "+level);
            check(ThunderBladeMath.depth(level)==depth[level],"depth at "+level);
            check(Math.abs(ThunderBladeMath.width(level)-(9+level*.2))<1e-8,"width at "+level);
            check(ThunderBladeMath.boltDamage(level)==20+4*level,"bolt at "+level);
        }
        check(ThunderBladeMath.length(100)==256,"sharpness beyond vanilla cap");
        check(ThunderBladeMath.depth(-1)==64,"negative sharpness clamped");
        int[]penetration={5,10,16,21,27,32};
        for(int level=0;level<=5;level++){
            check(ThunderBladeMath.boltDepth(level)==penetration[level],"bolt penetration depth at "+level);
            check(ThunderBladeMath.boltRadius(level)==3+3*level,"bolt destruction radius at "+level);
            check(ThunderBladeMath.stormRate(level)==20+16*level,"storm rate at "+level);
            for(int second=0;second<15;second++){int count=0;for(int tick=second*20;tick<(second+1)*20;tick++)count+=ThunderBladeMath.strikesThisTick(tick,level);check(count==ThunderBladeMath.stormRate(level),"exact one-second storm quota at "+level+" / "+second);}
        }
        System.out.println("PASS: "+checks+" production Sharpness scaling checks; no Minecraft launched.");
    }
}
