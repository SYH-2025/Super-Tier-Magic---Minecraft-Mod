package dev.flametalisman;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.GameType;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class AirFlightManager {
    public static final String ACTIVE_TAG="stmAirCloudFlight";
    private static final String PRIOR_ALLOW="stmAirFlightPriorMayfly",PRIOR_FLYING="stmAirFlightPriorFlying",PRIOR_MODE="stmAirFlightPriorMode";
    private record SavedFlight(ServerPlayer player,GameType mode,boolean mayfly,boolean flying){}
    private static final Map<UUID,SavedFlight>ACTIVE=new HashMap<>();private static final Map<UUID,Double>DRAIN=new HashMap<>();
    public static boolean hasTalisman(Player player){var inventory=player.getInventory();for(int i=0;i<inventory.getContainerSize();i++)if(inventory.getItem(i).is(FlameTalisman.AIR_TALISMAN.get()))return true;return false;}
    private static boolean permitted(ServerPlayer player){return player.isAlive()&&player.gameMode.getGameModeForPlayer()!=GameType.SPECTATOR&&(ArtifactConfig.FLIGHT_CHEAT.get()||ArtifactConfig.AIR_FLIGHT.get()&&hasTalisman(player));}
    private static void sync(ServerPlayer player,boolean active){player.getPersistentData().putBoolean(ACTIVE_TAG,active);SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new SpellNetwork.FlightState(active));}
    public static void toggle(ServerPlayer player){
        if(ACTIVE.containsKey(player.getUUID())){disable(player);return;}
        if(!permitted(player)){sync(player,false);return;}
        var abilities=player.getAbilities();ACTIVE.put(player.getUUID(),new SavedFlight(player,player.gameMode.getGameModeForPlayer(),abilities.mayfly,abilities.flying));
        player.getPersistentData().putString(PRIOR_MODE,player.gameMode.getGameModeForPlayer().getName());
        player.getPersistentData().putBoolean(PRIOR_ALLOW,abilities.mayfly);player.getPersistentData().putBoolean(PRIOR_FLYING,abilities.flying);
        abilities.mayfly=true;abilities.flying=true;player.fallDistance=0;player.onUpdateAbilities();sync(player,true);
    }
    private static void disable(ServerPlayer player){
        SavedFlight saved=ACTIVE.remove(player.getUUID());DRAIN.remove(player.getUUID());
        if(saved!=null&&player.gameMode.getGameModeForPlayer()!=GameType.SPECTATOR){var abilities=player.getAbilities();GameType mode=player.gameMode.getGameModeForPlayer();boolean creative=mode==GameType.CREATIVE,same=mode==saved.mode;abilities.mayfly=creative||same&&saved.mayfly;abilities.flying=!creative&&same&&saved.mayfly&&saved.flying;player.fallDistance=0;player.onUpdateAbilities();}
        player.getPersistentData().remove(PRIOR_ALLOW);player.getPersistentData().remove(PRIOR_FLYING);player.getPersistentData().remove(PRIOR_MODE);sync(player,false);
    }
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event){
        if(event.phase!=TickEvent.Phase.END||!(event.player instanceof ServerPlayer player)||!ACTIVE.containsKey(player.getUUID()))return;
        if(!permitted(player)){disable(player);return;}
        var abilities=player.getAbilities();if(!abilities.mayfly||!abilities.flying){abilities.mayfly=true;abilities.flying=true;player.onUpdateAbilities();}player.fallDistance=0;
        if(!player.getAbilities().instabuild&&ArtifactConfig.FLIGHT_HEALTH.get()){
            double rate=DurationMath.flightRate(player.experienceLevel,100);
            double elapsed=DRAIN.getOrDefault(player.getUUID(),0.0)+rate;
            double interval=ArtifactConfig.FLIGHT_SECONDS.get()*20;
            if(elapsed>=interval){elapsed-=interval;float floor=(float)(player.getMaxHealth()*ArtifactConfig.FLIGHT_FLOOR.get());if(player.getHealth()>floor)player.setHealth(Math.max(floor,player.getHealth()-1));}
            DRAIN.put(player.getUUID(),elapsed);
        }
    }
    @SubscribeEvent public static void mining(PlayerEvent.BreakSpeed event){
        Player player=event.getEntity();if(!ArtifactConfig.CLOUD_MINING.get()||!player.getAbilities().flying||!player.getPersistentData().getBoolean(ACTIVE_TAG))return;
        float speed=event.getOriginalSpeed();if(!player.onGround())speed*=5;if(player.isEyeInFluid(FluidTags.WATER)&&!EnchantmentHelper.hasAquaAffinity(player))speed*=5;event.setNewSpeed(speed);
    }
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event){if(event.getEntity() instanceof ServerPlayer player){
        var data=player.getPersistentData();var abilities=player.getAbilities();boolean survival=player.gameMode.getGameModeForPlayer()==GameType.SURVIVAL||player.gameMode.getGameModeForPlayer()==GameType.ADVENTURE;
        if(data.getBoolean(ACTIVE_TAG)&&survival){boolean same=player.gameMode.getGameModeForPlayer().getName().equals(data.getString(PRIOR_MODE));abilities.mayfly=same&&data.getBoolean(PRIOR_ALLOW);abilities.flying=abilities.mayfly&&data.getBoolean(PRIOR_FLYING);player.onUpdateAbilities();}
        if(!net.minecraftforge.fml.ModList.get().isLoaded("nuvemwukong")&&data.getBoolean("NuvemAtivaWukong")){data.remove("NuvemAtivaWukong");if(survival){abilities.mayfly=false;abilities.flying=false;player.onUpdateAbilities();}}
        data.remove(PRIOR_ALLOW);data.remove(PRIOR_FLYING);data.remove(PRIOR_MODE);sync(player,false);
    }}
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event){if(event.getEntity() instanceof ServerPlayer player)disable(player);}
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event){if(event.getEntity() instanceof ServerPlayer player)disable(player);}
    @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent event){if(event.getEntity() instanceof ServerPlayer player)disable(player);}
    @SubscribeEvent public static void stop(ServerStoppedEvent event){for(var state:new ArrayList<>(ACTIVE.values()))disable(state.player);ACTIVE.clear();}
    private AirFlightManager(){}
}
