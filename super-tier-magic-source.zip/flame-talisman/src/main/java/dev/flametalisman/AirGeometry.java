package dev.flametalisman;
public final class AirGeometry {
    public static double progress(double age,double duration){double t=Math.max(0,Math.min(1,age/duration));return t*t*(3-2*t);}
    public static double pushRadius(double start,double age){return start+(68-start)*progress(age,8);}
    public static double vortexRadius(double start,double age){return Math.max(0,start)*(1-progress(age,40))+1.6*progress(age,40);}
    public static double cloudRadius(double age){return 4+6*Math.max(0,Math.min(1,age/12));}
    private AirGeometry(){}
}
