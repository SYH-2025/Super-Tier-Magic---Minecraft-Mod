package dev.flametalisman;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class AirManager {
    private static final Map<ServerLevel,List<Spell>>ACTIVE=new IdentityHashMap<>();private static int nextId;
    private static boolean valid(Entity e,UUID owner){return !e.isRemoved()&&!e.isSpectator()&&!e.getUUID().equals(owner)&&(!(e instanceof LivingEntity living)||living.isAlive());}
    private static void send(ServerLevel level,SpellNetwork.WindEffect effect){SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension),effect);}
    private static void relocate(Entity e,Vec3 point){
        e.fallDistance=0;
        if(e instanceof ServerPlayer p)p.connection.teleport(point.x,point.y,point.z,p.getYRot(),p.getXRot());else e.teleportTo(point.x,point.y,point.z);
        e.setDeltaMovement(Vec3.ZERO);
    }
    private static void velocity(Entity e,Vec3 value){e.setDeltaMovement(value);e.hasImpulse=true;e.hurtMarked=true;if(e instanceof ServerPlayer p)p.connection.send(new ClientboundSetEntityMotionPacket(p));}
    public static boolean cast(ServerPlayer player,boolean right){
        var stack=player.getMainHandItem();boolean shift=player.isShiftKeyDown();
        if(!player.isAlive()||player.isSpectator()||!stack.is(FlameTalisman.AIR_TALISMAN.get())||player.getCooldowns().isOnCooldown(stack.getItem())||(!right&&!shift))return false;
        int kind=shift?(right?1:0):2,cost=kind==2?1:10;
        if(!(kind==0?ArtifactConfig.AIR_PUSH.get():kind==1?ArtifactConfig.AIR_VORTEX.get():ArtifactConfig.AIR_BLADE.get()))return false;
        var spells=ACTIVE.computeIfAbsent(player.serverLevel(),l->new ArrayList<>());
        if(spells.stream().anyMatch(s->s.owner.equals(player.getUUID())&&s.kind==kind))return false;
        if(!player.getAbilities().instabuild&&stack.getMaxDamage()-stack.getDamageValue()<ArtifactCosts.required(player,cost)){player.displayClientMessage(Component.translatable("message.flametalisman.low_durability",ArtifactCosts.required(player,cost)),true);return false;}
        Vec3 origin=kind==2?player.getEyePosition().add(0,-.3,0):player.position();
        if(kind==1){origin=SpellAim.ground(player,64);if(origin==null){player.displayClientMessage(Component.translatable("message.flametalisman.intent_target"),true);return false;}}
        Vec3 direction=player.getLookAngle().normalize();float roll=(float)Math.toRadians((player.getRandom().nextBoolean()?1:-1)*(30+player.getRandom().nextDouble()*30));
        if(shift)MagicAdvancements.grant(player,kind==1?"air_vortex":"air_push");
        Spell spell=new Spell(player,kind,++nextId,origin,direction,roll);spells.add(spell);send(player.serverLevel(),spell.packet());
        player.getCooldowns().addCooldown(stack.getItem(),kind==0?20:8);stack.hurtAndBreak(cost,player,p->p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        player.serverLevel().playSound(null,player.blockPosition(),kind==2?SoundEvents.PLAYER_ATTACK_SWEEP:SoundEvents.ELYTRA_FLYING,SoundSource.PLAYERS,kind==2?.55f:1.3f,kind==2?.95f:.65f);return true;
    }
    @SubscribeEvent public static void tick(TickEvent.LevelTickEvent event){if(event.phase!=TickEvent.Phase.END||!(event.level instanceof ServerLevel level))return;var spells=ACTIVE.get(level);if(spells==null)return;spells.removeIf(s->s.tick(level));if(spells.isEmpty())ACTIVE.remove(level);}
    @SubscribeEvent public static void stop(ServerStoppedEvent event){for(var spells:ACTIVE.values())for(var spell:spells)spell.restore();ACTIVE.clear();nextId=0;}
    private static final class Subject {
        final Entity entity;final Vec3 start,radial;final double distance,angle;final boolean gravity;
        boolean blocked;int capturedAt;double slamY=Double.NaN;
        Subject(Entity entity,Vec3 origin,Vec3 fallback){this.entity=entity;start=entity.position();Vec3 delta=start.subtract(origin).multiply(1,0,1);distance=delta.length();Vec3 horizontal=fallback.multiply(1,0,1).normalize();radial=distance>.01?delta.normalize():horizontal.lengthSqr()>.01?horizontal:new Vec3(1,0,0);angle=Math.atan2(radial.z,radial.x);gravity=entity.isNoGravity();}
    }
    private static final class Spell {
        final UUID owner;final ServerLevel level;final int kind,id,holdEnd;final Vec3 origin,forward,side;final float roll;final List<Subject>subjects=new ArrayList<>();final Set<UUID>hit=new HashSet<>(),captured=new HashSet<>();int age;double peak;
        Spell(ServerPlayer player,int kind,int id,Vec3 origin,Vec3 forward,float roll){
            owner=player.getUUID();level=player.serverLevel();this.kind=kind;this.id=id;holdEnd=40+DurationMath.extend(200,net.minecraft.world.item.enchantment.EnchantmentHelper.getItemEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,player.getMainHandItem()),3);this.origin=origin;this.forward=forward;this.roll=roll;
            Vec3 right=new Vec3(forward.z,0,-forward.x).normalize();if(right.lengthSqr()<.01)right=new Vec3(1,0,0);side=right.scale(Math.cos(roll)).add(forward.cross(right).normalize().scale(Math.sin(roll)));
            peak=origin.y+32;player.stopRiding();
            if(kind!=2)for(Entity e:level.getEntities(player,new AABB(origin,origin).inflate(64),e->valid(e,owner)&&(kind==0||e instanceof LivingEntity))){
                if(e.position().distanceToSqr(origin)>64*64)continue;Subject s=new Subject(e,origin,forward);subjects.add(s);captured.add(e.getUUID());e.stopRiding();if(kind==1){e.setNoGravity(true);peak=Math.max(peak,s.start.y+24);}
            }
        }
        SpellNetwork.WindEffect packet(){return new SpellNetwork.WindEffect(kind,id,origin,kind==1?new Vec3(holdEnd,peak-origin.y,0):forward,kind==0?8:kind==1?holdEnd+(int)Math.ceil((peak-origin.y)/16)+1:12,age,roll);}
        void recruit(ServerPlayer player){
            double previousPeak=peak;
            for(LivingEntity e:level.getEntitiesOfClass(LivingEntity.class,new AABB(origin,origin).inflate(64),e->valid(e,owner)&&!captured.contains(e.getUUID()))){
                if(e.position().distanceToSqr(origin)>64*64)continue;
                Subject subject=new Subject(e,origin,forward);subject.capturedAt=age;subjects.add(subject);captured.add(e.getUUID());
                e.stopRiding();e.setNoGravity(true);peak=Math.max(peak,subject.start.y+24);
            }
            if(peak!=previousPeak)send(level,packet());
        }
        void restore(){if(kind==1)for(Subject s:subjects)if(!s.entity.isRemoved()){s.entity.setNoGravity(s.gravity);s.entity.fallDistance=0;}}
        boolean tick(ServerLevel level){
            ServerPlayer player=level.getServer().getPlayerList().getPlayer(owner);
            if(player==null||!player.isAlive()||player.serverLevel()!=level){restore();send(level,new SpellNetwork.WindEffect(9,id,origin,forward,0,0,0));return true;}
            if(kind==2)return blade(player);
            if(kind==1&&age<holdEnd)recruit(player);
            for(Subject s:subjects){Entity e=s.entity;if(!valid(e,owner)||e.level()!=level)continue;
                if(kind==0){
                    if(s.blocked)continue;
                    if(age<8){
                        double r=AirGeometry.pushRadius(s.distance,age+1);Vec3 wanted=origin.add(s.radial.scale(r)).add(0,s.start.y-origin.y,0),before=e.position(),step=wanted.subtract(before);
                        boolean noPhysics=e.noPhysics;e.noPhysics=false;
                        try{e.move(MoverType.SELF,step);}finally{e.noPhysics=noPhysics;}
                        Vec3 actual=e.position(),moved=actual.subtract(before);
                        boolean collided=e.horizontalCollision||moved.multiply(1,0,1).distanceToSqr(step.multiply(1,0,1))>0.00001;
                        relocate(e,actual);
                        if(collided)wallHit(s,player);else if(age==7)velocity(e,s.radial.scale(4).add(0,1,0));
                    }else if(e.horizontalCollision)wallHit(s,player);
                }
                else{
                    if(age<holdEnd&&age-s.capturedAt<40){int elapsed=age-s.capturedAt+1;double f=AirGeometry.progress(elapsed,40),r=AirGeometry.vortexRadius(s.distance,elapsed),a=s.angle+elapsed*.38;relocate(e,new Vec3(origin.x+Math.cos(a)*r,s.start.y+(peak-s.start.y)*f,origin.z+Math.sin(a)*r));if(age%10==9&&e instanceof LivingEntity living)ArtifactExperience.hurt(living,player.damageSources().playerAttack(player),1);}
                    else if(age<holdEnd){double a=s.angle+(age-s.capturedAt)*.38;relocate(e,new Vec3(origin.x+Math.cos(a)*1.6,peak+Math.sin(a)*.35,origin.z+Math.sin(a)*1.6));}
                    else{
                        if(Double.isNaN(s.slamY))s.slamY=e.getY();
                        double y=Math.max(origin.y,s.slamY-(age-holdEnd+1)*16);double a=s.angle+(holdEnd-s.capturedAt)*.38;Vec3 point=new Vec3(origin.x+Math.cos(a)*1.6,y,origin.z+Math.sin(a)*1.6);relocate(e,point);
                        if(y<=origin.y){e.setNoGravity(s.gravity);if(hit.add(e.getUUID())&&e instanceof LivingEntity living){ArtifactExperience.hurt(living,player.damageSources().playerAttack(player),18);send(level,new SpellNetwork.WindEffect(3,++nextId,point,Vec3.ZERO,16,0,0));}velocity(e,Vec3.ZERO);}
                    }
                }
            }
            int end=kind==0?28:holdEnd+(int)Math.ceil((peak-origin.y)/16)+1;
            if(++age>=end){restore();send(level,new SpellNetwork.WindEffect(9,id,origin,forward,0,0,0));return true;}return false;
        }
        void wallHit(Subject subject,ServerPlayer player){
            subject.blocked=true;Entity target=subject.entity;
            if(target instanceof LivingEntity living&&valid(living,owner)&&hit.add(target.getUUID()))ArtifactExperience.hurt(living,player.damageSources().playerAttack(player),8);
            velocity(target,Vec3.ZERO);send(level,new SpellNetwork.WindEffect(3,++nextId,target.position(),Vec3.ZERO,12,0,0));
        }
        boolean blade(ServerPlayer player){
            Vec3 from=origin.add(forward.scale(age*4)),to=origin.add(forward.scale((age+1)*4));
            if(!level.hasChunkAt(BlockPos.containing(to))){send(level,new SpellNetwork.WindEffect(9,id,origin,forward,0,0,0));return true;}
            BlockHitResult wall=level.clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player));Vec3 end=wall.getType()==HitResult.Type.BLOCK?wall.getLocation():to;
            double radius=AirGeometry.cloudRadius(age+1);Vec3 axis=end.subtract(from);
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(from,end).inflate(radius+2),e->valid(e,owner)&&!hit.contains(e.getUUID()))){
                Vec3 center=target.getBoundingBox().getCenter(),delta=center.subtract(origin);double padding=Math.max(target.getBbWidth(),target.getBbHeight())*.5;
                if(delta.dot(forward)<0||delta.length()>48+target.getBbWidth()/2)continue;
                double fraction=axis.lengthSqr()>.00001?Math.max(0,Math.min(1,center.subtract(from).dot(axis)/axis.lengthSqr())):0;Vec3 nearest=from.add(axis.scale(fraction));
                if(center.distanceTo(nearest)>radius+padding)continue;
                if(level.clip(new ClipContext(nearest,center,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player)).getType()!=HitResult.Type.MISS)continue;
                hit.add(target.getUUID());ArtifactExperience.hurt(target,player.damageSources().playerAttack(player),10);velocity(target,forward.multiply(1,0,1).normalize().scale(3.5).add(0,1.8,0));target.fallDistance=0;
            }
            if(wall.getType()==HitResult.Type.BLOCK){send(level,new SpellNetwork.WindEffect(9,id,origin,forward,0,0,0));send(level,new SpellNetwork.WindEffect(3,++nextId,end,Vec3.ZERO,16,0,0));return true;}return ++age>=12;
        }
    }
}
