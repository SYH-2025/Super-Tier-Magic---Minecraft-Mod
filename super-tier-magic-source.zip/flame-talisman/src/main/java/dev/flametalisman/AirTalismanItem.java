package dev.flametalisman;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
public final class AirTalismanItem extends Item {
    public AirTalismanItem(){super(new Properties().durability(640));}
    @Override public int getEnchantmentValue(){return 15;}
    @Override public boolean canApplyAtEnchantingTable(ItemStack stack,Enchantment e){return e==Enchantments.MENDING||e==Enchantments.UNBREAKING;}
    @Override public boolean isBookEnchantable(ItemStack stack,ItemStack book){return EnchantmentHelper.getEnchantments(book).keySet().stream().allMatch(e->e==Enchantments.MENDING||e==Enchantments.UNBREAKING);}
    @Override public <T extends net.minecraft.world.entity.LivingEntity> int damageItem(ItemStack stack,int amount,T entity,java.util.function.Consumer<T> broken){return ArtifactCosts.damage(entity,amount);}
    @Override public void appendHoverText(ItemStack stack,@Nullable Level level,List<Component>lines,TooltipFlag flag){ItemLegend.append(lines,"air_talisman");}
}
