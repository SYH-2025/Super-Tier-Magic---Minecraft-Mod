package dev.flametalisman;
import net.minecraftforge.common.ForgeConfigSpec;
public final class ArtifactConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue HEALTH_COST,DURABILITY_COST,LEVEL_HEALTH,LEVEL_DURABILITY,FIRE_SKY,THUNDER_SKY,ABYSS,SWORD_SKY,SWORD_DOMAIN,FIRE_IMMUNITY,SHARD_DROPS,LORE,INSCRIPTIONS;
    public static final ForgeConfigSpec.IntValue FREE_LEVEL;
    public static final ForgeConfigSpec.DoubleValue HEALTH_FRACTION;
    public static final ForgeConfigSpec.BooleanValue STORM_TERRAIN;
    public static final ForgeConfigSpec.BooleanValue AIR_PUSH,AIR_VORTEX,AIR_BLADE,FALL_IMMUNITY;
    public static final ForgeConfigSpec.DoubleValue SWORD_PERCENT_MIN,SWORD_PERCENT_MAX;
    public static final ForgeConfigSpec.BooleanValue AIR_FLIGHT,CLOUD_PARTICLES,CLOUD_MINING;
    public static final ForgeConfigSpec.BooleanValue BOLT_TERRAIN,REMOTE_XP,FLIGHT_CHEAT,FLIGHT_HEALTH;
    public static final ForgeConfigSpec.DoubleValue FLIGHT_SECONDS,FLIGHT_FLOOR;
    static {
        var b=new ForgeConfigSpec.Builder();b.push("costs");
        HEALTH_COST=b.comment("Enable survival-only ultimate health costs.").define("healthCost",true);
        DURABILITY_COST=b.comment("Enable durability and Lightning Shard consumption.").define("durabilityCost",true);
        LEVEL_HEALTH=b.comment("Linearly reduce health costs with current experience level.").define("scaleHealthWithLevel",true);
        LEVEL_DURABILITY=b.comment("Reduce durability with level. Fractional costs use unbiased random rounding.").define("scaleDurabilityWithLevel",true);
        FREE_LEVEL=b.comment("Level at which scaled costs reach zero.").defineInRange("freeAtLevel",100,1,10000);
        HEALTH_FRACTION=b.comment("Fraction of maximum health spent at level zero; never heals.").defineInRange("baseHealthFraction",0.80,0.0,0.99);b.pop();b.push("skills");
        FIRE_SKY=b.define("flameSky",true);THUNDER_SKY=b.define("thunderSky",true);ABYSS=b.comment("Disable to prevent destructive terrain cutting.").define("thunderAbyss",true);SWORD_SKY=b.define("celestialSword",true);SWORD_DOMAIN=b.define("swordDomain",true);STORM_TERRAIN=b.comment("Sky lightning carves irregular craters up to five blocks deep, without block drops.").define("thunderStormTerrainDamage",true);b.pop();b.push("features");
        FIRE_IMMUNITY=b.define("inventoryFireImmunity",true);SHARD_DROPS=b.define("lightningRodShardDrops",true);LORE=b.define("itemLegendStories",true);INSCRIPTIONS=b.define("rotatingCalligraphy",true);FALL_IMMUNITY=b.define("inventoryFallImmunity",true);REMOTE_XP=b.comment("Artifact kill XP is picked up by its caster remotely, including vanilla Mending. Item drops stay in place.").define("remoteKillExperience",true);b.pop();
        b.push("air");FLIGHT_CHEAT=b.comment("R toggles cloud flight without an Air Talisman when enabled.").define("flightCheat",false);FLIGHT_HEALTH=b.define("flightHealthCost",true);FLIGHT_SECONDS=b.comment("Seconds per one health point at level 10 and below; drain rate decreases linearly to zero at level 100.").defineInRange("flightSecondsPerHealth",2.0,.1,3600.0);FLIGHT_FLOOR=b.defineInRange("flightMinimumHealthFraction",.40,.01,1.0);AIR_PUSH=b.define("repulsion",true);AIR_VORTEX=b.define("vortex",true);AIR_BLADE=b.define("windBlade",true);AIR_FLIGHT=b.comment("Enable talisman cloud flight in Survival, Adventure and Creative. Key name retained for existing configs.").define("survivalCloudFlight",true);CLOUD_PARTICLES=b.define("thirdPersonCloudParticles",true);CLOUD_MINING=b.define("flightMiningCompensation",true);b.pop();
        b.push("swordPercentage");SWORD_PERCENT_MIN=b.comment("Fraction of target maximum health, added as forced health loss.").defineInRange("minimum",0.05,0.0,1.0);SWORD_PERCENT_MAX=b.defineInRange("maximum",0.10,0.0,1.0);b.pop();
        b.push("lightning");BOLT_TERRAIN=b.comment("Thunderclap Blade bolts carve a cylindrical penetration tunnel. Blocks have no drops; unbreakable blocks are preserved.").define("boltTerrainDamage",true);b.pop();SPEC=b.build();
    }
    private ArtifactConfig(){}
}
