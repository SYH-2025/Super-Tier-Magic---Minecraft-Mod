package dev.flametalisman;
public final class ArtifactCostMath {
    public static double factor(int level,int freeAt){return Math.max(0,1-Math.max(0,level)/(double)Math.max(1,freeAt));}
    public static float healthFloor(float maximum,double fraction,double factor){return (float)(maximum*(1-fraction*factor));}
    public static int rounded(double cost,double sample){int whole=(int)Math.floor(cost);return whole+(sample<cost-whole?1:0);}
    private ArtifactCostMath(){}
}
