package dev.flametalisman;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
public final class ArtifactCosts {
    private static double factor(LivingEntity entity,boolean scale){return scale&&entity instanceof Player p?ArtifactCostMath.factor(p.experienceLevel,ArtifactConfig.FREE_LEVEL.get()):1;}
    private static double durability(LivingEntity entity,int base){return ArtifactConfig.DURABILITY_COST.get()?base*factor(entity,ArtifactConfig.LEVEL_DURABILITY.get()):0;}
    public static int damage(LivingEntity entity,int base){return ArtifactCostMath.rounded(durability(entity,base),entity.getRandom().nextDouble());}
    public static int required(LivingEntity entity,int base){return (int)Math.ceil(durability(entity,base));}
    public static void health(ServerPlayer player,boolean gradual){
        if(!ArtifactConfig.HEALTH_COST.get()||player.gameMode.getGameModeForPlayer()!=GameType.SURVIVAL)return;
        double factor=factor(player,ArtifactConfig.LEVEL_HEALTH.get());if(factor==0)return;
        float floor=ArtifactCostMath.healthFloor(player.getMaxHealth(),ArtifactConfig.HEALTH_FRACTION.get(),factor),current=player.getHealth();
        if(current>floor)player.setHealth(gradual?Math.max(floor,current-(float)(2*factor)):floor);
    }
    private ArtifactCosts(){}
}
