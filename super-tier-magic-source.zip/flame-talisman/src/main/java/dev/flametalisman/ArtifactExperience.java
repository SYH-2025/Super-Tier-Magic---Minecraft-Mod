package dev.flametalisman;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Mob;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Artifact kill attribution, remote XP pickup, and Sword Intent vanilla-mob loot suppression. */
@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class ArtifactExperience {
    private static final String OWNER="stmArtifactXpOwner",UNTIL="stmArtifactXpUntil",KILL="stmArtifactXpKill";
    private static final ThreadLocal<DamageSource> SKILL=new ThreadLocal<>();
    private static final ThreadLocal<Boolean> SWORD=ThreadLocal.withInitial(()->false);
    static boolean isSkillSource(DamageSource source){return SKILL.get()==source;}
    static boolean weapon(ItemStack stack){
        return stack.is(FlameTalisman.TALISMAN.get())||stack.is(FlameTalisman.BLADE.get())
                ||stack.is(FlameTalisman.LIGHTNING_SHARD.get())||stack.is(FlameTalisman.LIGHTNING_TALISMAN.get())
                ||stack.is(FlameTalisman.THUNDER_BLADE.get())||stack.is(FlameTalisman.SWORD_INTENT.get())
                ||stack.is(FlameTalisman.AIR_TALISMAN.get());
    }
    static void mark(LivingEntity target,ServerPlayer player){
        mark(target,player,false);
    }
    static void markSword(LivingEntity target,ServerPlayer player){mark(target,player,true);}
    private static void mark(LivingEntity target,ServerPlayer player,boolean sword){
        if(!(target.level() instanceof ServerLevel level))return;
        var data=target.getPersistentData();data.putUUID(OWNER,player.getUUID());
        data.putLong(UNTIL,level.getServer().overworld().getGameTime()+300);
        data.putBoolean("stmArtifactXpSword",sword);
    }
    public static boolean hurt(LivingEntity target,DamageSource source,float damage){
        return hurt(target,source,damage,false);
    }
    static boolean hurtSword(LivingEntity target,DamageSource source,float damage){return hurt(target,source,damage,true);}
    private static boolean hurt(LivingEntity target,DamageSource source,float damage,boolean sword){
        DamageSource previous=SKILL.get();boolean previousSword=SWORD.get();SKILL.set(source);SWORD.set(sword);
        try{return target.hurt(source,damage);}finally{SKILL.set(previous);SWORD.set(previousSword);}
    }
    static void qiOwner(LivingEntity target,ServerPlayer player){
        target.getPersistentData().putUUID("stmSwordQiOwner",player.getUUID());markSword(target,player);
    }
    static void qiPulse(LivingEntity target){
        if(!(target.level() instanceof ServerLevel level))return;
        var data=target.getPersistentData();
        if(data.hasUUID("stmSwordQiOwner")){
            ServerPlayer player=level.getServer().getPlayerList().getPlayer(data.getUUID("stmSwordQiOwner"));
            if(player!=null){markSword(target,player);target.setLastHurtByPlayer(player);}
        }
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void damage(LivingDamageEvent event){
        if(event.getAmount()<=0||!(event.getEntity().level() instanceof ServerLevel))return;
        DamageSource source=event.getSource();
        if(source.getEntity() instanceof ServerPlayer player){
            if(SKILL.get()==source||source.getDirectEntity()==player&&weapon(player.getMainHandItem()))
                mark(event.getEntity(),player,SKILL.get()==source?SWORD.get():player.getMainHandItem().is(FlameTalisman.SWORD_INTENT.get()));
            else clear(event.getEntity());
        }else if(source.getEntity()!=null)clear(event.getEntity());
    }
    private static void clear(LivingEntity target){target.getPersistentData().remove(OWNER);target.getPersistentData().remove(UNTIL);target.getPersistentData().remove("stmArtifactXpSword");}
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void death(LivingDeathEvent event){
        if(!(event.getEntity().level() instanceof ServerLevel level))return;
        var data=event.getEntity().getPersistentData();data.remove(KILL);data.remove("stmArtifactSwordKill");
        if(!data.hasUUID(OWNER)||data.getLong(UNTIL)<level.getServer().overworld().getGameTime())return;
        if(event.getSource().getEntity()!=null&&!event.getSource().getEntity().getUUID().equals(data.getUUID(OWNER)))return;
        data.putUUID(KILL,data.getUUID(OWNER));
        data.putBoolean("stmArtifactSwordKill",data.getBoolean("stmArtifactXpSword"));
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void drops(LivingDropsEvent event){
        LivingEntity target=event.getEntity();
        if(target.level().isClientSide||!(target instanceof Mob)||!target.getPersistentData().getBoolean("stmArtifactSwordKill"))return;
        if(BuiltInRegistries.ENTITY_TYPE.getKey(target.getType()).getNamespace().equals("minecraft"))event.getDrops().clear();
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void experience(LivingExperienceDropEvent event){
        if(!ArtifactConfig.REMOTE_XP.get()||event.getDroppedExperience()<=0||!(event.getEntity().level() instanceof ServerLevel level))return;
        var data=event.getEntity().getPersistentData();if(!data.hasUUID(KILL))return;
        ServerPlayer player=level.getServer().getPlayerList().getPlayer(data.getUUID(KILL));
        if(player==null||!player.isAlive()||player.isSpectator())return;
        int total=event.getDroppedExperience(),remaining=total,unclaimed=0,delay=player.takeXpDelay;
        try{
            while(remaining>0){
                int value=ExperienceOrb.getExperienceValue(remaining);
                // Never insert into the world: vanilla pickup applies Mending and awards the remainder.
                ExperienceOrb orb=new ExperienceOrb(player.serverLevel(),player.getX(),player.getY(),player.getZ(),value);
                player.takeXpDelay=0;orb.playerTouch(player);
                if(!orb.isRemoved()){unclaimed+=value;orb.discard();}
                remaining-=value;
            }
        }finally{player.takeXpDelay=delay;}
        // A cancelled vanilla pickup retains that chunk as a normal drop.
        event.setDroppedExperience(unclaimed);
        if(unclaimed<total){
            long now=level.getServer().overworld().getGameTime();var playerData=player.getPersistentData();
            if(!playerData.contains("stmRemoteXpSoundTick")||playerData.getLong("stmRemoteXpSoundTick")!=now){
                playerData.putLong("stmRemoteXpSoundTick",now);
                player.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP,SoundSource.PLAYERS,.4f,
                        .9f+(player.getRandom().nextFloat()-player.getRandom().nextFloat())*.35f);
            }
        }
    }
    private ArtifactExperience(){}
}
