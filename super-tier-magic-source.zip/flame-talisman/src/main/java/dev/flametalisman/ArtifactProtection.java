package dev.flametalisman;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class ArtifactProtection {
    private static boolean protectedByFireArtifact(Player player) {
        if(!ArtifactConfig.FIRE_IMMUNITY.get())return false;
        var inventory=player.getInventory();
        for(int i=0;i<inventory.getContainerSize();i++) {
            var stack=inventory.getItem(i);
            if(stack.is(FlameTalisman.TALISMAN.get())||stack.is(FlameTalisman.BLADE.get()))return true;
        }
        return false;
    }
    @SubscribeEvent public static void attack(LivingAttackEvent event) {
        if(event.getEntity() instanceof Player player&&event.getSource().is(DamageTypeTags.IS_FALL)&&protectedByAirArtifact(player)){event.setCanceled(true);player.fallDistance=0;}
        if(event.getEntity() instanceof Player player && event.getSource().is(DamageTypeTags.IS_FIRE) && protectedByFireArtifact(player)) {
            event.setCanceled(true);player.clearFire();
        }
    }
    private static boolean protectedByAirArtifact(Player player){if(!ArtifactConfig.FALL_IMMUNITY.get())return false;var inventory=player.getInventory();for(int i=0;i<inventory.getContainerSize();i++)if(inventory.getItem(i).is(FlameTalisman.AIR_TALISMAN.get()))return true;return false;}
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event) {
        if(event.phase==TickEvent.Phase.END&&!event.player.level().isClientSide&&protectedByAirArtifact(event.player))event.player.fallDistance=0;
        if(event.phase==TickEvent.Phase.END&&!event.player.level().isClientSide&&event.player.isOnFire()&&protectedByFireArtifact(event.player))event.player.clearFire();
    }
}

