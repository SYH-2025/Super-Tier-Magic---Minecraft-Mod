package dev.flametalisman;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
public final class ArtifactRange {
    public static double radius(double base,ItemStack stack){
        int levels=EnchantmentSpellMath.fire(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FIRE_ASPECT,stack))
                +EnchantmentSpellMath.sharp(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS,stack))
                +Math.max(0,Math.min(3,EnchantmentHelper.getItemEnchantmentLevel(Enchantments.UNBREAKING,stack)))
                +Math.max(0,Math.min(1,EnchantmentHelper.getItemEnchantmentLevel(Enchantments.MENDING,stack)));
        return base+5*levels;
    }
    private ArtifactRange(){}
}
