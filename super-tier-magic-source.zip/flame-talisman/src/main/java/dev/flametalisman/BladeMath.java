package dev.flametalisman;

/** Pure mechanics shared by server, client and regression checks. */
public final class BladeMath {
    public static final int CHARGE = 200;
    public static final int RAIN = 300;
    public static final int DURATION = CHARGE + RAIN;
    public static final double RANGE = 64;
    public static final double SPEED = 4;
    public static final int WAVE_TICKS = 16;
    public static final double EXPLOSION_RADIUS = 8;
    public static boolean emitOrb(int age) {
        int t = age - CHARGE;
        return t >= 0 && t < RAIN;
    }
    public static float drainedHealth(float current, float maximum) {
        float floor = maximum * 0.2f;
        return current <= floor ? current : Math.max(floor, current - 2);
    }
    public static float explosionDamage(double distance) {
        return (float)(30 * Math.max(0, 1 - distance / EXPLOSION_RADIUS));
    }
    public static double orbFall(int tick) { return Math.min(12, 8 + tick * 0.5); }
    public static final int RITUAL_COOLDOWN = 30 * 20;
    public static final int DASH_TICKS = 5;
    public static final double DASH_SPEED = 1.6;
    private BladeMath() {}
}
