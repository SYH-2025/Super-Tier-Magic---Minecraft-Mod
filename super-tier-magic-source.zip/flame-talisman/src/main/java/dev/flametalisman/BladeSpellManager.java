package dev.flametalisman;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID)
public final class BladeSpellManager {
    private static final Map<ServerLevel, List<BladeSpell>> ACTIVE = new IdentityHashMap<>();
    private static int nextId;
    private BladeSpellManager() {}
    public static boolean cast(ServerPlayer player, boolean ritual) {
        ItemStack stack = player.getMainHandItem();
        if (!player.isAlive() || player.isSpectator() || ritual!=player.isShiftKeyDown()
                || !stack.is(FlameTalisman.BLADE.get()) || player.getCooldowns().isOnCooldown(stack.getItem())) return false;
        ServerLevel level = player.serverLevel();
        if(ritual&&!ArtifactConfig.FIRE_SKY.get())return false; int remaining = cooldownRemaining(player);
        if(ritual && remaining>0) {
            player.displayClientMessage(Component.translatable("message.flametalisman.ritual_cooldown",(remaining+19)/20),true);
            SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new SpellNetwork.HandAnimation(player.getId(),3,remaining));
            return false;
        }
        if (ritual && ACTIVE.getOrDefault(level, List.of()).stream().anyMatch(s -> s.ritual && s.owner.equals(player.getUUID()))) {
            player.displayClientMessage(Component.translatable("message.flametalisman.ritual_active"), true);
            return false;
        }
        int cost = ritual ? 200 : 20;
        if (!player.getAbilities().instabuild && stack.getMaxDamage() - stack.getDamageValue() < ArtifactCosts.required(player,cost)) {
            player.displayClientMessage(Component.translatable("message.flametalisman.low_durability", ArtifactCosts.required(player,cost)), true);
            return false;
        }
        Vec3 origin = ritual ? new Vec3(player.getX(), Math.min(level.getMaxBuildHeight() - 8, player.getY() + 48), player.getZ())
                : player.getEyePosition().add(0, -0.35, 0);
        if(ritual){
            Vec3 ground=SpellAim.ground(player,64);
            if(ground==null){player.displayClientMessage(Component.translatable("message.flametalisman.intent_target"),true);return false;}
            origin=new Vec3(ground.x,Math.max(ground.y+8,Math.min(level.getMaxBuildHeight()-8,player.getY()+48)),ground.z);
        }
        BladeSpell spell = new BladeSpell(player, ritual, origin, player.getLookAngle(), ++nextId);
        ACTIVE.computeIfAbsent(level, ignored -> new ArrayList<>()).add(spell);
        if(ritual) {
            MagicAdvancements.grant(player,"fire_ritual");
            var persisted=player.getPersistentData().getCompound(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG);
            persisted.putLong("flametalismanSkyReadyTick",level.getServer().overworld().getGameTime()+BladeMath.RITUAL_COOLDOWN);
            player.getPersistentData().put(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG,persisted);
            SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new SpellNetwork.HandAnimation(player.getId(),3,BladeMath.RITUAL_COOLDOWN));
        }
        send(level, spell.packet(), null);
        if(ritual) SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new SpellNetwork.HandAnimation(player.getId(),0,BladeMath.CHARGE));
        stack.hurtAndBreak(cost, player, p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        if(!ritual)player.getCooldowns().addCooldown(stack.getItem(),10);
        player.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, player.blockPosition(), ritual ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BLAZE_SHOOT,
                SoundSource.PLAYERS, 2, ritual ? 0.6f : 0.7f);
        return true;
    }
    static void send(ServerLevel level, SpellNetwork.BladeEffect packet, ServerPlayer only) {
        if (only == null) SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), packet);
        else SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> only), packet);
    }
    private static int cooldownRemaining(ServerPlayer player) {
        long ready=player.getPersistentData().getCompound(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG).getLong("flametalismanSkyReadyTick");
        return (int)Math.min(BladeMath.RITUAL_COOLDOWN,Math.max(0,ready-player.serverLevel().getServer().overworld().getGameTime()));
    }
    @SubscribeEvent public static void tick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        List<BladeSpell> spells = ACTIVE.get(level);
        if (spells == null) return;
        spells.removeIf(s -> s.tick(level));
        if (spells.isEmpty()) ACTIVE.remove(level);
    }
    @SubscribeEvent public static void stopped(ServerStoppedEvent event) { ACTIVE.clear(); nextId = 0; }
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event) { sync(event); }
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event) { sync(event); }
    private static void sync(PlayerEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new SpellNetwork.HandAnimation(player.getId(),3,cooldownRemaining(player)));
            for (BladeSpell spell : ACTIVE.getOrDefault(player.serverLevel(), List.of())) {
                send(player.serverLevel(), spell.packet(), player);
                for (Orb orb : spell.orbs) send(player.serverLevel(), new SpellNetwork.BladeEffect(2, orb.id, orb.pos, Vec3.ZERO, orb.age,0,orb.fireAspect), player);
            }
        }
    }
    static final class BladeSpell {
        final UUID owner;
        final boolean ritual;
        final Vec3 origin, forward, side, normal;
        final int id, fireSeconds, casterEntityId,fireAspect,activeEnd,visualEnd;final double coverage;
        final float roll;
        final Set<UUID> hit = new HashSet<>();
        final List<Orb> orbs = new ArrayList<>();
        int age;
        BladeSpell(ServerPlayer player, boolean ritual, Vec3 origin, Vec3 forward, int id) {
            owner = player.getUUID(); this.ritual = ritual; this.origin = origin; this.forward = forward.normalize(); this.id = id;
            double yaw = Math.toRadians(player.getYRot());
            Vec3 horizontalSide = new Vec3(Math.cos(yaw), 0, Math.sin(yaw));
            Vec3 up = this.forward.cross(horizontalSide).normalize();
            roll=ritual?0:(float)Math.toRadians((player.getRandom().nextBoolean()?1:-1)*(15+player.getRandom().nextDouble()*65));
            side = horizontalSide.scale(Math.cos(roll)).add(up.scale(Math.sin(roll)));
            normal = this.forward.cross(side).normalize();
            coverage=ArtifactRange.radius(64,player.getMainHandItem());fireAspect=FlameBladeItem.fireLevel(player.getMainHandItem());fireSeconds = FlameBladeItem.fireSeconds(player.getMainHandItem());
            activeEnd=BladeMath.CHARGE+DurationMath.fireRain(fireAspect);visualEnd=activeEnd+DurationMath.SKY_FADE;casterEntityId = player.getId();
        }
        SpellNetwork.BladeEffect packet() { return new SpellNetwork.BladeEffect(ritual ? 1 : 0, id, origin, forward, age,roll,fireAspect,(float)coverage); }
        boolean tick(ServerLevel level) {
            ServerPlayer player = level.getServer().getPlayerList().getPlayer(owner);
            if (player == null || !player.isAlive() || player.serverLevel() != level) {
                send(level, new SpellNetwork.BladeEffect(4, id, origin, Vec3.ZERO, age), null);
                for (Orb orb : orbs) send(level, new SpellNetwork.BladeEffect(4, orb.id, orb.pos, Vec3.ZERO, 0), null);
                if(ritual) SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension),
                        new SpellNetwork.HandAnimation(casterEntityId,2,0));
                return true;
            }
            if (!ritual) { damageWave(level, player); return ++age >= BladeMath.WAVE_TICKS; }
            if (age < activeEnd && age % 20 == 0
                    && player.gameMode.getGameModeForPlayer() == net.minecraft.world.level.GameType.SURVIVAL)
                ArtifactCosts.health(player,true);
            if (age == BladeMath.CHARGE) {
                SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                        new SpellNetwork.HandAnimation(player.getId(),2,0));
                level.playSound(null, player.blockPosition(), SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 1.5f, 0.55f);
            }
            if (age>=BladeMath.CHARGE&&age<activeEnd) {
                for(int count=0;count<EnchantmentSpellMath.rainThisTick(age-BladeMath.CHARGE,fireAspect);count++)for (int attempt = 0; attempt < 6; attempt++) {
                    double angle = level.random.nextDouble() * Math.PI * 2;
                    double radius = Math.sqrt(level.random.nextDouble()) * coverage;
                    Vec3 pos = origin.add(Math.cos(angle) * radius, -0.6, Math.sin(angle) * radius);
                    if (!level.hasChunkAt(BlockPos.containing(pos))) continue;
                    Orb orb = new Orb(++nextId, pos,fireAspect);
                    orbs.add(orb);
                    send(level, new SpellNetwork.BladeEffect(2, orb.id, pos, Vec3.ZERO, 0,0,fireAspect), null);
                    break;
                }
            }
            orbs.removeIf(orb -> orb.tick(level, player, fireSeconds));
            return ++age >= visualEnd && orbs.isEmpty();
        }
        void damageWave(ServerLevel level, ServerPlayer player) {
            double previous = age * BladeMath.SPEED, current = Math.min(64, previous + BladeMath.SPEED);
            AABB bounds = new AABB(origin, origin).inflate(current + 3);
            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds,
                    e -> valid(e, owner) && !hit.contains(e.getUUID()))) {
                Vec3 delta = entity.getBoundingBox().getCenter().subtract(origin);
                double padding = Math.max(entity.getBbWidth(), entity.getBbHeight()) * 0.5;
                double f = delta.dot(forward), s = delta.dot(side), plane = Math.abs(delta.dot(normal));
                double radius = Math.hypot(f, s);
                if (f >= -padding && radius <= 64 + padding && radius + padding >= previous
                        && radius - padding <= current && plane <= 1.8 + padding) {
                    hit.add(entity.getUUID());
                    entity.setSecondsOnFire(fireSeconds);ArtifactExperience.hurt(entity,player.damageSources().playerAttack(player), 24+EnchantmentSpellMath.fireBonus(fireAspect));
                }
            }
        }
    }
    static boolean valid(LivingEntity entity, UUID owner) {
        return entity.isAlive() && !entity.isSpectator() && !entity.getUUID().equals(owner);
    }
    static void explode(ServerLevel level, ServerPlayer player, Vec3 pos, int fireSeconds, int id,int fireAspect) {
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(8), e -> valid(e, player.getUUID()))) {
            Vec3 center = entity.getBoundingBox().getCenter();
            double distance = center.distanceTo(pos);
            float damage = BladeMath.explosionDamage(distance)*(1+EnchantmentSpellMath.fireBonus(fireAspect)/30f);
            if (damage <= 0) continue;
            Vec3 start = pos.add(0, 0.25, 0);
            entity.setSecondsOnFire(fireSeconds);ArtifactExperience.hurt(entity,player.damageSources().playerAttack(player), damage);
            Vec3 push = center.subtract(pos).normalize().scale(0.75 * (1 - distance / 8));
            entity.push(push.x, Math.max(0.12, push.y), push.z);
        }
        send(level, new SpellNetwork.BladeEffect(3, id, pos, Vec3.ZERO, 0), null);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.4f, 0.7f + level.random.nextFloat() * 0.25f);
    }
    static void explode(ServerLevel level,ServerPlayer player,Vec3 pos,int fireSeconds,int id){explode(level,player,pos,fireSeconds,id,FlameBladeItem.fireLevel(player.getMainHandItem()));}
    static final class Orb {
        final int id,fireAspect;
        final Set<UUID> struck = new HashSet<>();
        Vec3 pos;
        int age;
        Orb(int id, Vec3 pos,int fireAspect) { this.id = id; this.pos = pos;this.fireAspect=fireAspect; }
        Orb(int id,Vec3 pos){this(id,pos,0);}
        boolean tick(ServerLevel level, ServerPlayer player, int fireSeconds) {
            if (!level.hasChunkAt(BlockPos.containing(pos))) {
                send(level, new SpellNetwork.BladeEffect(4, id, pos, Vec3.ZERO, 0), null); return true;
            }
            Vec3 next = pos.add(0, -BladeMath.orbFall(age), 0);
            // A swept vertical cylinder hits through roofs without consuming the orb.
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(pos,next).inflate(8,0,8),e->valid(e,player.getUUID())&&!struck.contains(e.getUUID()))){
                Vec3 center=target.getBoundingBox().getCenter();
                double distance=Math.hypot(center.x-pos.x,center.z-pos.z);
                float damage=BladeMath.explosionDamage(distance)*(1+EnchantmentSpellMath.fireBonus(fireAspect)/30f);
                if(damage<=0)continue;
                struck.add(target.getUUID());target.setSecondsOnFire(fireSeconds);ArtifactExperience.hurt(target,player.damageSources().playerAttack(player),damage);
                Vec3 outward=new Vec3(center.x-pos.x,0,center.z-pos.z).normalize().scale(.75*(1-distance/8));
                target.push(outward.x,.12,outward.z);
            }
            for(net.minecraft.world.entity.item.ItemEntity item:level.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,new AABB(pos,next).inflate(8,0,8))){
                if(Math.hypot(item.getX()-pos.x,item.getZ()-pos.z)<=8)item.discard();
            }
            for(int y=(int)Math.floor(pos.y);y>=Math.max(level.getMinBuildHeight(),(int)Math.floor(next.y));y--){
                BlockPos block=BlockPos.containing(pos.x,y,pos.z);
                if(level.getBlockState(block).getCollisionShape(level,block).isEmpty())continue;
                BlockPos above=block.above();
                if(!level.getBlockState(above).getCollisionShape(level,above).isEmpty())continue;
                double top=y+level.getBlockState(block).getCollisionShape(level,block).max(net.minecraft.core.Direction.Axis.Y);
                if(top>pos.y||top<=next.y)continue;
                Vec3 impact=new Vec3(pos.x,top+.05,pos.z);
                // A distinct ID keeps the falling orb alive in the client visual map.
                send(level,new SpellNetwork.BladeEffect(3,++nextId,impact,Vec3.ZERO,0),null);
                level.playSound(null,impact.x,impact.y,impact.z,SoundEvents.GENERIC_EXPLODE,SoundSource.PLAYERS,.9f,.8f);
                if(level.random.nextFloat()<.20f){
                    BlockPos firePos=block.above();
                    var fire=net.minecraft.world.level.block.BaseFireBlock.getState(level,firePos);
                    if(level.getBlockState(firePos).isAir()&&fire.canSurvive(level,firePos))level.setBlockAndUpdate(firePos,fire);
                }
            }
            pos = next;
            if (++age > 180 || pos.y < level.getMinBuildHeight()) {
                send(level, new SpellNetwork.BladeEffect(4, id, pos, Vec3.ZERO, 0), null); return true;
            }
            return false;
        }
    }
}















