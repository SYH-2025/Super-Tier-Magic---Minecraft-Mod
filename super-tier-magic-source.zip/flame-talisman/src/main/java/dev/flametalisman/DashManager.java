package dev.flametalisman;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID)
public final class DashManager {
    private static final Map<UUID, Dash> ACTIVE = new HashMap<>();
    private static int effectId = -1;
    private static final ResourceKey<DamageType> FIRE_THRUST = ResourceKey.create(Registries.DAMAGE_TYPE,
            new ResourceLocation(FlameTalisman.MOD_ID,"flame_thrust"));
    public static boolean cast(ServerPlayer player) {
        var stack=player.getMainHandItem();
        if(!player.isAlive() || player.isSpectator() || !player.isShiftKeyDown()
                || !stack.is(FlameTalisman.BLADE.get()) || player.getCooldowns().isOnCooldown(stack.getItem())
                || ACTIVE.containsKey(player.getUUID())) return false;
        double yaw=Math.toRadians(player.getYRot());
        Vec3 direction=new Vec3(-Math.sin(yaw),0,Math.cos(yaw));
        int fire=4+4*EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FIRE_ASPECT,stack);
        ACTIVE.put(player.getUUID(),new Dash(direction,fire,player.serverLevel().dimension(),EnchantmentSpellMath.fireBonus(FlameBladeItem.fireLevel(stack))));
        player.getCooldowns().addCooldown(stack.getItem(),20);
        stack.hurtAndBreak(1,player,p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new SpellNetwork.HandAnimation(player.getId(),1,12));
        BladeSpellManager.send(player.serverLevel(),new SpellNetwork.BladeEffect(6,effectId--,player.position(),direction,0),null);
        player.serverLevel().playSound(null,player.blockPosition(),SoundEvents.TRIDENT_THROW,SoundSource.PLAYERS,1.1f,1.25f);
        return true;
    }
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !(event.player instanceof ServerPlayer player))return;
        Dash dash=ACTIVE.get(player.getUUID());
        if(dash==null)return;
        if(dash.tick(player))ACTIVE.remove(player.getUUID());
    }
    @SubscribeEvent public static void logout(net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent event) {
        ACTIVE.remove(event.getEntity().getUUID());
    }
    @SubscribeEvent public static void stopped(ServerStoppedEvent event) { ACTIVE.clear();effectId=-1; }
    private static final class Dash {
        final Vec3 direction;
        final int fire,bonus;
        final ResourceKey<net.minecraft.world.level.Level> dimension;
        final Set<UUID> hit=new HashSet<>();
        int age;
        Dash(Vec3 direction,int fire,ResourceKey<net.minecraft.world.level.Level> dimension,int bonus){this.bonus=bonus;this.direction=direction;this.fire=fire;this.dimension=dimension;}
        boolean tick(ServerPlayer player) {
            if(!player.isAlive() || player.isSpectator() || player.serverLevel().dimension()!=dimension)return true;
            if(age++<2)return false;
            Vec3 before=player.position();
            Vec3 step=direction.scale(BladeMath.DASH_SPEED);
            var level=player.serverLevel();
            BlockPos next=BlockPos.containing(before.add(step));
            if(!level.hasChunkAt(next)|| !level.getWorldBorder().isWithinBounds(next))return true;
            AABB swept=player.getBoundingBox().expandTowards(step).expandTowards(direction.scale(2.2)).inflate(0.55,0.15,0.55);
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,swept,
                    e -> BladeSpellManager.valid(e,player.getUUID())&&!hit.contains(e.getUUID()))) {
                Vec3 delta=target.getBoundingBox().getCenter().subtract(player.getBoundingBox().getCenter());
                if(delta.dot(direction)<-0.2)continue;
                if(level.clip(new ClipContext(player.getEyePosition(),target.getEyePosition(),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player)).getType()!=HitResult.Type.MISS)continue;
                DamageSource source=new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(FIRE_THRUST),player,player);
                hit.add(target.getUUID());
                target.setSecondsOnFire(fire);ArtifactExperience.hurt(target,source,20+bonus);
            }
            player.move(MoverType.SELF,step);
            player.setDeltaMovement(Vec3.ZERO);
            player.fallDistance=0;
            player.connection.teleport(player.getX(),player.getY(),player.getZ(),player.getYRot(),player.getXRot());
            boolean finished=age>=2+BladeMath.DASH_TICKS || player.position().distanceToSqr(before)<0.0025;
            if(finished){
                // Resolve from the actual endpoint after movement, extending only in front.
                Vec3 base=player.getBoundingBox().getCenter(),tip=base.add(direction.scale(5));
                AABB front=new AABB(base,tip).inflate(1.8,1.3,1.8);
                for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,front,e->BladeSpellManager.valid(e,player.getUUID())&&!hit.contains(e.getUUID()))){
                    Vec3 delta=target.getBoundingBox().getCenter().subtract(base);double along=delta.dot(direction);
                    double side=Math.abs(delta.x*direction.z-delta.z*direction.x);
                    if(along<0||along>5+target.getBbWidth()*0.5||side>1.8+target.getBbWidth()*0.5)continue;
                    if(level.clip(new ClipContext(player.getEyePosition(),target.getEyePosition(),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player)).getType()!=HitResult.Type.MISS)continue;
                    hit.add(target.getUUID());DamageSource source=new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(FIRE_THRUST),player,player);
                    target.setSecondsOnFire(fire);ArtifactExperience.hurt(target,source,20+bonus);
                }
                BladeSpellManager.send(level,new SpellNetwork.BladeEffect(6,effectId--,player.position(),direction,0),null);
            }
            return finished;
        }
    }
}




