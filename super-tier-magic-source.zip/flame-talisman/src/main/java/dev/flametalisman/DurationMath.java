package dev.flametalisman;
/** Enchantments extend active phases; charge times and visual fade are independent. */
public final class DurationMath {
    public static final int SKY_FADE=120;
    public static int extend(int ticks,int level,int maximum){return (int)Math.round(ticks*(1+.667*Math.max(0,Math.min(maximum,level))/(double)maximum));}
    public static int fireRain(int level){return extend(300,level,20);}
    public static int thunderRain(int level){return extend(300,level,5);}
    public static int domain(int level){return extend(300,level,5);}
    public static int fall(int level){return extend(100,level,5);}
    public static double flightRate(int level,int free){return level>=free?0:level<=10?1:Math.max(0,(free-level)/(double)Math.max(1,free-10));}
    private DurationMath(){}
}
