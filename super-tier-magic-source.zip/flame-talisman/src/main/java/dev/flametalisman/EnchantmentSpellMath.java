package dev.flametalisman;
public final class EnchantmentSpellMath {
    public static int fire(int level){return Math.max(0,Math.min(20,level));}
    public static int sharp(int level){return Math.max(0,Math.min(5,level));}
    public static int fireBonus(int level){return 2*fire(level);}
    public static int rainThisTick(int tick,int level){int n=40+3*fire(level);return (tick+1)*n/40-tick*n/40;}
    public static int range(int level){return (int)Math.round(32+96*sharp(level)/5.0);}
    public static int rays(int level){return 65+40*sharp(level);}
    public static int ghosts(int level){return 123+24*sharp(level);}
    public static int directBonus(int level){return 3*sharp(level);}
    public static double swordAttributeBonus(int level){int n=sharp(level);return n>0?3*n-(n*.5+.5):0;}
    public static int skyBonus(int level){return 7*sharp(level);}
    public static int domainBonus(int level){return 5*sharp(level);}
    public static double opacity(int level){return .82+.03*sharp(level);}
    public static double percentMultiplier(int level){return 1+.1*sharp(level);}
    private EnchantmentSpellMath(){}
}
