package dev.flametalisman;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public final class FlameBladeItem extends SwordItem {
    // Diamond tier contributes 3 attack damage; modifier 4 + player base 1 = 8.
    public FlameBladeItem() { super(Tiers.DIAMOND, 4, -2.4f, new Item.Properties().fireResistant()); }
    public static int fireLevel(ItemStack stack){return EnchantmentSpellMath.fire(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FIRE_ASPECT,stack));}
    @Override public com.google.common.collect.Multimap<net.minecraft.world.entity.ai.attributes.Attribute,net.minecraft.world.entity.ai.attributes.AttributeModifier> getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot slot,ItemStack stack){var attributes=com.google.common.collect.HashMultimap.create(super.getAttributeModifiers(slot,stack));if(slot==net.minecraft.world.entity.EquipmentSlot.MAINHAND&&fireLevel(stack)>0)attributes.put(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE,new net.minecraft.world.entity.ai.attributes.AttributeModifier(java.util.UUID.fromString("c248e7fc-f081-4c11-a291-438d54811460"),"Flame mastery",EnchantmentSpellMath.fireBonus(fireLevel(stack)),net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));return attributes;}
    @Override public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
        consumer.accept(new dev.flametalisman.client.BladeClientExtension());
    }
    public static int fireSeconds(ItemStack stack) {
        return 7 + 4 * EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FIRE_ASPECT, stack);
    }
    @Override public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.setSecondsOnFire(fireSeconds(stack));
        return super.hurtEnemy(stack, target, attacker);
    }
    private static boolean allowed(Enchantment e) {
        return e == Enchantments.UNBREAKING || e == Enchantments.MENDING || e == Enchantments.FIRE_ASPECT;
    }
    @Override public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment e) { return allowed(e); }
    @Override public boolean isBookEnchantable(ItemStack stack, ItemStack book) {
        return EnchantmentHelper.getEnchantments(book).keySet().stream().allMatch(FlameBladeItem::allowed);
    }
    @Override public <T extends net.minecraft.world.entity.LivingEntity> int damageItem(ItemStack stack,int amount,T entity,java.util.function.Consumer<T> onBroken){return ArtifactCosts.damage(entity,amount);}
    @Override public void appendHoverText(ItemStack stack,@Nullable Level level,List<Component> lines,TooltipFlag flag){ItemLegend.append(lines,"flame_blade");}
}

