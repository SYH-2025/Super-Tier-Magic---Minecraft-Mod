package dev.flametalisman;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class FlameCombat {
    @SubscribeEvent public static void ignite(LivingAttackEvent event){
        if(event.getAmount()>0&&!ArtifactExperience.isSkillSource(event.getSource())&&event.getSource().getEntity() instanceof ServerPlayer player
                &&event.getSource().getDirectEntity()==player&&player.getMainHandItem().is(FlameTalisman.BLADE.get()))
            event.getEntity().setSecondsOnFire(FlameBladeItem.fireSeconds(player.getMainHandItem()));
    }
    private FlameCombat(){}
}
