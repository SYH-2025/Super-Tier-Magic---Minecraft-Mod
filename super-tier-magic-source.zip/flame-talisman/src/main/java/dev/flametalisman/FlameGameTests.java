package dev.flametalisman;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import java.util.Map;
import java.util.UUID;

/** Run only with the Forge GameTest namespace enabled; exercises real Minecraft objects. */
@GameTestHolder(FlameTalisman.MOD_ID)
@PrefixGameTestTemplate(false)
public final class FlameGameTests {
    private static FakePlayer player(GameTestHelper h, Vec3 pos) {
        FakePlayer p = FakePlayerFactory.get(h.getLevel(), new GameProfile(UUID.randomUUID(), "FlameTest"));
        Vec3 world = h.absoluteVec(pos);
        p.setPos(world.x, world.y, world.z);
        p.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(FlameTalisman.TALISMAN.get()));
        return p;
    }
    private static Cow cow(GameTestHelper h, Vec3 pos) {
        Cow cow = EntityType.COW.create(h.getLevel());
        Vec3 world = h.absoluteVec(pos);
        cow.setPos(world.x, world.y, world.z);
        cow.setNoAi(true);
        cow.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);
        cow.setHealth(100);
        h.getLevel().addFreshEntity(cow);
        return cow;
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void itemAndRecipe(GameTestHelper h) {
        ItemStack stack = new ItemStack(FlameTalisman.TALISMAN.get());
        h.assertTrue(stack.getMaxDamage() == 27 && stack.getMaxStackSize() == 1, "27 durability, unstackable");
        h.assertTrue(stack.getItem().canApplyAtEnchantingTable(stack, Enchantments.UNBREAKING), "Unbreaking supported");
        h.assertTrue(stack.getItem().canApplyAtEnchantingTable(stack, Enchantments.MENDING), "Mending supported");
        h.assertTrue(!stack.getItem().canApplyAtEnchantingTable(stack, Enchantments.SHARPNESS), "Sharpness rejected");
        ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
        EnchantmentHelper.setEnchantments(Map.of(Enchantments.MENDING, 1), book);
        h.assertTrue(stack.getItem().isBookEnchantable(stack, book), "Mending book accepted");
        EnchantmentHelper.setEnchantments(Map.of(Enchantments.SHARPNESS, 1), book);
        h.assertTrue(!stack.getItem().isBookEnchantable(stack, book), "Unrelated book rejected");
        AbstractContainerMenu menu = new AbstractContainerMenu(MenuType.CRAFTING, 0) {
            @Override public ItemStack quickMoveStack(Player p, int slot) { return ItemStack.EMPTY; }
            @Override public boolean stillValid(Player p) { return true; }
        };
        CraftingContainer grid = new TransientCraftingContainer(menu, 3, 3);
        for (int slot = 0; slot < 9; slot++) grid.setItem(slot, new ItemStack(Items.BLAZE_POWDER));
        h.assertTrue(h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, grid, h.getLevel()).isEmpty(), "old nine powder recipe removed");
        grid.setItem(4, new ItemStack(Items.PAPER));
        for(int slot:new int[]{0,2,6,8})grid.setItem(slot,new ItemStack(Items.GOLD_BLOCK));
        var recipe = h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, grid, h.getLevel());
        h.assertTrue(recipe.isPresent() && recipe.get().assemble(grid, h.getLevel().registryAccess()).is(FlameTalisman.TALISMAN.get()), "four gold blocks, four powders and center paper recipe");
        grid.setItem(4, ItemStack.EMPTY);
        var incomplete = h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING, grid, h.getLevel());
        h.assertTrue(incomplete.isEmpty() || !incomplete.get().assemble(grid, h.getLevel().registryAccess()).is(FlameTalisman.TALISMAN.get()), "eight powder cannot craft");
        h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void bladeItemRecipeAndFire(GameTestHelper h) {
        ItemStack blade = new ItemStack(FlameTalisman.BLADE.get());
        h.assertTrue(blade.getMaxDamage() == new ItemStack(Items.DIAMOND_SWORD).getMaxDamage(), "diamond sword durability");
        h.assertTrue(((FlameBladeItem)blade.getItem()).getDamage() + 1 == 8, "8 total melee attack damage");
        h.assertTrue(blade.getItem().canApplyAtEnchantingTable(blade, Enchantments.FIRE_ASPECT), "fire aspect accepted");
        h.assertTrue(!blade.getItem().canApplyAtEnchantingTable(blade, Enchantments.SHARPNESS), "sharpness rejected");
        h.assertTrue(FlameBladeItem.fireSeconds(blade) == 7, "base burning seven seconds");
        blade.enchant(Enchantments.FIRE_ASPECT, 2);
        h.assertTrue(FlameBladeItem.fireSeconds(blade) == 15, "fire aspect II adds eight seconds");
        FakePlayer p = player(h, new Vec3(5,3,5));
        Cow target = cow(h, new Vec3(6,3,5));
        blade.getItem().hurtEnemy(blade,target,p);
        h.assertTrue(target.getRemainingFireTicks() == 300 && blade.getDamageValue() == 1, "melee burning and vanilla sword durability");
        AbstractContainerMenu menu = new AbstractContainerMenu(MenuType.CRAFTING,0) {
            @Override public ItemStack quickMoveStack(Player p,int slot){return ItemStack.EMPTY;}
            @Override public boolean stillValid(Player p){return true;}
        };
        CraftingContainer grid = new TransientCraftingContainer(menu,3,3);
        for(int i=0;i<9;i++) grid.setItem(i,new ItemStack(FlameTalisman.TALISMAN.get()));
        grid.setItem(4,new ItemStack(Items.DIAMOND_SWORD));
        var recipe = h.getLevel().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,grid,h.getLevel());
        h.assertTrue(recipe.isPresent() && recipe.get().assemble(grid,h.getLevel().registryAccess()).is(FlameTalisman.BLADE.get()), "eight talismans and diamond sword recipe");
        target.discard(); h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void tiltedWaveDamage(GameTestHelper h) {
        FakePlayer p = player(h,new Vec3(5,3,5));
        p.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(FlameTalisman.BLADE.get()));
        Vec3 origin = h.absoluteVec(new Vec3(5,3,5));
        Cow inPlane = cow(h,new Vec3(5,5,5));
        Cow outOfPlane = cow(h,new Vec3(5,3,10));
        BladeSpellManager.BladeSpell wave = new BladeSpellManager.BladeSpell(p,false,origin,new Vec3(0,1,0),100);
        wave.damageWave(h.getLevel(),p);
        h.assertTrue(inPlane.getHealth() == 76 && inPlane.getRemainingFireTicks() == 140, "tilted wave deals 24 and burns seven seconds");
        h.assertTrue(outOfPlane.getHealth() == 100, "outside tilted plane is not hit");
        inPlane.invulnerableTime=0;
        wave.damageWave(h.getLevel(),p);
        h.assertTrue(inPlane.getHealth()==76,"blade wave hits once");
        inPlane.discard(); outOfPlane.discard(); h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void bladeCastCosts(GameTestHelper h) {
        FakePlayer p=player(h,new Vec3(5,3,5));
        ItemStack blade=new ItemStack(FlameTalisman.BLADE.get());
        p.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,blade);
        h.assertTrue(!BladeSpellManager.cast(p,false),"non-sneak cannot cast");
        p.setShiftKeyDown(true);
        h.assertTrue(BladeSpellManager.cast(p,false) && blade.getDamageValue()==20,"wave costs 20");
        p.getCooldowns().removeCooldown(blade.getItem());
        h.assertTrue(BladeSpellManager.cast(p,true) && blade.getDamageValue()==220,"ritual costs 200");
        p.getCooldowns().removeCooldown(blade.getItem());
        h.assertTrue(!BladeSpellManager.cast(p,true) && blade.getDamageValue()==220,"cannot stack own ritual");
        blade.setDamageValue(blade.getMaxDamage()-19);
        h.assertTrue(!BladeSpellManager.cast(p,false),"low durability blocks wave");
        h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void meteorFalloffAndHealthFloor(GameTestHelper h) {
        FakePlayer p=player(h,new Vec3(5,3,5));
        Cow near=cow(h,new Vec3(6,3,5));
        Cow far=cow(h,new Vec3(11,3,5));
        BladeSpellManager.explode(h.getLevel(),p,h.absoluteVec(new Vec3(5,3.5,5)),7,200);
        h.assertTrue(near.getHealth()<far.getHealth() && near.getHealth()<100 && far.getHealth()<100,"meteor damage falls with distance");
        h.assertTrue(near.getRemainingFireTicks()==140 && far.getRemainingFireTicks()==140,"meteor burns both targets");
        float health=20;
        for(int i=0;i<40;i++) health=BladeMath.drainedHealth(health,20);
        h.assertTrue(health==4,"drain stops at 20 percent");
        h.assertTrue(BladeMath.drainedHealth(3,20)==3,"drain never heals player below floor");
        near.discard();far.discard();h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void waveDamageAndExclusion(GameTestHelper h) {
        FakePlayer p = player(h, new Vec3(5, 3, 5));
        Cow front = cow(h, new Vec3(5, 3, 6.5));
        Cow behind = cow(h, new Vec3(5, 3, 3.5));
        SpellManager.Spell wave = new SpellManager.Spell(p, false, p.position().add(0, 0.9, 0), 0);
        wave.damageWave(h.getLevel(), p);
        h.assertTrue(front.getHealth() == 90, "talisman wave inflicts exactly 10 raw damage");
        h.assertTrue(front.getRemainingFireTicks() == 100, "five seconds burning");
        h.assertTrue(behind.getHealth() == 100, "behind caster stays safe");
        front.invulnerableTime = 0;
        wave.damageWave(h.getLevel(), p);
        h.assertTrue(front.getHealth() == 90, "each wave hits a target once");
        front.discard(); behind.discard(); h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void rainDamageAndRoof(GameTestHelper h) {
        FakePlayer p = player(h, new Vec3(5, 3, 5));
        Cow exposed = cow(h, new Vec3(6, 3, 5));
        Cow sheltered = cow(h, new Vec3(8, 3, 5));
        h.setBlock(new BlockPos(8, 6, 5), Blocks.STONE);
        SpellManager.Spell rain = new SpellManager.Spell(p, true, p.position(), 0);
        rain.damageRain(h.getLevel(), p);
        h.assertTrue(exposed.getHealth() == 90 && exposed.getRemainingFireTicks() == 100, "talisman rain damage and burning");
        h.assertTrue(sheltered.getHealth() == 100, "solid roof shields target");
        exposed.discard(); sheltered.discard(); h.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 20)
    public static void castValidationAndDurability(GameTestHelper h) {
        FakePlayer p = player(h, new Vec3(5.5, 3, 5.5));
        p.setYRot(0); p.setXRot(-90);
        h.assertTrue(!SpellManager.cast(p, true), "sky targeting is invalid");
        h.assertTrue(p.getMainHandItem().getDamageValue() == 0, "invalid cast is free");
        h.setBlock(new BlockPos(5, 1, 5), Blocks.STONE);
        p.setXRot(90);
        h.assertTrue(SpellManager.cast(p, true), "ground target accepted");
        h.assertTrue(p.getMainHandItem().getDamageValue() == 1, "valid right cast costs one");
        h.assertTrue(!SpellManager.cast(p, false), "packet spam blocked during short cooldown");
        p.getCooldowns().removeCooldown(FlameTalisman.TALISMAN.get());
        h.assertTrue(SpellManager.cast(p, false), "left cast accepted");
        h.assertTrue(p.getMainHandItem().getDamageValue() == 2, "left cast costs one");
        h.succeed();
    }
}
