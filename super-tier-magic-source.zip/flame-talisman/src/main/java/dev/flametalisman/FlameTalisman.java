package dev.flametalisman;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(FlameTalisman.MOD_ID)
public final class FlameTalisman {
    public static final String MOD_ID = "flametalisman";
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    private static final DeferredRegister<net.minecraft.world.effect.MobEffect> EFFECTS=DeferredRegister.create(ForgeRegistries.MOB_EFFECTS,MOD_ID);
    private static final DeferredRegister<net.minecraft.core.particles.ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, MOD_ID);
    public static final RegistryObject<Item> TALISMAN = ITEMS.register("flame_talisman", TalismanItem::new);
    public static final RegistryObject<Item> BLADE = ITEMS.register("flame_blade", FlameBladeItem::new);
    public static final RegistryObject<Item> LIGHTNING_SHARD = ITEMS.register("lightning_shard", () -> new LightningItem(false));
    public static final RegistryObject<Item> LIGHTNING_TALISMAN = ITEMS.register("lightning_talisman", () -> new LightningItem(true));
    public static final RegistryObject<Item> THUNDER_BLADE = ITEMS.register("thunderclap_blade", ThunderBladeItem::new);
    public static final RegistryObject<Item> SWORD_INTENT=ITEMS.register("sword_intent",SwordIntentItem::new);
    public static final RegistryObject<Item> AIR_TALISMAN=ITEMS.register("air_talisman",AirTalismanItem::new);
    public static final RegistryObject<net.minecraft.world.effect.MobEffect> SWORD_QI=EFFECTS.register("sword_qi",SwordQiEffect::new);
    public static final RegistryObject<SimpleParticleType> GOLD_FLAME = PARTICLES.register("gold_flame", () -> new SimpleParticleType(true));

    public FlameTalisman() {
        net.minecraftforge.fml.ModLoadingContext.get().registerConfig(net.minecraftforge.fml.config.ModConfig.Type.COMMON,ArtifactConfig.SPEC,"super-tier-magic-common.toml");
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        EFFECTS.register(bus);
        PARTICLES.register(bus);
        bus.addListener(this::creativeTab);
        SpellNetwork.register();
    }

    private void creativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(TALISMAN);event.accept(BLADE);event.accept(LIGHTNING_SHARD);event.accept(LIGHTNING_TALISMAN);event.accept(THUNDER_BLADE);event.accept(SWORD_INTENT);event.accept(AIR_TALISMAN);
        }
    }
}

