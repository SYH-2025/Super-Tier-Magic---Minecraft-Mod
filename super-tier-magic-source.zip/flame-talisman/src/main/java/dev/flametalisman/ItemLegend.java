package dev.flametalisman;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
public final class ItemLegend {
    public static void append(List<Component> lines,String item){if(!ArtifactConfig.LORE.get())return;for(int i=1;i<=3;i++)lines.add(Component.translatable("lore.flametalisman."+item+"."+i).withStyle(ChatFormatting.GRAY,ChatFormatting.ITALIC));}
    private ItemLegend(){}
}
