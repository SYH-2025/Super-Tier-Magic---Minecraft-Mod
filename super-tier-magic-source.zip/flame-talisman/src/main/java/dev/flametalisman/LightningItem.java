package dev.flametalisman;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public final class LightningItem extends Item {
    private final boolean talisman;
    public LightningItem(boolean talisman) {
        super(talisman?new Item.Properties().durability(27):new Item.Properties().fireResistant());
        this.talisman=talisman;
    }
    @Override public int getEnchantmentValue(){return talisman?15:0;}
    @Override public boolean canBeHurtBy(net.minecraft.world.damagesource.DamageSource source){return !(!talisman&&source.is(net.minecraft.world.damagesource.DamageTypes.LIGHTNING_BOLT))&&super.canBeHurtBy(source);}
    @Override public boolean canApplyAtEnchantingTable(ItemStack stack,Enchantment e) {
        return talisman&&(e==Enchantments.UNBREAKING||e==Enchantments.MENDING);
    }
    @Override public boolean isBookEnchantable(ItemStack stack,ItemStack book) {
        return talisman&&EnchantmentHelper.getEnchantments(book).keySet().stream().allMatch(e->e==Enchantments.UNBREAKING||e==Enchantments.MENDING);
    }
    @Override public <T extends net.minecraft.world.entity.LivingEntity> int damageItem(ItemStack stack,int amount,T entity,java.util.function.Consumer<T> onBroken){return ArtifactCosts.damage(entity,amount);}
    @Override public void appendHoverText(ItemStack stack,@Nullable Level level,List<Component> lines,TooltipFlag flag){ItemLegend.append(lines,talisman?"lightning_talisman":"lightning_shard");}
}

