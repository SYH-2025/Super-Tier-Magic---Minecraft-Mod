package dev.flametalisman;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class MagicAdvancements {
    private static final String[] ITEMS={"flame_talisman","flame_blade","lightning_shard","lightning_talisman","thunderclap_blade","sword_intent","air_talisman"};
    private static final String[] SPELLS={"fire_ritual","thunder_ritual","abyss","celestial_sword","sword_domain","air_vortex","air_push","level_100"};
    private static void acquired(ServerPlayer player,net.minecraft.world.item.ItemStack stack){
        for(String id:ITEMS)if(stack.is(net.minecraftforge.registries.ForgeRegistries.ITEMS.getValue(new ResourceLocation(FlameTalisman.MOD_ID,id)))){
            grant(player,"root");grant(player,"get_"+id);break;
        }
    }
    @SubscribeEvent public static void crafted(PlayerEvent.ItemCraftedEvent event){if(event.getEntity() instanceof ServerPlayer player)acquired(player,event.getCrafting());}
    @SubscribeEvent public static void pickup(PlayerEvent.ItemPickupEvent event){if(event.getEntity() instanceof ServerPlayer player)acquired(player,event.getStack());}
    public static void grant(ServerPlayer player,String name){
        var advancement=player.server.getAdvancements().getAdvancement(new ResourceLocation(FlameTalisman.MOD_ID,name));
        if(advancement==null)return;
        var progress=player.getAdvancements().getOrStartProgress(advancement);
        if(progress.isDone()){player.getPersistentData().remove("stmAdvPending:"+name);return;}
        var parent=advancement.getParent();
        if(parent!=null&&!player.getAdvancements().getOrStartProgress(parent).isDone()){
            player.getPersistentData().putBoolean("stmAdvPending:"+name,true);return;
        }
        for(String criterion:progress.getRemainingCriteria())player.getAdvancements().award(advancement,criterion);
        player.getPersistentData().remove("stmAdvPending:"+name);
    }
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event){
        if(event.phase!=TickEvent.Phase.END||!(event.player instanceof ServerPlayer player)||player.tickCount%20!=0)return;
        var inventory=player.getInventory();
        for(String id:ITEMS){
            var item=net.minecraftforge.registries.ForgeRegistries.ITEMS.getValue(new ResourceLocation(FlameTalisman.MOD_ID,id));
            for(int slot=0;slot<inventory.getContainerSize();slot++)if(inventory.getItem(slot).is(item)){
                grant(player,"root");grant(player,"get_"+id);break;
            }
        }
        if(player.experienceLevel>=100)grant(player,"level_100");
        for(String id:ITEMS)if(player.getPersistentData().getBoolean("stmAdvPending:get_"+id))grant(player,"get_"+id);
        for(String id:SPELLS)if(player.getPersistentData().getBoolean("stmAdvPending:"+id))grant(player,id);
    }
    private MagicAdvancements(){}
}
