package dev.flametalisman;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;

/** Snapshot the ground under the initial crosshair hit; a miss never targets the caster. */
public final class SpellAim {
    public static Vec3 ground(ServerPlayer player,double range){
        var level=player.serverLevel();Vec3 eye=player.getEyePosition();
        BlockHitResult aim=level.clip(new ClipContext(eye,eye.add(player.getLookAngle().scale(range)),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player));
        if(aim.getType()!=HitResult.Type.BLOCK||!level.hasChunkAt(aim.getBlockPos()))return null;
        BlockPos block=aim.getBlockPos();
        BlockHitResult ground=level.clip(new ClipContext(new Vec3(block.getX()+0.5,block.getY()+1.01,block.getZ()+0.5),new Vec3(block.getX()+0.5,block.getY()-8,block.getZ()+0.5),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player));
        return ground.getType()==HitResult.Type.BLOCK?ground.getLocation().add(0,0.04,0):null;
    }
    private SpellAim(){}
}
