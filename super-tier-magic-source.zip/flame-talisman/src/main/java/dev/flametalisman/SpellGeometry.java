package dev.flametalisman;

/** Shared deterministic geometry and timing, in blocks and game ticks. */
public final class SpellGeometry {
    public static final double WAVE_RANGE = 16;
    public static final double WAVE_SPEED = 1;
    public static final int WAVE_TICKS = 16;
    public static final double RAIN_RADIUS = 8;
    public static final int CHARGE_TICKS = 80;
    public static final int RAIN_TICKS = 120;
    public static final int HIT_INTERVAL = 20;
    public static final int CAST_COOLDOWN = 6;
    private SpellGeometry() {}

    public static boolean inWave(double forward, double side, double previous, double current, double padding) {
        double distance = Math.hypot(forward, side);
        return forward >= -padding && distance <= WAVE_RANGE + padding
                && distance + padding >= previous && distance - padding <= current;
    }
    public static boolean inRain(double dx, double dz, double padding) {
        return Math.hypot(dx, dz) <= RAIN_RADIUS + padding;
    }
}
