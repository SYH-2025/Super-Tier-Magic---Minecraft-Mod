package dev.flametalisman;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID)
public final class SpellManager {
    private static final Map<ServerLevel, List<Spell>> ACTIVE = new IdentityHashMap<>();
    private SpellManager() {}

    public static boolean cast(ServerPlayer player, boolean rain) {
        ItemStack stack = player.getMainHandItem();
        if (!player.isAlive() || player.isSpectator() || !stack.is(FlameTalisman.TALISMAN.get())
                || player.getCooldowns().isOnCooldown(stack.getItem())) return false;
        ServerLevel level = player.serverLevel();
        int cost=rain?3:1;
        if(!player.getAbilities().instabuild&&stack.getMaxDamage()-stack.getDamageValue()<ArtifactCosts.required(player,cost)){player.displayClientMessage(Component.translatable("message.flametalisman.low_durability",ArtifactCosts.required(player,cost)),true);return false;}
        Vec3 origin;
        if (rain) {
            Vec3 eye = player.getEyePosition();
            BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(player.getLookAngle().scale(32)),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (hit.getType() != HitResult.Type.BLOCK || hit.getDirection() != Direction.UP
                    || eye.distanceToSqr(hit.getLocation()) > 32 * 32
                    || !level.hasChunkAt(hit.getBlockPos())) {
                player.displayClientMessage(Component.translatable("message.flametalisman.invalid_target"), true);
                return false;
            }
            origin = hit.getLocation().add(0, 0.035, 0);
        } else {
            origin = player.position().add(0, 0.9, 0);
        }
        Spell spell = new Spell(player, rain, origin, player.getYRot());
        ACTIVE.computeIfAbsent(level, ignored -> new ArrayList<>()).add(spell);
        broadcast(level, spell, null);
        stack.hurtAndBreak(rain?3:1, player, p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        player.getCooldowns().addCooldown(FlameTalisman.TALISMAN.get(), SpellGeometry.CAST_COOLDOWN);
        player.swing(InteractionHand.MAIN_HAND, true);
        level.playSound(null, origin.x, origin.y, origin.z,
                rain ? SoundEvents.EVOKER_PREPARE_SUMMON : SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.2f, rain ? 0.75f : 1.15f);
        return true;
    }

    private static void broadcast(ServerLevel level, Spell spell, ServerPlayer only) {
        SpellNetwork.Effect packet = new SpellNetwork.Effect(spell.rain, spell.origin, spell.yaw, spell.age,spell.duration);
        if (only != null) SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> only), packet);
        else SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), packet);
    }

    @SubscribeEvent public static void tick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        List<Spell> spells = ACTIVE.get(level);
        if (spells == null) return;
        spells.removeIf(spell -> spell.tick(level));
        if (spells.isEmpty()) ACTIVE.remove(level);
    }
    @SubscribeEvent public static void stop(ServerStoppedEvent event) { ACTIVE.clear(); }
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event) { sync(event); }
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event) { sync(event); }
    private static void sync(PlayerEvent event) {
        if (event.getEntity() instanceof ServerPlayer player)
            for (Spell spell : ACTIVE.getOrDefault(player.serverLevel(), List.of())) broadcast(player.serverLevel(), spell, player);
    }

    static final class Spell {
        final UUID owner;
        final boolean rain;final int duration;
        final Vec3 origin;
        final float yaw;
        final Vec3 forward;
        final Vec3 side;
        final Set<UUID> waveHits = new HashSet<>();
        int age;
        Spell(ServerPlayer player, boolean rain, Vec3 origin, float yaw) {
            duration=rain?SpellGeometry.CHARGE_TICKS+DurationMath.extend(SpellGeometry.RAIN_TICKS,net.minecraft.world.item.enchantment.EnchantmentHelper.getItemEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,player.getMainHandItem()),3):SpellGeometry.WAVE_TICKS;
            this.owner = player.getUUID(); this.rain = rain; this.origin = origin; this.yaw = yaw;
            double angle = Math.toRadians(yaw);
            forward = new Vec3(-Math.sin(angle), 0, Math.cos(angle));
            side = new Vec3(forward.z, 0, -forward.x);
        }
        boolean tick(ServerLevel level) {
            ServerPlayer caster = level.getServer().getPlayerList().getPlayer(owner);
            if (caster == null || caster.serverLevel() != level || !caster.isAlive()) return true;
            if (rain) {
                if (age == SpellGeometry.CHARGE_TICKS) {
                    level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.EVOKER_CAST_SPELL, SoundSource.PLAYERS, 1.5f, 0.7f);
                }
                if (age >= SpellGeometry.CHARGE_TICKS && (age - SpellGeometry.CHARGE_TICKS) % SpellGeometry.HIT_INTERVAL == 0)
                    damageRain(level, caster);
                return ++age >= duration;
            }
            damageWave(level, caster);
            return ++age >= SpellGeometry.WAVE_TICKS;
        }
        void damageWave(ServerLevel level, ServerPlayer caster) {
            double previous = age * SpellGeometry.WAVE_SPEED;
            double current = Math.min(SpellGeometry.WAVE_RANGE, previous + SpellGeometry.WAVE_SPEED);
            AABB bounds = new AABB(origin.x - current - 2, origin.y - 3, origin.z - current - 2,
                    origin.x + current + 2, origin.y + 3, origin.z + current + 2);
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, bounds,
                    e -> validTarget(e) && !waveHits.contains(e.getUUID()))) {
                Vec3 delta = target.position().subtract(origin);
                if (SpellGeometry.inWave(delta.dot(forward), delta.dot(side), previous, current, target.getBbWidth() * 0.5)) {
                    waveHits.add(target.getUUID());
                    burn(target, caster);
                }
            }
        }
        void damageRain(ServerLevel level, ServerPlayer caster) {
            AABB bounds = new AABB(origin.x - 9, origin.y - 0.4, origin.z - 9,
                    origin.x + 9, origin.y + 16, origin.z + 9);
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, bounds, this::validTarget)) {
                if (!SpellGeometry.inRain(target.getX() - origin.x, target.getZ() - origin.z, target.getBbWidth() * 0.5)) continue;
                // A solid roof shields the target from falling fire; do not burn through it.
                Vec3 impact = target.getEyePosition();
                Vec3 sky = new Vec3(impact.x, origin.y + 16, impact.z);
                BlockHitResult obstruction = level.clip(new ClipContext(sky, impact, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, caster));
                if (obstruction.getType() == HitResult.Type.MISS) burn(target, caster);
            }
        }
        boolean validTarget(LivingEntity entity) {
            return entity.isAlive() && !entity.getUUID().equals(owner) && !entity.isSpectator();
        }
        void burn(LivingEntity target, ServerPlayer caster) {
            target.setSecondsOnFire(5);ArtifactExperience.hurt(target,caster.damageSources().playerAttack(caster), 10.0f);
        }
    }
}
