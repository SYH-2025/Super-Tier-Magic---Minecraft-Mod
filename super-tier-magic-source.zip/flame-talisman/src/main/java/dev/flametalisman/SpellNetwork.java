package dev.flametalisman;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.Optional;
import java.util.function.Supplier;

public final class SpellNetwork {
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(FlameTalisman.MOD_ID, "spells"), () -> "14", "14"::equals, "14"::equals);
    private SpellNetwork() {}
    public static void register() {
        CHANNEL.registerMessage(0, Cast.class, (msg, buf) -> buf.writeBoolean(msg.rain),
                buf -> new Cast(buf.readBoolean()), SpellNetwork::handleCast, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(1, Effect.class, Effect::encode, Effect::decode,
                SpellNetwork::handleEffect, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(2, BladeEffect.class, BladeEffect::encode, BladeEffect::decode,
                SpellNetwork::handleBladeEffect, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(3, HandAnimation.class,
                (msg,buf) -> {buf.writeVarInt(msg.playerId);buf.writeByte(msg.mode);buf.writeVarInt(msg.duration);},
                buf -> new HandAnimation(buf.readVarInt(),buf.readUnsignedByte(),buf.readVarInt()),
                SpellNetwork::handleAnimation, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(4, ElectricEffect.class,ElectricEffect::encode,ElectricEffect::decode,
                SpellNetwork::handleElectric,Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(5,SwordEffect.class,SwordEffect::encode,SwordEffect::decode,SpellNetwork::handleSword,Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(6,SwordSwarm.class,SwordSwarm::encode,SwordSwarm::decode,SpellNetwork::handleSwarm,Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(7,WindEffect.class,WindEffect::encode,WindEffect::decode,SpellNetwork::handleWind,Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(8,ToggleFlight.class,(msg,buf)->{},buf->new ToggleFlight(),SpellNetwork::handleToggleFlight,Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(9,FlightState.class,(msg,buf)->buf.writeBoolean(msg.active()),buf->new FlightState(buf.readBoolean()),SpellNetwork::handleFlightState,Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
    public record Cast(boolean rain) {}
    public record ToggleFlight(){}
    public record FlightState(boolean active){}
    private static void handleToggleFlight(ToggleFlight msg,Supplier<NetworkEvent.Context> supplier){var context=supplier.get();context.enqueueWork(()->{if(context.getSender()!=null)AirFlightManager.toggle(context.getSender());});context.setPacketHandled(true);}
    private static void handleFlightState(FlightState msg,Supplier<NetworkEvent.Context> supplier){var context=supplier.get();context.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->dev.flametalisman.client.AirFlightClient.state(msg.active())));context.setPacketHandled(true);}
    public record WindEffect(int kind,int id,Vec3 origin,Vec3 vector,int duration,int age,float roll){
        void encode(FriendlyByteBuf b){b.writeByte(kind);b.writeVarInt(id);b.writeDouble(origin.x);b.writeDouble(origin.y);b.writeDouble(origin.z);b.writeDouble(vector.x);b.writeDouble(vector.y);b.writeDouble(vector.z);b.writeVarInt(duration);b.writeVarInt(age);b.writeFloat(roll);}
        static WindEffect decode(FriendlyByteBuf b){return new WindEffect(b.readUnsignedByte(),b.readVarInt(),new Vec3(b.readDouble(),b.readDouble(),b.readDouble()),new Vec3(b.readDouble(),b.readDouble(),b.readDouble()),b.readVarInt(),b.readVarInt(),b.readFloat());}
    }
    private static void handleWind(WindEffect msg,Supplier<NetworkEvent.Context> supplier){var context=supplier.get();context.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->dev.flametalisman.client.WindRenderer.add(msg)));context.setPacketHandled(true);}
    public record SwordSwarm(int id,int age,Vec3 origin,Vec3[]positions,Vec3[]directions){
        void encode(FriendlyByteBuf b){b.writeVarInt(id);b.writeVarInt(age);b.writeDouble(origin.x);b.writeDouble(origin.y);b.writeDouble(origin.z);b.writeVarInt(positions.length);for(int i=0;i<positions.length;i++){Vec3 p=positions[i].subtract(origin),d=directions[i];b.writeFloat((float)p.x);b.writeFloat((float)p.y);b.writeFloat((float)p.z);b.writeFloat((float)d.x);b.writeFloat((float)d.y);b.writeFloat((float)d.z);}}
        static SwordSwarm decode(FriendlyByteBuf b){int id=b.readVarInt(),age=b.readVarInt();Vec3 o=new Vec3(b.readDouble(),b.readDouble(),b.readDouble());int count=b.readVarInt();if(count<1||count>243)throw new IllegalArgumentException("Invalid sword count");Vec3[]p=new Vec3[count],d=new Vec3[count];for(int i=0;i<count;i++){p[i]=o.add(b.readFloat(),b.readFloat(),b.readFloat());d[i]=new Vec3(b.readFloat(),b.readFloat(),b.readFloat());}return new SwordSwarm(id,age,o,p,d);}
    }
    private static void handleSwarm(SwordSwarm msg,Supplier<NetworkEvent.Context> supplier){var context=supplier.get();context.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->dev.flametalisman.client.SwordVisuals.swarm(msg)));context.setPacketHandled(true);}
    public record HandAnimation(int playerId, int mode, int duration) {}
    private static void handleAnimation(HandAnimation msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> dev.flametalisman.client.BladeHandAnimation.start(msg)));
        context.setPacketHandled(true);
    }
    public record Effect(boolean rain, Vec3 origin, float yaw, int age,int duration) {
        public Effect(boolean rain,Vec3 origin,float yaw,int age){this(rain,origin,yaw,age,rain?200:16);}
        void encode(FriendlyByteBuf buf) {
            buf.writeBoolean(rain); buf.writeDouble(origin.x); buf.writeDouble(origin.y);
            buf.writeDouble(origin.z); buf.writeFloat(yaw); buf.writeVarInt(age);buf.writeVarInt(duration);
        }
        static Effect decode(FriendlyByteBuf buf) {
            return new Effect(buf.readBoolean(), new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()), buf.readFloat(), buf.readVarInt(),buf.readVarInt());
        }
    }
    private static void handleCast(Cast msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            if (context.getSender() != null) {
                var held=context.getSender().getMainHandItem();
                if(held.is(FlameTalisman.AIR_TALISMAN.get()))AirManager.cast(context.getSender(),msg.rain);
                else if(held.is(FlameTalisman.SWORD_INTENT.get()))SwordIntentManager.cast(context.getSender(),msg.rain);
                else if(held.is(FlameTalisman.LIGHTNING_SHARD.get())||held.is(FlameTalisman.LIGHTNING_TALISMAN.get())||held.is(FlameTalisman.THUNDER_BLADE.get())) {
                    ThunderManager.cast(context.getSender(),msg.rain);
                }
                else if (held.is(FlameTalisman.BLADE.get())) {
                    if(!msg.rain&&context.getSender().isShiftKeyDown())DashManager.cast(context.getSender());
                    else if(msg.rain)BladeSpellManager.cast(context.getSender(),context.getSender().isShiftKeyDown());
                }
                else SpellManager.cast(context.getSender(), msg.rain);
            }
        });
        context.setPacketHandled(true);
    }
    private static void handleEffect(Effect msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> dev.flametalisman.client.ClientEffects.add(msg)));
        context.setPacketHandled(true);
    }
    public record BladeEffect(int kind, int id, Vec3 origin, Vec3 direction, int age,float roll,int enchantLevel,float coverage) {
        public BladeEffect(int kind,int id,Vec3 origin,Vec3 direction,int age,float roll,int enchantLevel){this(kind,id,origin,direction,age,roll,enchantLevel,64);}
        public BladeEffect(int kind,int id,Vec3 origin,Vec3 direction,int age){this(kind,id,origin,direction,age,0,0);}
        public BladeEffect(int kind,int id,Vec3 origin,Vec3 direction,int age,float roll){this(kind,id,origin,direction,age,roll,0);}
        void encode(FriendlyByteBuf buf) {
            buf.writeByte(kind); buf.writeVarInt(id);
            buf.writeDouble(origin.x); buf.writeDouble(origin.y); buf.writeDouble(origin.z);
            buf.writeDouble(direction.x); buf.writeDouble(direction.y); buf.writeDouble(direction.z);
            buf.writeVarInt(age);buf.writeFloat(roll);buf.writeVarInt(enchantLevel);buf.writeFloat(coverage);
        }
        static BladeEffect decode(FriendlyByteBuf buf) {
            return new BladeEffect(buf.readUnsignedByte(), buf.readVarInt(),
                    new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
                    new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()), buf.readVarInt(),buf.readFloat(),EnchantmentSpellMath.fire(buf.readVarInt()),buf.readFloat());
        }
    }
    private static void handleBladeEffect(BladeEffect msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> dev.flametalisman.client.BladeVisuals.add(msg)));
        context.setPacketHandled(true);
    }
    public record ElectricEffect(int kind,int id,Vec3 origin,Vec3 vector,int duration,float scale,int entityId) {
        void encode(FriendlyByteBuf b){b.writeByte(kind);b.writeVarInt(id);b.writeDouble(origin.x);b.writeDouble(origin.y);b.writeDouble(origin.z);b.writeDouble(vector.x);b.writeDouble(vector.y);b.writeDouble(vector.z);b.writeVarInt(duration);b.writeFloat(scale);b.writeVarInt(entityId);}
        static ElectricEffect decode(FriendlyByteBuf b){return new ElectricEffect(b.readUnsignedByte(),b.readVarInt(),new Vec3(b.readDouble(),b.readDouble(),b.readDouble()),new Vec3(b.readDouble(),b.readDouble(),b.readDouble()),b.readVarInt(),b.readFloat(),b.readVarInt());}
    }
    private static void handleElectric(ElectricEffect msg,Supplier<NetworkEvent.Context> supplier) {
        var context=supplier.get();
        context.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->dev.flametalisman.client.ElectricVisuals.add(msg)));
        context.setPacketHandled(true);
    }
    public record SwordEffect(int kind,int id,Vec3 origin,Vec3 vector,int duration,int entityId,float scale,float roll,int enchantLevel,float coverage) {
        public SwordEffect(int kind,int id,Vec3 origin,Vec3 vector,int duration,int entityId,float scale,float roll,int enchantLevel){this(kind,id,origin,vector,duration,entityId,scale,roll,enchantLevel,kind==2?50:64);}
        public SwordEffect(int kind,int id,Vec3 origin,Vec3 vector,int duration,int entityId,float scale){this(kind,id,origin,vector,duration,entityId,scale,0,0);}
        public SwordEffect(int kind,int id,Vec3 origin,Vec3 vector,int duration,int entityId,float scale,float roll){this(kind,id,origin,vector,duration,entityId,scale,roll,0);}
        void encode(FriendlyByteBuf b){b.writeByte(kind);b.writeVarInt(id);b.writeDouble(origin.x);b.writeDouble(origin.y);b.writeDouble(origin.z);b.writeDouble(vector.x);b.writeDouble(vector.y);b.writeDouble(vector.z);b.writeVarInt(duration);b.writeVarInt(entityId);b.writeFloat(scale);b.writeFloat(roll);b.writeVarInt(enchantLevel);b.writeFloat(coverage);}
        static SwordEffect decode(FriendlyByteBuf b){return new SwordEffect(b.readUnsignedByte(),b.readVarInt(),new Vec3(b.readDouble(),b.readDouble(),b.readDouble()),new Vec3(b.readDouble(),b.readDouble(),b.readDouble()),b.readVarInt(),b.readVarInt(),b.readFloat(),b.readFloat(),EnchantmentSpellMath.sharp(b.readVarInt()),b.readFloat());}
    }
    private static void handleSword(SwordEffect msg,Supplier<NetworkEvent.Context> supplier) {
        var context=supplier.get();context.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->dev.flametalisman.client.SwordVisuals.add(msg)));context.setPacketHandled(true);
    }
}
