package dev.flametalisman;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public final class SwordIntentItem extends SwordItem {
    public SwordIntentItem(){super(Tiers.NETHERITE,7,-2.4f,new Item.Properties().durability(3000).fireResistant());}
    public static int sharpness(ItemStack stack){return EnchantmentSpellMath.sharp(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS,stack));}
    @Override public com.google.common.collect.Multimap<net.minecraft.world.entity.ai.attributes.Attribute,net.minecraft.world.entity.ai.attributes.AttributeModifier> getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot slot,ItemStack stack){var attributes=com.google.common.collect.HashMultimap.create(super.getAttributeModifiers(slot,stack));int level=sharpness(stack);if(slot==net.minecraft.world.entity.EquipmentSlot.MAINHAND&&level>0)attributes.put(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE,new net.minecraft.world.entity.ai.attributes.AttributeModifier(java.util.UUID.fromString("5c281c62-d049-4830-bdc6-02ece7723f10"),"Sword mastery",EnchantmentSpellMath.swordAttributeBonus(level),net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));return attributes;}
    @Override public boolean hurtEnemy(ItemStack stack,net.minecraft.world.entity.LivingEntity target,net.minecraft.world.entity.LivingEntity attacker){if(SwordTargeting.canHit(attacker.getUUID(),target.getUUID()))SwordPercentage.take(target,0,sharpness(stack));return super.hurtEnemy(stack,target,attacker);}
    @Override public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer){consumer.accept(new dev.flametalisman.client.BladeClientExtension());}
    @Override public boolean canApplyAtEnchantingTable(ItemStack stack,Enchantment e){return e==Enchantments.MENDING||e==Enchantments.UNBREAKING||e==Enchantments.SHARPNESS;}
    @Override public boolean isBookEnchantable(ItemStack stack,ItemStack book){return EnchantmentHelper.getEnchantments(book).keySet().stream().allMatch(e->e==Enchantments.MENDING||e==Enchantments.UNBREAKING||e==Enchantments.SHARPNESS);}
    @Override public <T extends net.minecraft.world.entity.LivingEntity> int damageItem(ItemStack stack,int amount,T entity,java.util.function.Consumer<T> onBroken){return ArtifactCosts.damage(entity,amount);}
    @Override public void appendHoverText(ItemStack stack,@Nullable Level level,List<Component> lines,TooltipFlag flag){ItemLegend.append(lines,"sword_intent");}
}



