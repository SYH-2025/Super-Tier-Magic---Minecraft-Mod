package dev.flametalisman;

import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.*;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class SwordIntentManager {
    private static final Map<ServerLevel,List<Skill>> ACTIVE=new IdentityHashMap<>();
    private static int nextId=1;
    private static boolean valid(LivingEntity target,UUID owner){return target.isAlive()&&!target.isSpectator()&&SwordTargeting.canHit(owner,target.getUUID());}
    static void qi(LivingEntity target,int skillDamage,int sharpness) {
        if(!(target.level() instanceof ServerLevel level)||!target.isAlive())return;
        MobEffectInstance old=target.getEffect(FlameTalisman.SWORD_QI.get());int amplifier=old==null?0:Math.min(4,old.getAmplifier()+1);
        target.addEffect(new MobEffectInstance(FlameTalisman.SWORD_QI.get(),101,amplifier,false,false,true));
        long now=level.getServer().overworld().getGameTime();var data=target.getPersistentData();
        if(old==null)data.putLong("stmSwordQiNextPulse",now+20);data.putInt("stmSwordQiSharpness",old==null?sharpness:Math.max(sharpness,data.getInt("stmSwordQiSharpness")));
        if(skillDamage>0){float prior=data.getLong("stmSwordQiBoostUntil")>=now?data.getFloat("stmSwordQiBoost"):0;data.putFloat("stmSwordQiBoost",Math.max(prior,skillDamage));data.putLong("stmSwordQiBoostUntil",now+100);}
    }
    private static void hit(ServerLevel level,ServerPlayer player,LivingEntity target,float damage,int lingering,double percentStrength,int sharpness) {
        if(!valid(target,player.getUUID()))return;
        ArtifactExperience.markSword(target,player);
        ArtifactExperience.hurtSword(target,player.damageSources().playerAttack(player),damage);if(target.isAlive())target.setLastHurtByPlayer(player);SwordPercentage.take(target,percentStrength,sharpness);qi(target,lingering,sharpness);ArtifactExperience.qiOwner(target,player);
    }
    @SubscribeEvent public static void melee(AttackEntityEvent event) {
        if(event.getEntity() instanceof ServerPlayer player&&event.getEntity().getMainHandItem().is(FlameTalisman.SWORD_INTENT.get())&&event.getTarget() instanceof LivingEntity target&&valid(target,event.getEntity().getUUID())){qi(target,0,SwordIntentItem.sharpness(event.getEntity().getMainHandItem()));ArtifactExperience.qiOwner(target,player);}
    }
    private static long clock(ServerPlayer p){return p.serverLevel().getServer().overworld().getGameTime();}
    private static int cooldown(ServerPlayer p,String key){return (int)Math.min(600,Math.max(0,p.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG).getLong(key)-clock(p)));}
    private static void animation(ServerPlayer p,int mode,int ticks){SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(()->p),new SpellNetwork.HandAnimation(p.getId(),mode,ticks));}
    private static void send(ServerLevel level,SpellNetwork.SwordEffect effect){SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension),effect);}
    private static void stop(ServerLevel level,int id){send(level,new SpellNetwork.SwordEffect(9,id,Vec3.ZERO,Vec3.ZERO,0,0,0));}
    public static boolean cast(ServerPlayer player,boolean right){
        var stack=player.getMainHandItem();if(!player.isAlive()||player.isSpectator()||!stack.is(FlameTalisman.SWORD_INTENT.get())||player.getCooldowns().isOnCooldown(stack.getItem()))return false;
        boolean ultimate=player.isShiftKeyDown();if(!right&&!ultimate)return false; if(ultimate&&!(right?ArtifactConfig.SWORD_SKY.get():ArtifactConfig.SWORD_DOMAIN.get()))return false;
        ServerLevel level=player.serverLevel();List<Skill> skills=ACTIVE.computeIfAbsent(level,l->new ArrayList<>());
        String key=right?"stmCelestialSwordReady":"stmSwordDominionReady";
        if(ultimate&&cooldown(player,key)>0){player.displayClientMessage(Component.translatable("message.flametalisman.intent_cooldown",(cooldown(player,key)+19)/20),true);animation(player,right?7:8,cooldown(player,key));return false;}
        if(ultimate&&skills.stream().anyMatch(s->s.owner.equals(player.getUUID())&&s.kind==(right?1:2))){player.displayClientMessage(Component.translatable("message.flametalisman.intent_active"),true);return false;}
        int cost=ultimate?200:2;
        if(!player.getAbilities().instabuild&&stack.getMaxDamage()-stack.getDamageValue()<ArtifactCosts.required(player,cost)){player.displayClientMessage(Component.translatable("message.flametalisman.low_durability",ArtifactCosts.required(player,cost)),true);return false;}
        double yaw=Math.toRadians(player.getYRot());Vec3 forward=ultimate?new Vec3(-Math.sin(yaw),0,Math.cos(yaw)):player.getLookAngle().normalize();
        Vec3 origin=ultimate?player.position():player.getEyePosition().add(0,-.35,0);
        if(ultimate&&right){
            origin=SpellAim.ground(player,64);
            if(origin==null){player.displayClientMessage(Component.translatable("message.flametalisman.intent_target"),true);return false;}
            double sky=Math.min(level.getMaxBuildHeight()-8,player.getY()+32);
            forward=new Vec3(forward.x,Math.max(8,sky-origin.y),forward.z);
        }
        float roll=ultimate?0:(float)Math.toRadians((player.getRandom().nextBoolean()?1:-1)*(15+player.getRandom().nextDouble()*65));
        Skill skill=new Skill(player.getUUID(),ultimate?(right?1:2):0,nextId++,origin,forward,player.getId(),roll,SwordIntentItem.sharpness(stack),ArtifactRange.radius(ultimate&&!right?50:64,stack));skills.add(skill);
        send(level,skill.packet());
        if(ultimate){
            var persisted=player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);persisted.putLong(key,clock(player)+600);player.getPersistentData().put(Player.PERSISTED_NBT_TAG,persisted);
            MagicAdvancements.grant(player,right?"celestial_sword":"sword_domain");ArtifactCosts.health(player,false);
            animation(player,right?7:8,600);if(right)animation(player,0,200);
        }else player.getCooldowns().addCooldown(stack.getItem(),8);
        stack.hurtAndBreak(cost,player,p->p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        level.playSound(null,player.blockPosition(),ultimate?SoundEvents.BEACON_ACTIVATE:SoundEvents.TRIDENT_THROW,SoundSource.PLAYERS,1.2f,ultimate?0.55f:1.2f);
        return true;
    }
    @SubscribeEvent public static void tick(TickEvent.LevelTickEvent event){
        if(event.phase!=TickEvent.Phase.END||!(event.level instanceof ServerLevel level))return;var skills=ACTIVE.get(level);if(skills==null)return;
        skills.removeIf(s->s.tick(level));if(skills.isEmpty())ACTIVE.remove(level);
    }
    @SubscribeEvent public static void stopped(ServerStoppedEvent event){ACTIVE.clear();nextId=1;}
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event){sync(event);}
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event){sync(event);}
    private static void sync(PlayerEvent event){
        if(!(event.getEntity() instanceof ServerPlayer p))return;animation(p,7,cooldown(p,"stmCelestialSwordReady"));animation(p,8,cooldown(p,"stmSwordDominionReady"));
        for(Skill skill:ACTIVE.getOrDefault(p.serverLevel(),List.of()))SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(()->p),skill.packet());
    }
    private static final class Skill {
        final double coverage;final UUID owner;final int kind,id,entity,sharpness,range,rayCount;final Vec3 origin,forward,side;final float roll;final boolean[]blocked;
        final Set<UUID>waveHit=new HashSet<>();final Map<UUID,Integer>domainHit=new HashMap<>();int age;boolean impact;
        final Vec3[] ghostPositions,ghostDirections;final int[] piercing;
        Skill(UUID owner,int kind,int id,Vec3 origin,Vec3 forward,int entity,float roll,int sharpness,double coverage){this.coverage=coverage;this.sharpness=sharpness;range=EnchantmentSpellMath.range(sharpness);rayCount=EnchantmentSpellMath.rays(sharpness);blocked=new boolean[rayCount];int count=EnchantmentSpellMath.ghosts(sharpness);ghostPositions=new Vec3[count];ghostDirections=new Vec3[count];piercing=new int[count];this.owner=owner;this.kind=kind;this.id=id;this.origin=origin;this.forward=forward;side=SwordMotion.waveSide(forward,roll);this.entity=entity;this.roll=roll;}
        SpellNetwork.SwordEffect packet(){return new SpellNetwork.SwordEffect(kind,id,origin,forward,kind==0?16:kind==1?200+DurationMath.fall(sharpness)+DurationMath.SKY_FADE:DurationMath.domain(sharpness),entity,age,roll,sharpness,(float)coverage);}
        boolean tick(ServerLevel level){
            ServerPlayer player=level.getServer().getPlayerList().getPlayer(owner);
            if(player==null||!player.isAlive()||player.serverLevel()!=level){stop(level,id);return true;}
            if(kind==0)wave(level,player);
            else if(kind==1){
                if(age==200)animation(player,2,0);
                if(!impact&&age>=200&&SwordMotion.swordTip(age,forward.y,sharpness)<=0){
                    impact=true;
                    send(level,new SpellNetwork.SwordEffect(3,nextId++,origin,Vec3.ZERO,30,0,(float)coverage));
                    level.playSound(null,origin.x,origin.y,origin.z,SoundEvents.GENERIC_EXPLODE,SoundSource.PLAYERS,3,0.5f);
                }
                if(age>=200&&age<200+DurationMath.fall(sharpness)&&age%20==0){
                    for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(origin,origin).inflate(coverage),e->valid(e,owner))) {
                        Vec3 delta=target.getBoundingBox().getCenter().subtract(origin);
                        if(Math.hypot(delta.x,delta.z)>coverage)continue;
                        hit(level,player,target,32+EnchantmentSpellMath.skyBonus(sharpness),10,1,sharpness);
                    }
                }
            } else domain(level,player);
            int end=kind==0?16:kind==1?200+DurationMath.fall(sharpness)+DurationMath.SKY_FADE:DurationMath.domain(sharpness);return ++age>=end;
        }
        void wave(ServerLevel level,ServerPlayer player){
            double speed=range/16.0,previous=age*speed,current=Math.min(range,previous+speed);Vec3 base=origin;
            for(int i=0;i<rayCount;i++){
                if(blocked[i])continue;double a=-Math.PI/2+i*Math.PI/(rayCount-1);Vec3 ray=forward.scale(Math.cos(a)).add(side.scale(Math.sin(a)));
                Vec3 from=base.add(ray.scale(previous)),to=base.add(ray.scale(current));
                if(!level.hasChunkAt(BlockPos.containing(to))){blocked[i]=true;continue;}
                Vec3 end=to;
                for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(from,end).inflate(0.7,1,0.7),e->valid(e,owner)&&!waveHit.contains(e.getUUID()))){
                    if(target.getBoundingBox().inflate(0.55).clip(from,end).isEmpty())continue;waveHit.add(target.getUUID());hit(level,player,target,20+EnchantmentSpellMath.directBonus(sharpness),8,.2,sharpness);
                }
                
            }
        }
        void domain(ServerLevel level,ServerPlayer player){
            Vec3 center=origin;
            double radius=age<=DurationMath.domain(sharpness)-40?coverage*SwordMotion.expansion(age):coverage+(age-DurationMath.domain(sharpness)+40)*2.4;
            List<LivingEntity>targets=level.getEntitiesOfClass(LivingEntity.class,new AABB(center,center).inflate(radius+10,12,radius+10),e->valid(e,owner));
            for(int i=0;i<ghostPositions.length;i++){
                SwordMotion.Ghost orbit=SwordMotion.ghost(i,age,center,sharpness,coverage);
                if(i>=SwordMotion.count(age,sharpness)){ghostPositions[i]=orbit.position();ghostDirections[i]=orbit.tangent();continue;}
                if(ghostPositions[i]==null){var initial=SwordMotion.ghost(i,age-1,center,sharpness,coverage);ghostPositions[i]=initial.position();ghostDirections[i]=initial.tangent();}
                Vec3 from=ghostPositions[i],to;LivingEntity nearest=null;double closest=12*12;
                if(age<DurationMath.domain(sharpness)-40&&piercing[i]==0)for(LivingEntity target:targets){
                    Vec3 relative=target.position().subtract(center);if(Math.hypot(relative.x,relative.z)>radius)continue;
                    double distance=target.getBoundingBox().getCenter().distanceToSqr(from);
                    if(distance<closest){closest=distance;nearest=target;}
                }
                if(age>=DurationMath.domain(sharpness)-40){to=from.add(from.subtract(center).multiply(1,0,1).normalize().scale(2.4));}
                else if(piercing[i]>0){to=from.add(ghostDirections[i].scale(6));piercing[i]--;}
                else if(nearest!=null){Vec3 delta=nearest.getBoundingBox().getCenter().subtract(from);to=from.add(delta.normalize().scale(6));if(delta.length()<6)piercing[i]=3;}
                else {Vec3 delta=orbit.position().subtract(from);to=from.add(delta.scale(Math.min(1,24/Math.max(0.001,delta.length()))));}
                Vec3 direction=to.subtract(from);if(direction.lengthSqr()>0.00001)ghostDirections[i]=direction.normalize();
                for(LivingEntity target:targets){
                    Vec3 relative=target.position().subtract(center);if(Math.hypot(relative.x,relative.z)>radius+target.getBbWidth()/2)continue;
                    if(age-domainHit.getOrDefault(target.getUUID(),-100)<20)continue;
                    AABB box=target.getBoundingBox().inflate(0.45+orbit.size()*0.18);
                    if(!box.contains(to)&&box.clip(from,to).isEmpty())continue;
                    hit(level,player,target,32+EnchantmentSpellMath.domainBonus(sharpness),10,.6,sharpness);domainHit.put(target.getUUID(),age);
                }
                ghostPositions[i]=to;
            }
            if(age%2==0)SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension),new SpellNetwork.SwordSwarm(id,age,origin,ghostPositions.clone(),ghostDirections.clone()));
        }
    }
}
























