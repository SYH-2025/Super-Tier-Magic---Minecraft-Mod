package dev.flametalisman;

import net.minecraft.world.phys.Vec3;

/** Shared ghost-sword trajectories, so rendering and path damage use identical orbits. */
public final class SwordMotion {
    public static final double CELESTIAL_LENGTH=144,CELESTIAL_WIDTH=14,CELESTIAL_RADIUS=64;
    public static double length(int level){return CELESTIAL_LENGTH+12*EnchantmentSpellMath.sharp(level);}
    public static double width(int level){return CELESTIAL_WIDTH+1.2*EnchantmentSpellMath.sharp(level);}
    public static double expansion(double age){return Math.min(1,Math.max(0,age/20));}
    public static double swordTip(double age,double skyHeight){double start=skyHeight-12;return start-(start+CELESTIAL_LENGTH*0.80)*Math.max(0,Math.min(1,(age-200)/100));}
    public static double swordTip(double age,double skyHeight,int level){double start=skyHeight-12;return start-(start+length(level)*.80)*Math.max(0,Math.min(1,(age-200)/(double)DurationMath.fall(level)));}
    public static int count(double age){return Math.min(123,12+(int)(111*expansion(age)));}
    public static int count(double age,int level){int max=EnchantmentSpellMath.ghosts(level);return Math.min(max,12+(int)((max-12)*expansion(age)));}
    public static Vec3 waveSide(Vec3 forward,double roll){double yaw=Math.atan2(-forward.x,forward.z);Vec3 horizontalSide=new Vec3(Math.cos(yaw),0,Math.sin(yaw));Vec3 up=forward.normalize().cross(horizontalSide).normalize();return horizontalSide.scale(Math.cos(roll)).add(up.scale(Math.sin(roll)));}
    public static Ghost ghost(int index,double age,Vec3 center){
        return ghost(index,age,center,0);
    }
    public static Ghost ghost(int index,double age,Vec3 center,int level){
        return ghost(index,age,center,level,50);
    }
    public static Ghost ghost(int index,double age,Vec3 center,int level,double coverage){
        double release=DurationMath.domain(level)-40,orbit=Math.min(age,release),speed=5*(0.055+0.007*(index%5)),sign=index%2==0?1:-1;
        double angle=index*2.399963229728653+orbit*speed*sign;
        // Interleave six radial bands so new swords fill the centre and outer area together.
        double radius=(3+(index%6)*9+((index/6)%3-1)*0.8)*expansion(age)*coverage/50;
        if(age>release)radius+=(age-release)*2.4;
        Vec3 position=center.add(Math.cos(angle)*radius,1.1+(index%4)*0.5+Math.sin(age*0.06+index)*0.35,Math.sin(angle)*radius);
        Vec3 tangent=age>release?new Vec3(Math.cos(angle),0,Math.sin(angle)):new Vec3(-Math.sin(angle)*sign,0,Math.cos(angle)*sign);
        return new Ghost(position,tangent,0.22+(index%9)*0.03,index%2==1);
    }
    public record Ghost(Vec3 position,Vec3 tangent,double size,boolean silver){}
    private SwordMotion(){}
}
