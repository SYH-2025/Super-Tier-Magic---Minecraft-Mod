package dev.flametalisman;
import net.minecraft.world.entity.LivingEntity;
public final class SwordPercentage {
    public static float amount(LivingEntity target,double strength){return SwordPercentageMath.amount(target.getMaxHealth(),ArtifactConfig.SWORD_PERCENT_MIN.get(),ArtifactConfig.SWORD_PERCENT_MAX.get(),strength);}
    public static float amount(LivingEntity target,double strength,int sharpness){return (float)(amount(target,strength)*EnchantmentSpellMath.percentMultiplier(sharpness));}
    public static void take(LivingEntity target,double strength){if(target.level().isClientSide||!target.isAlive())return;target.setHealth(Math.max(0,target.getHealth()-amount(target,strength)));if(target.getHealth()<=0)target.die(target.damageSources().magic());}
    public static void take(LivingEntity target,double strength,int sharpness){if(target.level().isClientSide||!target.isAlive())return;target.setHealth(Math.max(0,target.getHealth()-amount(target,strength,sharpness)));if(target.getHealth()<=0)target.die(target.damageSources().magic());}
    private SwordPercentage(){}
}
