package dev.flametalisman;
public final class SwordPercentageMath {
    public static float amount(float maximum,double min,double max,double strength){return (float)(Math.max(0,maximum)*(min+(Math.max(min,max)-min)*Math.max(0,Math.min(1,strength))));}
    private SwordPercentageMath(){}
}
