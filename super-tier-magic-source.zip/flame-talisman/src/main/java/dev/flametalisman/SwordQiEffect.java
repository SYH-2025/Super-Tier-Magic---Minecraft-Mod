package dev.flametalisman;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.LivingEntity;

/** Forced vitality loss; armour, resistance and normal hurt frames cannot reduce it. */
public final class SwordQiEffect extends MobEffect {
    public SwordQiEffect(){super(MobEffectCategory.HARMFUL,0xCADFFF);}
    @Override public boolean isDurationEffectTick(int duration,int amplifier){return true;}
    @Override public void applyEffectTick(LivingEntity entity,int amplifier) {
        if(!(entity.level() instanceof ServerLevel level)||!entity.isAlive())return;
        float damage=Math.min(6,amplifier+2);
        var data=entity.getPersistentData();
        long now=level.getServer().overworld().getGameTime();if(now<data.getLong("stmSwordQiNextPulse"))return;
        data.putLong("stmSwordQiNextPulse",now+20);
        if(data.getLong("stmSwordQiBoostUntil")>=now)damage=Math.max(damage,data.getFloat("stmSwordQiBoost"));
        double strength=Math.max(0,Math.min(1,amplifier/4.0));
        if(data.getLong("stmSwordQiBoostUntil")>=now)strength=Math.max(strength,data.getFloat("stmSwordQiBoost")>=10?1:.6);
        damage+=SwordPercentage.amount(entity,strength,data.getInt("stmSwordQiSharpness"));
        ArtifactExperience.qiPulse(entity);
        entity.setHealth(Math.max(0,entity.getHealth()-damage));
        if(entity.getHealth()<=0)entity.die(level.damageSources().magic());
    }
}

