package dev.flametalisman;

import java.util.UUID;

/** Identity guard shared by all sword damage and homing target selection. */
public final class SwordTargeting {
    public static boolean canHit(UUID owner,UUID target){return owner!=null&&target!=null&&!owner.equals(target);}
    private SwordTargeting(){}
}
