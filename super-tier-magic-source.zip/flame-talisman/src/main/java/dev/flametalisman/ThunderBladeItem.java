package dev.flametalisman;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public final class ThunderBladeItem extends SwordItem {
    public ThunderBladeItem(){super(Tiers.NETHERITE,4,-2.4f,new Item.Properties().durability(8000).fireResistant());}
    @Override public boolean hurtEnemy(ItemStack stack,LivingEntity target,LivingEntity attacker) {
        if(!target.level().isClientSide)ThunderManager.residue(target,attacker.getUUID(),6);
        return super.hurtEnemy(stack,target,attacker);
    }
    @Override public boolean canApplyAtEnchantingTable(ItemStack stack,Enchantment e){return e==Enchantments.MENDING||e==Enchantments.UNBREAKING||e==Enchantments.SHARPNESS;}
    @Override public boolean isBookEnchantable(ItemStack stack,ItemStack book){return EnchantmentHelper.getEnchantments(book).keySet().stream().allMatch(e->e==Enchantments.MENDING||e==Enchantments.UNBREAKING||e==Enchantments.SHARPNESS);}
    @Override public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer){consumer.accept(new dev.flametalisman.client.BladeClientExtension());}
    @Override public <T extends net.minecraft.world.entity.LivingEntity> int damageItem(ItemStack stack,int amount,T entity,java.util.function.Consumer<T> onBroken){return ArtifactCosts.damage(entity,amount);}
    @Override public void appendHoverText(ItemStack stack,@Nullable Level level,List<Component> lines,TooltipFlag flag){ItemLegend.append(lines,"thunderclap_blade");}
}

