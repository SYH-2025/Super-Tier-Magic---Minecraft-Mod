package dev.flametalisman;
public final class ThunderBladeMath {
    private static int level(int sharpness){return Math.max(0,Math.min(5,sharpness));}
    public static int length(int sharpness){return (int)Math.round(72+184*level(sharpness)/5.0);}
    public static int depth(int sharpness){return (int)Math.round(64+64*level(sharpness)/5.0);}
    public static double width(int sharpness){return 9+level(sharpness)/5.0;}
    public static int boltDamage(int sharpness){return 20+4*level(sharpness);}
    public static int boltDepth(int sharpness){return (int)Math.round(5+27*level(sharpness)/5.0);}
    public static double boltRadius(int sharpness){return 3+3*level(sharpness);}
    public static int stormRate(int sharpness){return 20+16*level(sharpness);}
    public static int strikesThisTick(int tick,int sharpness){int rate=stormRate(sharpness);return (tick+1)*rate/20-tick*rate/20;}
    private ThunderBladeMath(){}
}
