package dev.flametalisman;

import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import java.util.*;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID)
public final class ThunderManager {
    private static final Map<ServerLevel,State> STATES=new IdentityHashMap<>();
    private static int nextId=1;
    private static final ResourceKey<DamageType> ELECTRIC=ResourceKey.create(Registries.DAMAGE_TYPE,new ResourceLocation(FlameTalisman.MOD_ID,"lightning_magic"));
    private static State state(ServerLevel level){return STATES.computeIfAbsent(level,l->new State());}
    private static int id(){return nextId++;}
    private static void effect(ServerLevel level,int kind,int id,Vec3 origin,Vec3 vector,int duration,float scale,int entity) {
        SpellNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension),new SpellNetwork.ElectricEffect(kind,id,origin,vector,duration,scale,entity));
    }
    private static void stopEffect(ServerLevel level,int id){effect(level,9,id,Vec3.ZERO,Vec3.ZERO,0,0,0);}
    private static DamageSource source(ServerLevel level,UUID owner) {
        Entity caster=level.getEntity(owner);
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ELECTRIC),caster,caster);
    }
    private static boolean valid(LivingEntity entity,UUID owner){return entity.isAlive()&&!entity.isSpectator()&&!entity.getUUID().equals(owner);}
    private static void shock(LivingEntity entity,UUID owner,float damage,int residual) {
        if(entity.level() instanceof ServerLevel level && valid(entity,owner) && ArtifactExperience.hurt(entity,source(level,owner),damage))residue(entity,owner,residual);
    }
    public static void residue(LivingEntity target,UUID owner,int damage) {
        if(!(target.level() instanceof ServerLevel level)||!valid(target,owner))return;
        State state=state(level);
        Residual old=state.residuals.get(target.getUUID());
        long now=level.getGameTime();
        if(old==null){old=new Residual(id(),owner,damage,now+100,now+20);state.residuals.put(target.getUUID(),old);}
        else {if(damage>=old.damage){old.damage=damage;old.owner=owner;}old.until=now+100;}
        effect(level,4,old.id,target.getBoundingBox().getCenter(),Vec3.ZERO,100,old.damage,target.getId());
    }
    private static void area(ServerLevel level,UUID owner,Vec3 center,double radius,float damage,int residual,Set<UUID> excluded,boolean falloff) {
        effect(level,1,id(),center,Vec3.ZERO,12,(float)radius,0);
        for(LivingEntity entity:level.getEntitiesOfClass(LivingEntity.class,new AABB(center,center).inflate(radius),e->valid(e,owner)&&!excluded.contains(e.getUUID()))) {
            double distance=entity.getBoundingBox().getCenter().distanceTo(center);
            if(distance>=radius)continue;
            if(level.clip(new ClipContext(center.add(0,0.15,0),entity.getEyePosition(),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,entity)).getType()!=HitResult.Type.MISS)continue;
            shock(entity,owner,falloff?(float)(damage*(1-distance/radius)):damage,residual);
        }
    }
    private static long clock(ServerPlayer player){return player.serverLevel().getServer().overworld().getGameTime();}
    public static int skyCooldown(ServerPlayer player) {
        return (int)Math.min(600,Math.max(0,player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG).getLong("stmThunderSkyReady")-clock(player)));
    }
    private static void animation(ServerPlayer player,int mode,int duration) {
        SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new SpellNetwork.HandAnimation(player.getId(),mode,duration));
    }
    public static boolean cast(ServerPlayer player,boolean right) {
        if(!player.isAlive()||player.isSpectator())return false;
        ItemStack stack=player.getMainHandItem();
        if(player.getCooldowns().isOnCooldown(stack.getItem()))return false;
        ServerLevel level=player.serverLevel();
        State state=state(level);
        boolean shard=stack.is(FlameTalisman.LIGHTNING_SHARD.get());
        boolean talisman=stack.is(FlameTalisman.LIGHTNING_TALISMAN.get());
        boolean blade=stack.is(FlameTalisman.THUNDER_BLADE.get());
        if(!shard&&!talisman&&!blade)return false;
        if(shard&&!right)return false;
        if(blade&&!right&&!player.isShiftKeyDown())return false;
        boolean sky=blade&&right&&player.isShiftKeyDown();
        boolean abyss=blade&&!right&&player.isShiftKeyDown(); if(sky&&!ArtifactConfig.THUNDER_SKY.get()||abyss&&!ArtifactConfig.ABYSS.get())return false;
        if(sky && skyCooldown(player)>0) {
            player.displayClientMessage(Component.translatable("message.flametalisman.thunder_cooldown",(skyCooldown(player)+19)/20),true);
            animation(player,5,skyCooldown(player));return false;
        }
        if((sky&&state.skies.stream().anyMatch(s->s.owner.equals(player.getUUID())))
                ||(abyss&&state.abysses.stream().anyMatch(s->s.owner.equals(player.getUUID())))) {
            player.displayClientMessage(Component.translatable("message.flametalisman.thunder_active"),true);return false;
        }
        int cost=sky?200:abyss?20:blade?2:1;
        if(!shard&&!player.getAbilities().instabuild&&stack.getMaxDamage()-stack.getDamageValue()<ArtifactCosts.required(player,cost)) {
            player.displayClientMessage(Component.translatable("message.flametalisman.low_durability",ArtifactCosts.required(player,cost)),true);return false;
        }
        if(sky) {
            Vec3 ground=SpellAim.ground(player,64);
            if(ground==null){player.displayClientMessage(Component.translatable("message.flametalisman.intent_target"),true);return false;}
            Sky ritual=new Sky(player,id(),ground);state.skies.add(ritual);
            effect(level,3,ritual.id,ritual.origin,new Vec3(ritual.sharpness,0,0),ritual.visualEnd,(float)ritual.coverage,player.getId());MagicAdvancements.grant(player,"thunder_ritual");
            CompoundTag data=player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
            data.putLong("stmThunderSkyReady",clock(player)+600);player.getPersistentData().put(Player.PERSISTED_NBT_TAG,data);
            animation(player,5,600);animation(player,0,200);
        } else if(abyss) { MagicAdvancements.grant(player,"abyss");ArtifactCosts.health(player,false);
            double yaw=Math.toRadians(player.getYRot());
            Vec3 forward=new Vec3(-Math.sin(yaw),0,Math.cos(yaw));
            BlockHitResult ground=level.clip(new ClipContext(player.position().add(0,0.2,0),player.position().add(0,level.getMinBuildHeight()-player.getY(),0),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player));
            int top=ground.getType()==HitResult.Type.BLOCK?ground.getBlockPos().getY():player.getBlockY()-1;
            int sharp=net.minecraft.world.item.enchantment.EnchantmentHelper.getItemEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,stack);
            Abyss cut=new Abyss(player.getUUID(),new Vec3(player.getX(),top+1.04,player.getZ()),forward,id(),sharp);state.abysses.add(cut);
            effect(level,7,cut.id,player.position().add(0,0.3,0),forward,100,1,player.getId());animation(player,4,120);
        } else if(talisman&&!right) {
            double yaw=Math.toRadians(player.getYRot());
            Wave wave=new Wave(player.getUUID(),player.position().add(0,1,0),new Vec3(-Math.sin(yaw),0,Math.cos(yaw)),id());state.waves.add(wave);
            effect(level,2,wave.id,wave.origin,wave.forward,16,32,0);
        } else {
            int sharp=net.minecraft.world.item.enchantment.EnchantmentHelper.getItemEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,stack);
            Projectile bolt=new Projectile(player.getUUID(),player.getEyePosition().add(player.getLookAngle().scale(0.4)),player.getLookAngle().scale(4),blade?ThunderBladeMath.boltDamage(sharp):shard?10:12,blade?8:shard?2:4,blade,id(),sharp);state.projectiles.add(bolt);
            effect(level,0,bolt.id,bolt.pos,bolt.velocity,blade?24:16,1,0);
        }
        if(shard){if(!player.getAbilities().instabuild&&ArtifactCosts.damage(player,1)>0)stack.shrink(1);}else stack.hurtAndBreak(cost,player,p->p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        if(!sky&&!abyss)player.getCooldowns().addCooldown(stack.getItem(),6);
        level.playSound(null,player.blockPosition(),sky?SoundEvents.LIGHTNING_BOLT_THUNDER:SoundEvents.TRIDENT_THUNDER,sky?SoundSource.WEATHER:SoundSource.PLAYERS,sky||abyss?1.5f:0.55f,sky||abyss?0.7f:1.45f);
        return true;
    }
    @SubscribeEvent public static void boltJoined(EntityJoinLevelEvent event) {
        if(ArtifactConfig.SHARD_DROPS.get()&&event.getLevel() instanceof ServerLevel level&&event.getEntity() instanceof LightningBolt bolt)state(level).rodBolts.put(bolt.getUUID(),new RodStrike(bolt));
    }
    @SubscribeEvent public static void tick(TickEvent.LevelTickEvent event) {
        if(event.phase!=TickEvent.Phase.END||!(event.level instanceof ServerLevel level))return;
        State state=STATES.get(level);if(state==null)return;
        state.projectiles.removeIf(p->p.tick(level));state.waves.removeIf(w->w.tick(level));
        state.skies.removeIf(s->s.tick(level));state.abysses.removeIf(a->a.tick(level));
        long now=level.getGameTime();
        var iterator=state.residuals.entrySet().iterator();
        while(iterator.hasNext()) {
            var entry=iterator.next();var residual=entry.getValue();var entity=level.getEntity(entry.getKey());
            if(!(entity instanceof LivingEntity living)||!living.isAlive()||now>residual.until){stopEffect(level,residual.id);iterator.remove();continue;}
            if(now>=residual.next){ArtifactExperience.hurt(living,source(level,residual.owner),residual.damage);residual.next=now+20;}
        }
        var rods=state.rodBolts.entrySet().iterator();
        while(rods.hasNext()) {
            RodStrike strike=rods.next().getValue();LightningBolt bolt=strike.bolt;strike.age++;
            BlockPos base=BlockPos.containing(bolt.getX(),bolt.getY()-0.000001,bolt.getZ());
            if(strike.rod==null)for(BlockPos pos:List.of(base,base.below(),base.above())) {
                if(!level.hasChunkAt(pos))continue;
                var block=level.getBlockState(pos);
                if(block.is(Blocks.LIGHTNING_ROD)&&block.getValue(LightningRodBlock.POWERED)) {
                    strike.rod=pos.immutable();strike.count=level.random.nextInt(4);break;
                }
            }
            if(strike.rod!=null&&(bolt.isRemoved()||strike.age>=80)){
                    BlockPos pos=strike.rod;int count=strike.count;
                    if(count>0) {
                        Direction side=Direction.from2DDataValue(level.random.nextInt(4));
                        ItemEntity item=new ItemEntity(level,pos.getX()+0.5+side.getStepX()*0.85,pos.getY()+0.55,pos.getZ()+0.5+side.getStepZ()*0.85,new ItemStack(FlameTalisman.LIGHTNING_SHARD.get(),count));
                        item.setDefaultPickUpDelay();item.setDeltaMovement(side.getStepX()*0.06,0.15,side.getStepZ()*0.06);level.addFreshEntity(item);
                    }
                    rods.remove();
            }else if(strike.rod==null&&(bolt.isRemoved()||strike.age>12))rods.remove();
        }
        if(state.empty())STATES.remove(level);
    }
    @SubscribeEvent public static void stopped(ServerStoppedEvent event){STATES.clear();nextId=1;}
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event){sync(event);}
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event){sync(event);}
    private static void sync(PlayerEvent event) {
        if(!(event.getEntity() instanceof ServerPlayer player))return;
        animation(player,5,skyCooldown(player));
        State state=STATES.get(player.serverLevel());if(state==null)return;
        for(Sky sky:state.skies)SpellNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new SpellNetwork.ElectricEffect(3,sky.id,sky.origin,new Vec3(sky.sharpness,0,0),Math.max(1,sky.visualEnd-sky.age),(float)sky.coverage,-sky.age));
    }
    private static final class State {
        final List<Projectile> projectiles=new ArrayList<>();final List<Wave>waves=new ArrayList<>();final List<Sky>skies=new ArrayList<>();final List<Abyss>abysses=new ArrayList<>();
        final Map<UUID,Residual> residuals=new HashMap<>();final Map<UUID,RodStrike>rodBolts=new HashMap<>();
        boolean empty(){return projectiles.isEmpty()&&waves.isEmpty()&&skies.isEmpty()&&abysses.isEmpty()&&residuals.isEmpty()&&rodBolts.isEmpty();}
    }
    private static final class RodStrike {
        final LightningBolt bolt;BlockPos rod;int age,count;
        RodStrike(LightningBolt bolt){this.bolt=bolt;}
    }
    private static final class Residual {
        final int id;UUID owner;int damage;long until,next;
        Residual(int id,UUID owner,int damage,long until,long next){this.id=id;this.owner=owner;this.damage=damage;this.until=until;this.next=next;}
    }
    private static final class Projectile {
        final UUID owner;final Vec3 velocity;final int damage,residual,id,terrainDepth;final double terrainRadius;final boolean pierce;final Set<UUID>hit=new HashSet<>();Vec3 pos,entry;int age;
        Projectile(UUID owner,Vec3 pos,Vec3 velocity,int damage,int residual,boolean pierce,int id,int sharpness){this.owner=owner;this.pos=pos;this.velocity=velocity;this.damage=damage;this.residual=residual;this.pierce=pierce;this.id=id;terrainDepth=ThunderBladeMath.boltDepth(sharpness);terrainRadius=ThunderBladeMath.boltRadius(sharpness);}
        boolean tick(ServerLevel level) {
            Vec3 next=pos.add(velocity);
            if(!level.hasChunkAt(BlockPos.containing(next))){stopEffect(level,id);return true;}
            Entity caster=level.getEntity(owner);
            if(!(caster instanceof LivingEntity living)||!living.isAlive()){stopEffect(level,id);return true;}
            BlockHitResult block=level.clip(new ClipContext(pos,next,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,living));
            Vec3 finish=block.getType()==HitResult.Type.BLOCK?block.getLocation():next;
            boolean penetrationEnds=false;
            if(pierce){
                finish=next;Vec3 axis=velocity.normalize();
                if(entry==null&&block.getType()==HitResult.Type.BLOCK){entry=block.getLocation();effect(level,1,ThunderManager.id(),entry,Vec3.ZERO,12,(float)terrainRadius,0);}
                if(entry!=null){
                    double from=Math.max(0,pos.subtract(entry).dot(axis)),to=Math.min(terrainDepth,next.subtract(entry).dot(axis));
                    finish=entry.add(axis.scale(to));penetrationEnds=to>=terrainDepth;
                    if(ArtifactConfig.BOLT_TERRAIN.get()&&to>from)carveBolt(level,entry.add(axis.scale(from)),finish,terrainRadius);
                }
                if(ArtifactConfig.BOLT_TERRAIN.get()&&block.getType()==HitResult.Type.BLOCK&&block.getLocation().distanceToSqr(pos)<=finish.distanceToSqr(pos)+.0001){
                    var struckBlock=level.getBlockState(block.getBlockPos());if(!struckBlock.is(Blocks.BEDROCK)&&struckBlock.getDestroySpeed(level,block.getBlockPos())>=0)level.setBlock(block.getBlockPos(),Blocks.AIR.defaultBlockState(),2);
                }
            }
            Vec3 rayEnd=finish;
            List<LivingEntity>targets=level.getEntitiesOfClass(LivingEntity.class,new AABB(pos,rayEnd).inflate(1),e->valid(e,owner)&&!hit.contains(e.getUUID())&&e.getBoundingBox().inflate(0.25).clip(pos,rayEnd).isPresent());
            targets.sort(Comparator.comparingDouble(e->e.getBoundingBox().getCenter().distanceToSqr(pos)));
            for(LivingEntity target:targets) {
                Vec3 impact=target.getBoundingBox().inflate(0.25).clip(pos,finish).orElse(target.getBoundingBox().getCenter());
                if(!pierce){area(level,owner,impact,4,damage,residual,Set.of(),false);stopEffect(level,id);return true;}
                hit.add(target.getUUID());shock(target,owner,damage,residual);effect(level,1,ThunderManager.id(),impact,Vec3.ZERO,8,1.5f,0);
            }
            if(penetrationEnds||!pierce&&block.getType()==HitResult.Type.BLOCK){area(level,owner,finish.add(0,0.15,0),4,damage,residual,hit,false);stopEffect(level,id);return true;}
            pos=finish;if(++age>=16&&entry==null){stopEffect(level,id);return true;}return false;
        }
    }
    private static final class Wave {
        final UUID owner;final Vec3 origin,forward,side;final int id;final Set<UUID>hit=new HashSet<>();int age;
        Wave(UUID owner,Vec3 origin,Vec3 forward,int id){this.owner=owner;this.origin=origin;this.forward=forward;side=new Vec3(forward.z,0,-forward.x);this.id=id;}
        boolean tick(ServerLevel level) {
            double previous=age*2,current=previous+2;
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(origin,origin).inflate(current+2,3,current+2),e->valid(e,owner)&&!hit.contains(e.getUUID()))) {
                Vec3 delta=target.position().subtract(origin);
                if(SpellGeometry.inWave(delta.dot(forward),delta.dot(side),previous,current,target.getBbWidth()*0.5)){hit.add(target.getUUID());shock(target,owner,12,4);}
            }
            return ++age>=16;
        }
    }
    private static final class Sky {
        final UUID owner;final Vec3 origin,soundOrigin;final double coverage;final int id,sharpness;int activeEnd,visualEnd,age;
        Sky(ServerPlayer player,int id,Vec3 ground){coverage=ArtifactRange.radius(64,player.getMainHandItem());soundOrigin=ground;owner=player.getUUID();origin=new Vec3(ground.x,Math.max(ground.y+8,Math.min(player.serverLevel().getMaxBuildHeight()-8,player.getY()+48)),ground.z);this.id=id;sharpness=Math.min(5,net.minecraft.world.item.enchantment.EnchantmentHelper.getItemEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,player.getMainHandItem()));activeEnd=200+DurationMath.thunderRain(sharpness);visualEnd=activeEnd+DurationMath.SKY_FADE;}
        boolean tick(ServerLevel level) {
            ServerPlayer player=level.getServer().getPlayerList().getPlayer(owner);
            if(player==null||!player.isAlive()||player.serverLevel()!=level){stopEffect(level,id);return true;}
            if(age<activeEnd&&age%20==0&&player.gameMode.getGameModeForPlayer()==GameType.SURVIVAL)ArtifactCosts.health(player,true);
            if(age==200)animation(player,2,0);
            if(age>0&&age<activeEnd&&age%40==0)level.playSound(null,soundOrigin.x,soundOrigin.y,soundOrigin.z,SoundEvents.LIGHTNING_BOLT_THUNDER,SoundSource.WEATHER,5f,.75f+level.random.nextFloat()*.2f);
            activeEnd=200+DurationMath.thunderRain(sharpness);visualEnd=activeEnd+DurationMath.SKY_FADE;
            if(age>=200&&age<activeEnd) {
                int strikes=ThunderBladeMath.strikesThisTick(age-200,sharpness);
                for(int strike=0;strike<strikes;strike++)for(int attempt=0;attempt<6;attempt++) {
                    double a=level.random.nextDouble()*Math.PI*2,r=Math.sqrt(level.random.nextDouble())*coverage;
                    double x=origin.x+Math.cos(a)*r,z=origin.z+Math.sin(a)*r;
                    if(!level.hasChunkAt(BlockPos.containing(x,0,z)))continue;
                    Vec3 top=new Vec3(x,level.getMaxBuildHeight()-1,z);
                    BlockHitResult ground=level.clip(new ClipContext(top,new Vec3(x,level.getMinBuildHeight()+0.01,z),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,player));
                    if(ground.getType()!=HitResult.Type.BLOCK)continue;
                    Vec3 impact=ground.getLocation().add(0,0.1,0);
                    Vec3 visibleSky=new Vec3(x,Math.max(origin.y+96,impact.y+128),z);
                    effect(level,8,ThunderManager.id(),visibleSky,impact,12,1,0);area(level,owner,impact,8,30,8,Set.of(),true);
                    if(ArtifactConfig.STORM_TERRAIN.get())crater(level,impact);
                    
                    break;
                }
            }
            return ++age>=visualEnd;
        }
    }
    private static final class Abyss {
        final UUID owner;final Vec3 origin,forward,side;final int id,length,depth;final double width;
        final Set<UUID> struck=new HashSet<>();
        final List<Column> columns=new ArrayList<>();int age,distance,cursor;
        Abyss(UUID owner,Vec3 origin,Vec3 forward,int id,int sharpness){
            this.owner=owner;this.origin=origin;this.forward=forward;side=new Vec3(forward.z,0,-forward.x);this.id=id;
            length=ThunderBladeMath.length(sharpness);depth=ThunderBladeMath.depth(sharpness);width=ThunderBladeMath.width(sharpness);
            Vec3 end=origin.add(forward.scale(length));
            int minX=(int)Math.floor(Math.min(origin.x,end.x)-6),maxX=(int)Math.ceil(Math.max(origin.x,end.x)+6);
            int minZ=(int)Math.floor(Math.min(origin.z,end.z)-6),maxZ=(int)Math.ceil(Math.max(origin.z,end.z)+6);
            // Classify every world-grid column instead of rounding sparse rotated samples.
            // This produces a filled footprint with no missed cells between scan lines.
            for(int x=minX;x<=maxX;x++)for(int z=minZ;z<=maxZ;z++){
                Vec3 delta=new Vec3(x+0.5-origin.x,0,z+0.5-origin.z);
                double along=delta.dot(forward),across=delta.dot(side);
                if(along<0.5||along>=length)continue;
                double half=abyssWidth(along,length,width);
                if(Math.abs(across)>Math.max(0.5,half))continue;
                if(x==(int)Math.floor(origin.x)&&z==(int)Math.floor(origin.z))continue;
                columns.add(new Column(x,z,along,across,half));
            }
            columns.sort(Comparator.comparingDouble(Column::along));
        }
        boolean tick(ServerLevel level) {
            ServerPlayer player=level.getServer().getPlayerList().getPlayer(owner);
            if(player==null||!player.isAlive()||player.serverLevel()!=level){stopEffect(level,id);return true;}
            if(age++<100)return false;
            if(distance==0){stopEffect(level,id);effect(level,6,id,origin,forward,220,length,0);level.playSound(null,player.blockPosition(),SoundEvents.LIGHTNING_BOLT_THUNDER,SoundSource.PLAYERS,2,0.6f);}
            int previous=distance;distance=Math.min(length,distance+4);
            Vec3 end=origin.add(forward.scale(distance));AABB damageBounds=new AABB(origin,end).inflate(width/2+2,0,width/2+2).expandTowards(0,-depth,0).expandTowards(0,16,0);
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,damageBounds,e->valid(e,owner)&&!struck.contains(e.getUUID()))){
                Vec3 delta=target.getBoundingBox().getCenter().subtract(origin);double along=delta.dot(forward),across=Math.abs(delta.dot(side)),padding=target.getBbWidth()/2;
                if(along<previous-padding||along>distance+padding||along<0||along>length||across>Math.max(.5,abyssWidth(along,length,width))+padding)continue;
                struck.add(target.getUUID());shock(target,owner,32,8);
            }
            while(cursor<columns.size()&&columns.get(cursor).along<=distance){
                Column column=columns.get(cursor++);
                BlockPos probe=new BlockPos(column.x,0,column.z);
                if(!level.hasChunkAt(probe))continue;
                // Clear the whole column from its actual top surface, including slopes,
                // gravel, fluids and overhanging blocks, down to the common abyss floor.
                int surface=level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE,column.x,column.z)-1;
                int topY=Math.max((int)Math.floor(origin.y-0.1),surface);
                int floor=Math.max(level.getMinBuildHeight(),(int)Math.floor(origin.y-0.1)-depth+1);
                int bottom=topY;
                for(int y=topY;y>=floor;y--){
                    BlockPos pos=new BlockPos(column.x,y,column.z);
                    var block=level.getBlockState(pos);
                    if(block.is(Blocks.BEDROCK)||block.getDestroySpeed(level,pos)<0)break;
                    if(!block.isAir())level.setBlock(pos,Blocks.AIR.defaultBlockState(),2);
                    bottom=y;
                }
                if(((int)column.along)%4==0 && Math.abs(column.across)<0.75) {
                    Vec3 floorLine=new Vec3(column.x+0.5,bottom+0.1,column.z+0.5);
                    effect(level,5,ThunderManager.id(),floorLine.subtract(forward.scale(1.8)),floorLine.add(forward.scale(1.8)),200,1,0);
                    Vec3 skyStrike=new Vec3(column.x+0.5,origin.y+144,column.z+0.5);
                    effect(level,8,ThunderManager.id(),skyStrike,floorLine,16,1,0);
                }
                if(bottom<topY&&((int)column.along)%4==0&&Math.abs(column.across)>=Math.max(0,column.half-1)){
                    Vec3 wall=new Vec3(column.x+0.5,topY+1.01,column.z+0.5).add(side.scale(column.across>=0?0.45:-0.45));
                    effect(level,5,ThunderManager.id(),wall,new Vec3(wall.x,bottom+0.1,wall.z),200,1,0);
                }
            }
            return cursor>=columns.size()&&distance>=length;
        }
        private record Column(int x,int z,double along,double across,double half){}
    }
    public static double abyssWidth(double distance){return 4.5*Math.pow(Math.max(0,Math.sin(Math.PI*distance/72.0)),1.25);}
    public static double abyssWidth(double distance,double length,double width){return width/2*Math.pow(Math.max(0,Math.sin(Math.PI*distance/length)),1.25);}
    private static void carveBolt(ServerLevel level,Vec3 from,Vec3 to,double radius){
        Vec3 delta=to.subtract(from);double length=delta.length();if(length<.001)return;Vec3 axis=delta.scale(1/length);
        AABB bounds=new AABB(from,to).inflate(radius);int minY=Math.max(level.getMinBuildHeight(),(int)Math.floor(bounds.minY)),maxY=Math.min(level.getMaxBuildHeight()-1,(int)Math.ceil(bounds.maxY));
        for(int x=(int)Math.floor(bounds.minX);x<=Math.ceil(bounds.maxX);x++)for(int z=(int)Math.floor(bounds.minZ);z<=Math.ceil(bounds.maxZ);z++){
            if(!level.hasChunkAt(new BlockPos(x,0,z)))continue;
            for(int y=minY;y<=maxY;y++){
                Vec3 offset=new Vec3(x+.5,y+.5,z+.5).subtract(from);double along=offset.dot(axis);
                if(along<0||along>=length||offset.lengthSqr()-along*along>radius*radius)continue;
                BlockPos pos=new BlockPos(x,y,z);var block=level.getBlockState(pos);if(!block.isAir()&&!block.is(Blocks.BEDROCK)&&block.getDestroySpeed(level,pos)>=0)level.setBlock(pos,Blocks.AIR.defaultBlockState(),2);
            }
        }
    }
    private static void crater(ServerLevel level,Vec3 impact){
        BlockPos center=BlockPos.containing(impact.add(0,-0.11,0));
        for(int dx=-4;dx<=4;dx++)for(int dz=-4;dz<=4;dz++){
            double r=Math.hypot(dx,dz),edge=3.3+level.random.nextDouble()*0.7;if(r>edge)continue;
            int cut=Math.min(5,Math.max(1,(int)Math.round(5*(1-r*r/(edge*edge))+level.random.nextDouble()*0.5)));
            for(int down=0;down<cut;down++){BlockPos pos=center.offset(dx,-down,dz);if(!level.hasChunkAt(pos))break;var block=level.getBlockState(pos);if(block.is(Blocks.BEDROCK)||block.getDestroySpeed(level,pos)<0)break;if(!block.isAir())level.setBlock(pos,Blocks.AIR.defaultBlockState(),2);}
        }
    }
}



