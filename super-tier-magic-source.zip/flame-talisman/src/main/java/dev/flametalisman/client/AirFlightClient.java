package dev.flametalisman.client;
import dev.flametalisman.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID,value=Dist.CLIENT)
public final class AirFlightClient {
    private static boolean active;private static ClientLevel lastLevel;
    public static boolean cloudVisible(){var mc=Minecraft.getInstance();return active&&mc.player!=null&&mc.level!=null&&ArtifactConfig.CLOUD_PARTICLES.get()&&!mc.options.getCameraType().isFirstPerson();}
    public static void state(boolean value){var mc=Minecraft.getInstance();lastLevel=mc.level;active=value;if(mc.player!=null)mc.player.getPersistentData().putBoolean(AirFlightManager.ACTIVE_TAG,value);}
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END)return;var mc=Minecraft.getInstance();
        if(lastLevel!=mc.level||mc.player==null){active=false;lastLevel=mc.level;}
        while(AirFlightKeys.TOGGLE.consumeClick())if(mc.player!=null&&mc.screen==null)SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.ToggleFlight());
        if(mc.player==null||mc.level==null||mc.isPaused()||!active)return;
        var player=mc.player;if(!player.isSpectator()){player.getAbilities().mayfly=true;player.getAbilities().flying=true;}
        player.walkAnimation.setSpeed(0);
        
    }
}

