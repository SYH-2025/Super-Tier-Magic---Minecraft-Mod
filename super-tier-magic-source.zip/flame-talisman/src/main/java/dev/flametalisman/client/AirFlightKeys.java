package dev.flametalisman.client;
import com.mojang.blaze3d.platform.InputConstants;
import dev.flametalisman.FlameTalisman;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class AirFlightKeys {
    public static final KeyMapping TOGGLE=new KeyMapping("key.flametalisman.cloud_flight",KeyConflictContext.IN_GAME,InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_R,"key.categories.flametalisman");
    @SubscribeEvent public static void register(RegisterKeyMappingsEvent event){event.register(TOGGLE);}
}
