package dev.flametalisman.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Move the one existing first-person item; never submit another copy for rendering. */
public final class BladeClientExtension implements IClientItemExtensions {
    @Override public boolean applyForgeHandTransform(PoseStack poses,LocalPlayer player,HumanoidArm arm,
            ItemStack stack,float partial,float equip,float swing) {
        return BladeHandAnimation.transform(poses,player,arm,stack,partial);
    }
}
