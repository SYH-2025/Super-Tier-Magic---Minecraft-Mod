package dev.flametalisman.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.flametalisman.FlameTalisman;
import dev.flametalisman.SpellNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Matrix3f;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID,value=Dist.CLIENT)
public final class BladeHandAnimation {
    private static int ritualLeft,ritualTotal,dashLeft,dashTotal,cooldownLeft,thunderCooldown,slashLeft,slashTotal,intentSkyCooldown,intentDomainCooldown;
    private static boolean domainPose;
    private static boolean blade(ItemStack stack){return stack.is(FlameTalisman.BLADE.get())||stack.is(FlameTalisman.THUNDER_BLADE.get())||stack.is(FlameTalisman.SWORD_INTENT.get());}
    private static ClientLevel lastLevel;
    public static void start(SpellNetwork.HandAnimation packet) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.player.getId()!=packet.playerId())return;
        lastLevel=mc.level;
        if(packet.mode()==0){ritualLeft=ritualTotal=packet.duration();domainPose=false;}
        else if(packet.mode()==1){dashLeft=dashTotal=packet.duration();}
        else if(packet.mode()==3){cooldownLeft=packet.duration();}
        else if(packet.mode()==4){slashLeft=slashTotal=packet.duration();}
        else if(packet.mode()==5){thunderCooldown=packet.duration();}
        else if(packet.mode()==6){ritualLeft=ritualTotal=packet.duration();domainPose=true;}
        else if(packet.mode()==7){intentSkyCooldown=packet.duration();}
        else if(packet.mode()==8){intentDomainCooldown=packet.duration();}
        else {ritualLeft=0;}
    }
    public static void tick(Minecraft mc) {
        if(mc.level!=lastLevel || mc.player==null) {
            ritualLeft=0;dashLeft=0;cooldownLeft=0;thunderCooldown=0;slashLeft=0;intentSkyCooldown=0;intentDomainCooldown=0;lastLevel=mc.level;return;
        }
        if(!mc.player.isAlive()){ritualLeft=0;dashLeft=0;slashLeft=0;}
        if(mc.isPaused())return;
        if(ritualLeft>0)ritualLeft--;
        if(dashLeft>0)dashLeft--;
        if(cooldownLeft>0)cooldownLeft--;
        if(thunderCooldown>0)thunderCooldown--;
        if(slashLeft>0)slashLeft--;
        if(intentSkyCooldown>0)intentSkyCooldown--;if(intentDomainCooldown>0)intentDomainCooldown--;
    }
    private static double smooth(double value){double t=Math.max(0,Math.min(1,value));return t*t*(3-2*t);}
    public static boolean transform(PoseStack poses,LocalPlayer player,HumanoidArm arm,ItemStack stack,float partial) {
        Minecraft mc=Minecraft.getInstance();
        if(player!=mc.player || arm!=player.getMainArm() || !blade(stack)
                || (ritualLeft<=0 && dashLeft<=0 && slashLeft<=0))return false;
        boolean dash=dashLeft>0;
        double progress=dash ? dashTotal-dashLeft+partial : ritualTotal-ritualLeft+partial;
        double amount=dash ? smooth(progress/2)*smooth((dashLeft-partial)/4)
                : smooth(progress/8)*smooth((ritualLeft-partial)/10);
        int sign=arm==HumanoidArm.RIGHT ? 1 : -1;
        double x=sign*(0.45*(1-amount)+(dash?0.18:0.025)*amount);
        double y=-0.34*(1-amount)+(dash?-0.26:0.07)*amount;
        double z=dash ? -0.65-0.8*amount : -0.62+0.10*amount;
        if(!dash&&domainPose&&slashLeft<=0){x=sign*(0.45*(1-amount)+0.20*amount);y=-0.34*(1-amount)+0.66*amount;}
        if(slashLeft>0) {
            progress=slashTotal-slashLeft+partial;
            double rise=smooth(progress/15),strike=smooth((progress-100)/6),returning=smooth((progress-106)/14);
            amount=rise*(1-returning);
            x=sign*(0.45*(1-amount)+0.22*amount);
            y=-0.34*(1-amount)+(0.72-0.97*strike)*amount;
            z=-0.62-0.48*strike*amount;
            poses.translate(x,y,z);
            poses.mulPose(Axis.XP.rotationDegrees((float)(-150*strike*amount)));
        } else poses.translate(x,y,z);
        if(!dash&&slashLeft<=0)poses.translate(0,Math.sin(progress*0.08)*0.007*amount,0);
        if(dash)poses.mulPose(Axis.XP.rotationDegrees((float)(-82*amount)));
        poses.mulPose(Axis.ZP.rotationDegrees((float)(45*amount+20*(1-amount))));
        poses.scale(0.90f,0.90f,0.90f);
        // The normal renderer still submits the only blade. Undo the model's built-in
        // first-person display transform so our desired vertical/spear pose is exact.
        ItemDisplayContext context=sign>0?ItemDisplayContext.FIRST_PERSON_RIGHT_HAND:ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
        var model=mc.getItemRenderer().getModel(stack,mc.level,player,player.getId());
        PoseStack builtIn=new PoseStack();
        model.getTransforms().getTransform(context).apply(sign<0,builtIn);
        poses.last().pose().mul(new Matrix4f(builtIn.last().pose()).invert());
        poses.last().normal().mul(new Matrix3f(builtIn.last().normal()).invert());
        return true;
    }
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void hideOffhand(RenderHandEvent event) {
        Minecraft mc=Minecraft.getInstance();
        if(event.getHand()==InteractionHand.OFF_HAND && mc.player!=null
                && blade(mc.player.getMainHandItem()) && (ritualLeft>0 || dashLeft>0 || slashLeft>0))
            event.setCanceled(true);
    }
    @SubscribeEvent(priority=EventPriority.HIGHEST) public static void hideDuplicateFirstPersonBody(RenderPlayerEvent.Pre event) {
        Minecraft mc=Minecraft.getInstance();
        // First-person body mods may submit the player's held-item layer separately.
        // Hide that body pass only while the camera owner is using a special hand pose.
        if(mc.player!=null && event.getEntity()==mc.player && mc.getCameraEntity()==mc.player
                && mc.options.getCameraType().isFirstPerson() && (ritualLeft>0 || dashLeft>0 || slashLeft>0)
                && blade(mc.player.getMainHandItem()))event.setCanceled(true);
    }
    @SubscribeEvent public static void cooldownHud(RenderGuiEvent.Post event) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.options.hideGui || !blade(mc.player.getMainHandItem()))return;
        if(mc.player.getMainHandItem().is(FlameTalisman.SWORD_INTENT.get())) {
            var gui=event.getGuiGraphics();int y=gui.guiHeight()-64;
            if(intentSkyCooldown>0){var text=net.minecraft.network.chat.Component.translatable("hud.flametalisman.intent_sky",(intentSkyCooldown+19)/20);gui.drawString(mc.font,text,(gui.guiWidth()-mc.font.width(text))/2,y,0xF0EDC8,true);y-=12;}
            if(intentDomainCooldown>0){var text=net.minecraft.network.chat.Component.translatable("hud.flametalisman.intent_domain",(intentDomainCooldown+19)/20);gui.drawString(mc.font,text,(gui.guiWidth()-mc.font.width(text))/2,y,0xD8E4FF,true);}return;
        }
        boolean thunder=mc.player.getMainHandItem().is(FlameTalisman.THUNDER_BLADE.get());int remaining=thunder?thunderCooldown:cooldownLeft;
        if(remaining<=0)return;
        var text=net.minecraft.network.chat.Component.translatable(thunder?"hud.flametalisman.thunder_cooldown":"hud.flametalisman.ritual_cooldown",(remaining+19)/20);
        var gui=event.getGuiGraphics();
        gui.drawString(mc.font,text,(gui.guiWidth()-mc.font.width(text))/2,gui.guiHeight()-64,0xFFD064,true);
    }
}
