package dev.flametalisman.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.flametalisman.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID, value = Dist.CLIENT)
public final class BladeRenderer {
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if (Minecraft.getInstance().level == null) return;
        if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            dimWorld(Math.max(SwordVisuals.darkness(event.getCamera().getPosition(),event.getPartialTick()),Math.max(BladeVisuals.darkness(event.getCamera().getPosition(), event.getPartialTick()),ElectricVisuals.darkness(event.getCamera().getPosition(),event.getPartialTick()))));
            return;
        }
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || BladeVisuals.ACTIVE.isEmpty()) return;
        Vec3 camera = event.getCamera().getPosition();
        RenderSystem.enableBlend(); RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.disableCull(); RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        PoseStack poses = event.getPoseStack();
        for (BladeVisuals.Visual v : BladeVisuals.ACTIVE.values()) {
            if (v.kind == 6 || v.pos.distanceToSqr(camera) > Math.pow(Math.max(220,v.coverage+96),2)) continue;
            poses.pushPose();
            Vec3 center = v.kind == 2 ? v.previous.lerp(v.pos, event.getPartialTick()) : v.origin;
            poses.translate(center.x - camera.x, center.y - camera.y, center.z - camera.z);
            Matrix4f m = poses.last().pose();
            double t = v.age + event.getPartialTick();
            if (v.kind == 0) waveRibbon(b,m,v,t);
            else if (v.kind == 1){circle(b,new Matrix4f(m).scale(v.coverage/16f),t,BladeMath.CHARGE+DurationMath.fireRain(v.enchantLevel)+DurationMath.SKY_FADE);SkySigilRenderer.render(b,m,v.coverage*Math.min(1,t/200),t,Math.max(0,Math.min(1,(BladeMath.CHARGE+DurationMath.fireRain(v.enchantLevel)+DurationMath.SKY_FADE-t)/DurationMath.SKY_FADE)),v.enchantLevel,0);if(v.enchantLevel>0){double r=v.coverage*Math.min(1,t/200),alpha=Math.max(0,Math.min(1,(BladeMath.CHARGE+DurationMath.fireRain(v.enchantLevel)+DurationMath.SKY_FADE-t)/DurationMath.SKY_FADE));for(int layer=0;layer<(v.enchantLevel+3)/4;layer++){double rr=r*(.12+layer*.11);MagicCircleRenderer.ring(b,m,rr,t*.012*(layer%2==0?1:-1),alpha);MagicCircleRenderer.polygon(b,m,8+layer*2,3,rr,-t*.013,alpha*.8);}}}
            else if (v.kind == 2) {
                sphere(b, m, 1.35, 0.11, t);
                sphere(b, m, 0.85, 0.75, t);
                sphere(b, m, 0.47, 1, t);
                trail(b, m, v, center, camera);
            } else {
                double alpha = Math.max(0, 1 - t / 25);
                MagicCircleRenderer.ring(b, m, Math.min(8, t * 0.6), 0, alpha);
                MagicCircleRenderer.ring(b, m, Math.min(8, t * 0.4), 0, alpha * 0.6);
                if (t < 8) sphere(b, m, 0.6 + t * 0.35, (1 - t/8) * 0.5, t);
            }
            poses.popPose();
        }
        BufferUploader.drawWithShader(b.end());
        RenderSystem.depthMask(true); RenderSystem.enableCull(); RenderSystem.defaultBlendFunc(); RenderSystem.disableBlend();
    }
    static void circle(BufferBuilder b,Matrix4f m,double t){circle(b,m,t,BladeMath.DURATION);}
    static void circle(BufferBuilder b, Matrix4f m, double t,int end) {
        double r = 16 * Math.max(0.015, Math.min(1, t / BladeMath.CHARGE));
        double a = t * 0.004;
        double alpha = Math.max(0, Math.min(1, (end-t)/(double)DurationMath.SKY_FADE));
        for (double scale : new double[]{1, 0.985, 0.94, 0.86, 0.825, 0.69, 0.66, 0.45, 0.22, 0.18})
            MagicCircleRenderer.ring(b, m, r * scale, a, alpha);
        MagicCircleRenderer.polygon(b,m,12,5,r*0.655,a,alpha);
        MagicCircleRenderer.polygon(b,m,6,2,r*0.81,-a*0.7,alpha);
        MagicCircleRenderer.polygon(b,m,8,3,r*0.43,-a*1.4,alpha);
        MagicCircleRenderer.polygon(b,m,12,1,r*0.69,a,alpha);
        for (int i=0;i<72;i++) {
            double angle = -a * 0.6 + i * Math.PI / 36;
            double x = Math.cos(angle) * r * 0.9, z = Math.sin(angle) * r * 0.9;
            double s = r * 0.012;
            MagicCircleRenderer.runeStroke(b,m,x,z,angle,-s,-s,s,s,alpha);
            MagicCircleRenderer.runeStroke(b,m,x,z,angle,0,-s*1.8,0,s*1.8,alpha);
            MagicCircleRenderer.runeStroke(b,m,x,z,angle,-s,s,s,-s,alpha);
            if(i%2==0) MagicCircleRenderer.runeStroke(b,m,x,z,angle,-s,0,s,0,alpha);
            if(i%3==0) MagicCircleRenderer.runeStroke(b,m,x,z,angle,-s,-s,s,-s,alpha);
        }
        for (int i=0;i<24;i++) {
            double angle = a + i * Math.PI / 12;
            MagicCircleRenderer.line(b,m,Math.cos(angle)*r*0.22,Math.sin(angle)*r*0.22,
                    Math.cos(angle)*r*0.32,Math.sin(angle)*r*0.32,alpha);
        }
        for (int i=0;i<12;i++) {
            double angle=-a+i*Math.PI/6;
            double x=Math.cos(angle)*r*0.755, z=Math.sin(angle)*r*0.755, s=r*0.022;
            for(int edge=0;edge<4;edge++) {
                double q=angle+edge*Math.PI/2, p=q+Math.PI/2;
                MagicCircleRenderer.line(b,m,x+Math.cos(q)*s,z+Math.sin(q)*s,x+Math.cos(p)*s,z+Math.sin(p)*s,alpha);
            }
        }
    }
    private static void sphere(BufferBuilder b, Matrix4f m, double radius, double alpha, double t) {
        for(int band=0;band<8;band++) {
            double p=-Math.PI/2+band*Math.PI/8, q=p+Math.PI/8;
            for(int slice=0;slice<16;slice++) {
                double a=t*0.03+slice*Math.PI/8,c=a+Math.PI/8;
                sphereVertex(b,m,radius,p,a,alpha); sphereVertex(b,m,radius,q,a,alpha);
                sphereVertex(b,m,radius,q,c,alpha); sphereVertex(b,m,radius,p,c,alpha);
            }
        }
    }
    private static void sphereVertex(BufferBuilder b, Matrix4f m, double r, double p, double a, double alpha) {
        double brightness=0.7+0.3*Math.cos(p);
        b.vertex(m,(float)(r*Math.cos(p)*Math.cos(a)),(float)(r*Math.sin(p)),(float)(r*Math.cos(p)*Math.sin(a)))
                .color(1f,(float)(0.74+0.2*brightness),(float)(0.20+0.5*brightness),(float)alpha).endVertex();
    }
    private static void trail(BufferBuilder b, Matrix4f m, BladeVisuals.Visual v, Vec3 center, Vec3 camera) {
        double length=Math.min(40,Math.max(0,v.origin.y-center.y));
        if(length<0.01)return;
        Vec3 up=new Vec3(0,1,0);
        Vec3 facing=up.cross(camera.subtract(center)).normalize();
        if(facing.lengthSqr()<0.001)facing=new Vec3(1,0,0);
        Vec3 tail=new Vec3(0,length,0);
        // Fixed x/z endpoints and one straight tapered strip, with a bright central core.
        for(int layer=0;layer<2;layer++) {
            double width=layer==0?0.70:0.12;
            float alpha=layer==0?0.42f:0.95f;
            Vec3 near=facing.scale(width),far=facing.scale(width*0.18);
            trailVertex(b,m,near,alpha);trailVertex(b,m,tail.add(far),0);
            trailVertex(b,m,tail.subtract(far),0);trailVertex(b,m,near.scale(-1),alpha);
        }
    }
    private static void trailVertex(BufferBuilder b, Matrix4f m, Vec3 p, float alpha) {
        b.vertex(m,(float)p.x,(float)p.y,(float)p.z).color(1f,0.73f,0.13f,alpha).endVertex();
    }
    private static void waveRibbon(BufferBuilder b,Matrix4f m,BladeVisuals.Visual v,double t) {
        double radius=Math.min(64,Math.max(0,t*BladeMath.SPEED));
        double inner=Math.max(0,radius-1.7);
        for(int i=0;i<120;i++) {
            double a=-Math.PI/2+i*Math.PI/120,c=a+Math.PI/120;
            Vec3 da=v.forward.scale(Math.cos(a)).add(v.side.scale(Math.sin(a)));
            Vec3 dc=v.forward.scale(Math.cos(c)).add(v.side.scale(Math.sin(c)));
            trailVertex(b,m,da.scale(radius),0.32f);trailVertex(b,m,dc.scale(radius),0.32f);
            trailVertex(b,m,dc.scale(inner),0.08f);trailVertex(b,m,da.scale(inner),0.08f);
        }
    }
    private static void dimWorld(float darkness) {
        if(darkness<=0) return;
        Matrix4f projection=new Matrix4f(RenderSystem.getProjectionMatrix());
        PoseStack model=RenderSystem.getModelViewStack(); model.pushPose(); model.setIdentity(); RenderSystem.applyModelViewMatrix();
        RenderSystem.setProjectionMatrix(new Matrix4f(),VertexSorting.ORTHOGRAPHIC_Z);
        RenderSystem.disableDepthTest(); RenderSystem.depthMask(false); RenderSystem.disableCull();
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder b=Tesselator.getInstance().getBuilder(); b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_COLOR);
        float alpha=darkness*0.60f;
        b.vertex(-1,-1,0).color(0.005f,0.006f,0.016f,alpha).endVertex();
        b.vertex(1,-1,0).color(0.005f,0.006f,0.016f,alpha).endVertex();
        b.vertex(1,1,0).color(0.005f,0.006f,0.016f,alpha).endVertex();
        b.vertex(-1,1,0).color(0.005f,0.006f,0.016f,alpha).endVertex();
        BufferUploader.drawWithShader(b.end());
        RenderSystem.setProjectionMatrix(projection,VertexSorting.DISTANCE_TO_ORIGIN);
        model.popPose(); RenderSystem.applyModelViewMatrix();
        RenderSystem.enableDepthTest(); RenderSystem.depthMask(true); RenderSystem.enableCull(); RenderSystem.disableBlend();
    }
}

