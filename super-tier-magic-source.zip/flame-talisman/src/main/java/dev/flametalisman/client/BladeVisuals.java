package dev.flametalisman.client;

import dev.flametalisman.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import java.util.*;

public final class BladeVisuals {
    static final Map<Integer, Visual> ACTIVE = new LinkedHashMap<>();
    private static ClientLevel lastLevel;
    private BladeVisuals() {}
    public static void add(SpellNetwork.BladeEffect packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (lastLevel != mc.level) { ACTIVE.clear(); lastLevel = mc.level; }
        if (packet.kind() == 4) { ACTIVE.remove(packet.id()); return; }
        if (packet.kind() == 3) ACTIVE.remove(packet.id());
        ACTIVE.put(packet.id(), new Visual(packet));
    }
    public static void tick(Minecraft mc) {
        if (mc.level != lastLevel) { ACTIVE.clear(); lastLevel = mc.level; }
        if (mc.level == null || mc.isPaused()) return;
        ACTIVE.values().removeIf(v -> v.tick(mc.level));
    }
    static float darkness(Vec3 camera, float partial) {
        float strength = 0;
        for (Visual v : ACTIVE.values()) {
            if (v.kind != 1) continue;
            double horizontal = Math.hypot(camera.x - v.origin.x, camera.z - v.origin.z);
            float distance = (float)Math.max(0, Math.min(1, (v.coverage+96-horizontal)/64));
            float age = v.age + partial;
            strength = Math.max(strength, distance * Math.min(1, age / 40) * Math.max(0, Math.min(1, (BladeMath.CHARGE+DurationMath.fireRain(v.enchantLevel)+DurationMath.SKY_FADE-age)/DurationMath.SKY_FADE)));
        }
        return strength;
    }
    static final class Visual {
        final int kind,enchantLevel;final float coverage;
        final Vec3 origin, forward, side, normal;
        Vec3 pos, previous;
        int age;
        Visual(SpellNetwork.BladeEffect packet) {
            coverage=packet.coverage();enchantLevel=packet.enchantLevel();kind = packet.kind(); origin = packet.origin(); pos = origin; previous = origin;
            forward = packet.direction().lengthSqr() > 0 ? packet.direction().normalize() : new Vec3(0, 0, 1);
            double yaw = Math.atan2(-forward.x, forward.z);
            Vec3 horizontalSide = new Vec3(Math.cos(yaw), 0, Math.sin(yaw));
            Vec3 up = forward.cross(horizontalSide).normalize();
            side = horizontalSide.scale(Math.cos(packet.roll())).add(up.scale(Math.sin(packet.roll())));
            normal = forward.cross(side).normalize();
            age = packet.age();
        }
        boolean tick(ClientLevel level) {
            previous = pos;
            Minecraft mc = Minecraft.getInstance();
            boolean nearby = mc.player != null && mc.player.distanceToSqr(pos) < 220 * 220;
            if (kind == 0 && nearby) wave(level);
            if (kind == 6 && age < BladeMath.DASH_TICKS) {
                pos = pos.add(forward.scale(BladeMath.DASH_SPEED));
                if(nearby) for(int i=0;i<16;i++) {
                    double f=level.random.nextDouble();
                    particle(level,previous.lerp(pos,f).add((level.random.nextDouble()-0.5)*0.7,level.random.nextDouble()*1.2,0),
                            forward.scale(-0.15).add(0,0.05,0));
                }
            }
            if (kind == 2) {
                pos = pos.add(0, -BladeMath.orbFall(age), 0);
                if (nearby) {
                    for (int i = 0; i < 12; i++) {
                        Vec3 along=previous.lerp(pos,i/12.0);
                        particle(level, along.add(0,0.4,0),new Vec3(0,0.1,0));
                    }
                }
            }
            if (kind == 3 && nearby) impact(level);
            if (kind == 1 && nearby && age % 3 == 0) {
                double radius = coverage * Math.min(1, age / 200.0);
                for (int i = 0; i < 10; i++) {
                    double a = age * 0.009 + i * Math.PI / 5;
                    particle(level, origin.add(Math.cos(a) * radius, 0, Math.sin(a) * radius), new Vec3(0, -0.01, 0));
                }
            }
            int end = switch (kind) { case 0 -> BladeMath.WAVE_TICKS; case 1 -> BladeMath.CHARGE+DurationMath.fireRain(enchantLevel)+DurationMath.SKY_FADE; case 2 -> 190; case 6 -> 12; default -> 25; };
            return ++age >= end;
        }
        void wave(ClientLevel level) {
            double radius = Math.min(64, (age + 1) * 4);
            for (int i = 0; i <= 180; i++) {
                double a = -Math.PI / 2 + Math.PI * i / 180;
                Vec3 direction = forward.scale(Math.cos(a)).add(side.scale(Math.sin(a)));
                for (int band = -1; band <= 1; band++) {
                    double r = Math.max(0, radius - 4 - level.random.nextDouble() * 1.2);
                    particle(level, origin.add(direction.scale(r)).add(normal.scale(band * 0.7)), direction.scale(1.0));
                }
            }
        }
        void impact(ClientLevel level) {
            if (age == 0) {
                for (int i = 0; i < 150; i++) {
                    double a = level.random.nextDouble() * Math.PI * 2;
                    double r = level.random.nextDouble() * 1.2;
                    particle(level, origin.add(Math.cos(a) * r, 0.2, Math.sin(a) * r),
                            new Vec3(Math.cos(a) * level.random.nextDouble() * 0.7, level.random.nextDouble() * 0.45, Math.sin(a) * level.random.nextDouble() * 0.7));
                }
            }
            if (age < 14) {
                double radius = age / 13.0 * 8;
                for (int i = 0; i < 36; i++) {
                    double a = i * Math.PI / 18;
                    particle(level, origin.add(Math.cos(a) * radius, 0.15, Math.sin(a) * radius), new Vec3(0, 0.02, 0));
                }
            }
        }
    }
    static void particle(ClientLevel level, Vec3 pos, Vec3 velocity) {
        level.addParticle(FlameTalisman.GOLD_FLAME.get(), true, pos.x, pos.y, pos.z, velocity.x, velocity.y, velocity.z);
    }
}


