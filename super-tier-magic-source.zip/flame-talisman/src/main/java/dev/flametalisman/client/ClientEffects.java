package dev.flametalisman.client;

import dev.flametalisman.FlameTalisman;
import dev.flametalisman.SpellGeometry;
import dev.flametalisman.SpellNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public final class ClientEffects {
    static final List<Visual> ACTIVE = new ArrayList<>();
    private static ClientLevel previousLevel;
    private ClientEffects() {}
    public static void add(SpellNetwork.Effect effect) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (previousLevel != mc.level) { ACTIVE.clear(); previousLevel = mc.level; }
        ACTIVE.add(new Visual(effect));
    }
    public static void tick(Minecraft mc) {
        if (previousLevel != mc.level) { ACTIVE.clear(); previousLevel = mc.level; }
        if (mc.level == null || mc.isPaused()) return;
        ACTIVE.removeIf(visual -> visual.tick(mc.level));
    }
    static final class Visual {
        final boolean rain;final int duration;
        final Vec3 origin;
        final float yaw;
        int age;
        Visual(SpellNetwork.Effect packet) {
            duration=packet.duration();rain = packet.rain(); origin = packet.origin(); yaw = packet.yaw(); age = packet.age();
        }
        boolean tick(ClientLevel level) {
            Minecraft mc = Minecraft.getInstance();
            boolean nearby = mc.player != null && mc.player.distanceToSqr(origin) < 128 * 128;
            if (nearby) {
                if (rain) rain(level); else wave(level);
            }
            return ++age >= duration;
        }
        void wave(ClientLevel level) {
            double radius = Math.min(SpellGeometry.WAVE_RANGE, (age + 1) * SpellGeometry.WAVE_SPEED);
            double base = Math.toRadians(yaw);
            // Constant angular spacing produces a dense, continuous 180 degree wavefront.
            for (int i = 0; i <= 110; i++) {
                double angle = base - Math.PI / 2 + Math.PI * i / 110;
                double dx = -Math.sin(angle), dz = Math.cos(angle);
                for (int layer = 0; layer < 3; layer++) {
                    double r = Math.max(0, radius - 2 - level.random.nextDouble() * 1.5);
                    particle(level, origin.x + dx * r, origin.y + layer * 0.65 + level.random.nextDouble() * 0.4,
                            origin.z + dz * r, dx * 0.55, 0.02, dz * 0.55);
                }
            }
        }
        void rain(ClientLevel level) {
            double radius = SpellGeometry.RAIN_RADIUS * (0.16 + 0.84 * Math.min(1, age / 80.0));
            for (int i = 0; i < 8; i++) {
                double a = level.random.nextDouble() * Math.PI * 2;
                particle(level, origin.x + Math.cos(a) * radius, origin.y + 0.06,
                        origin.z + Math.sin(a) * radius, 0, 0.04, 0);
            }
            if (age < SpellGeometry.CHARGE_TICKS) return;
            // 1,800 falling flames per second over the complete circular footprint.
            for (int i = 0; i < 90; i++) {
                double a = level.random.nextDouble() * Math.PI * 2;
                double r = Math.sqrt(level.random.nextDouble()) * SpellGeometry.RAIN_RADIUS;
                particle(level, origin.x + Math.cos(a) * r, origin.y + 14 + level.random.nextDouble() * 2,
                        origin.z + Math.sin(a) * r, 0, -1.35 - level.random.nextDouble() * 0.4, 0);
            }
            if ((age - SpellGeometry.CHARGE_TICKS) % 20 == 0) {
                for (int i = 0; i < 48; i++) {
                    double a = level.random.nextDouble() * Math.PI * 2;
                    double r = Math.sqrt(level.random.nextDouble()) * SpellGeometry.RAIN_RADIUS;
                    particle(level, origin.x + Math.cos(a) * r, origin.y + 0.12, origin.z + Math.sin(a) * r,
                            0, 0.18, 0);
                }
            }
        }
        private static void particle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            level.addParticle(FlameTalisman.GOLD_FLAME.get(), true, x, y, z, vx, vy, vz);
        }
    }
}
