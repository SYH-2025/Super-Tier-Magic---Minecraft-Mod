package dev.flametalisman.client;

import dev.flametalisman.FlameTalisman;
import dev.flametalisman.SpellNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {
    private static boolean attackHeld;
    private static boolean useHeld;
    private ClientEvents() {}
    @SubscribeEvent public static void input(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        var held=mc.player.getMainHandItem();
        boolean talisman = held.is(FlameTalisman.TALISMAN.get())||held.is(FlameTalisman.LIGHTNING_TALISMAN.get());
        boolean blade = held.is(FlameTalisman.BLADE.get())||held.is(FlameTalisman.THUNDER_BLADE.get())||held.is(FlameTalisman.SWORD_INTENT.get());
        boolean shard=held.is(FlameTalisman.LIGHTNING_SHARD.get());
        boolean air=held.is(FlameTalisman.AIR_TALISMAN.get());
        if (!talisman && !blade && !shard&&!air) return;
        if (!event.isAttack() && !event.isUseItem()) return;
        if (blade && event.isAttack() && !mc.player.isShiftKeyDown()) return;
        if (shard && event.isAttack())return;
        if(air&&event.isAttack()&&!mc.player.isShiftKeyDown())return;
        event.setCanceled(true);
        event.setSwingHand(false);
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (event.isAttack() && !attackHeld) {
            attackHeld = true;
            SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.Cast(false));
        } else if (event.isUseItem() && !useHeld) {
            useHeld = true;
            SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.Cast(true));
        }
    }
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (!mc.options.keyAttack.isDown()) attackHeld = false;
        if (!mc.options.keyUse.isDown()) useHeld = false;
        if (mc.level == null) { attackHeld = false; useHeld = false; }
        ClientEffects.tick(mc);
        BladeVisuals.tick(mc);
        BladeHandAnimation.tick(mc);
        ElectricVisuals.tick(mc);
        SwordVisuals.tick(mc);
    }
}
