package dev.flametalisman.client;

import dev.flametalisman.FlameTalisman;
import dev.flametalisman.SpellNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Opt-in development smoke test. This class is excluded from the release jar. */
@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID, value = Dist.CLIENT)
public final class ClientSmokeTest {
    private static boolean started;
    private static int ticks;
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if (!Boolean.getBoolean("flametalisman.smokeTest") || Boolean.getBoolean("flametalisman.bladeTest") || event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        mc.options.pauseOnLostFocus = false;
        if (!started && mc.screen instanceof TitleScreen) {
            started = true;
            mc.options.renderDistance().set(6);
            mc.options.simulationDistance().set(5);
            GameRules rules = new GameRules();
            rules.getRule(GameRules.RULE_DAYLIGHT).set(false, null);
            rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false, null);
            mc.createWorldOpenFlows().createFreshLevel("flame-smoke-" + System.currentTimeMillis(),
                    new LevelSettings("Flame Visual Test", GameType.CREATIVE, false, Difficulty.PEACEFUL,
                            true, rules, WorldDataConfiguration.DEFAULT),
                    new WorldOptions(42L, false, false), access -> access.registryOrThrow(Registries.WORLD_PRESET)
                            .getHolderOrThrow(WorldPresets.FLAT).value().createWorldDimensions());
        }
        if (mc.player == null || mc.level == null || mc.getSingleplayerServer() == null) return;
        ticks++;
        if (ticks == 40) {
            var server = mc.getSingleplayerServer();
            var id = mc.player.getUUID();
            server.execute(() -> {
                var p = server.getPlayerList().getPlayer(id);
                if (p == null) return;
                p.teleportTo(p.serverLevel(), 0.5, -52, -10, 0, 35);
                p.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(FlameTalisman.TALISMAN.get()));
                p.getAbilities().flying = true;
                p.onUpdateAbilities();
                p.serverLevel().setDayTime(14000);
            });
        }
        if (ticks == 80) {
            mc.player.setYRot(0); mc.player.setXRot(35);
            SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.Cast(true));
        }
        if (ticks == 188) {
            Screenshot.grab(mc.gameDirectory, "flame-rain-test.png", mc.getMainRenderTarget(),
                    msg -> System.out.println("FLAME_SMOKE_SCREENSHOT: " + msg.getString()));
            System.out.println("FLAME_SMOKE: rain visuals active=" + ClientEffects.ACTIVE.size());
        }
        if (ticks == 205) {
            mc.player.setXRot(10);
            SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.Cast(false));
        }
        if (ticks == 212) {
            Screenshot.grab(mc.gameDirectory, "flame-wave-test.png", mc.getMainRenderTarget(),
                    msg -> System.out.println("FLAME_SMOKE_SCREENSHOT: " + msg.getString()));
        }
        if (ticks == 255) {
            System.out.println("FLAME_SMOKE_SUCCESS");
            mc.stop();
        }
    }
}
