package dev.flametalisman.client;

import dev.flametalisman.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.*;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Included only in the temporary local-client visual test build. */
@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID, value = Dist.CLIENT)
public final class ClientSmokeTestBlade {
    private static boolean started;
    private static int ticks;
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if (!Boolean.getBoolean("flametalisman.bladeTest") || event.phase != TickEvent.Phase.END) return;
        Minecraft mc=Minecraft.getInstance();
        mc.options.pauseOnLostFocus=false;
        if(!started && mc.screen instanceof TitleScreen) {
            started=true;
            mc.options.renderDistance().set(8); mc.options.simulationDistance().set(5);
            GameRules rules=new GameRules(); rules.getRule(GameRules.RULE_DAYLIGHT).set(false,null);
            rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false,null);
            mc.createWorldOpenFlows().createFreshLevel("blade-test-"+System.currentTimeMillis(),
                new LevelSettings("Flame Blade Visual Test",GameType.CREATIVE,false,Difficulty.PEACEFUL,true,rules,WorldDataConfiguration.DEFAULT),
                new WorldOptions(42,false,false),access -> access.registryOrThrow(Registries.WORLD_PRESET)
                    .getHolderOrThrow(WorldPresets.FLAT).value().createWorldDimensions());
        }
        if(mc.player==null || mc.level==null || mc.getSingleplayerServer()==null) return;
        ticks++;
        if(ticks==30) {
            var server=mc.getSingleplayerServer(); var id=mc.player.getUUID();
            server.execute(() -> {
                var p=server.getPlayerList().getPlayer(id); if(p==null)return;
                p.teleportTo(p.serverLevel(),0.5,-60,0.5,0,-30);
                p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(FlameTalisman.BLADE.get()));
                p.setShiftKeyDown(true); p.serverLevel().setDayTime(6000);
            });
        }
        if(ticks==60) { mc.player.setYRot(0);mc.player.setXRot(-30);SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.Cast(false)); }
        if(ticks==67) shot(mc,"blade-tilted-wave.png");
        if(ticks==100) SpellNetwork.CHANNEL.sendToServer(new SpellNetwork.Cast(true));
        if(ticks==110) {
            var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
            server.execute(() -> { var p=server.getPlayerList().getPlayer(id);if(p!=null)p.teleportTo(p.serverLevel(),0.5,-60,-85,0,-25); });
        }
        if(ticks==170) shot(mc,"blade-charge.png");
        if(ticks==360) {
            shot(mc,"blade-sky-meteors.png");
            System.out.println("BLADE_VISUAL_COUNT="+BladeVisuals.ACTIVE.size());
        }
        if(ticks==415) shot(mc,"blade-meteor-impact.png");
        if(ticks==460) {
            var server=mc.getSingleplayerServer();var id=mc.player.getUUID();
            server.execute(() -> {var p=server.getPlayerList().getPlayer(id);if(p!=null)System.out.println("BLADE_TEST_HEALTH="+p.getHealth());});
        }
        if(ticks==490) { System.out.println("BLADE_LOCAL_SMOKE_SUCCESS");mc.stop(); }
    }
    private static void shot(Minecraft mc,String name) {
        Screenshot.grab(mc.gameDirectory,name,mc.getMainRenderTarget(),msg -> System.out.println("BLADE_SCREENSHOT="+msg.getString()));
    }
}
