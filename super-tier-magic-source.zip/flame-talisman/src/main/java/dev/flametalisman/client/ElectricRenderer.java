package dev.flametalisman.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.flametalisman.FlameTalisman;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import java.util.Random;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID,value=Dist.CLIENT)
public final class ElectricRenderer {
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||ElectricVisuals.ACTIVE.isEmpty())return;
        Vec3 camera=event.getCamera().getPosition();PoseStack poses=event.getPoseStack();
        RenderSystem.enableBlend();RenderSystem.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE);RenderSystem.disableCull();RenderSystem.depthMask(false);RenderSystem.setShader(net.minecraft.client.renderer.GameRenderer::getPositionColorShader);
        BufferBuilder b=Tesselator.getInstance().getBuilder();b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_COLOR);
        MagicCircleRenderer.color(0.32f,0.76f,1);
        try {
            for(ElectricVisuals.Visual v:ElectricVisuals.ACTIVE.values()) {
                Vec3 closest=v.pos;
                if(v.kind==8){
                    Vec3 axis=v.vector.subtract(v.origin);
                    double fraction=axis.lengthSqr()>0?Math.max(0,Math.min(1,camera.subtract(v.origin).dot(axis)/axis.lengthSqr())):0;
                    closest=v.origin.add(axis.scale(fraction));
                }
                if(closest.distanceToSqr(camera)>360*360)continue;
                double age=v.age+event.getPartialTick();
                double fade=Math.min(1,(v.end-age)/(v.kind==3?dev.flametalisman.DurationMath.SKY_FADE:Math.min(40,v.end)));
                Random random=new Random(v.id*341873128712L+(v.age/2)*132897987541L);
                if(v.kind==3) {
                    int sharp=Math.max(0,Math.min(5,(int)v.vector.x));
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y-camera.y,v.origin.z-camera.z);
                    BladeRenderer.circle(b,new Matrix4f(poses.last().pose()).scale(v.scale/16f),age,v.end);poses.popPose();
                    double r=v.scale*Math.min(1,age/200);
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y-camera.y,v.origin.z-camera.z);
                    SkySigilRenderer.render(b,poses.last().pose(),r,age,fade,sharp,1);poses.popPose();
                    if(sharp>0){poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y-camera.y,v.origin.z-camera.z);Matrix4f m=poses.last().pose();for(int layer=0;layer<sharp;layer++){double rr=r*(.15+layer*.105);MagicCircleRenderer.ring(b,m,rr,age*.02*(layer%2==0?1:-1),fade*.8);MagicCircleRenderer.polygon(b,m,8+layer*2,3,rr,age*.016*(layer%2==0?-1:1),fade*.65);}poses.popPose();}
                    int forks=12+sharp*4;
                    for(int i=0;i<forks;i++) {
                        double a=age*0.018+i*Math.PI*2/forks;
                        bolt(b,poses.last().pose(),v.origin.add(Math.cos(a)*r,0,Math.sin(a)*r),v.origin.add(Math.cos(a)*r*0.69,-2,Math.sin(a)*r*0.69),camera,random,0.8*fade,1);
                    }
                } else if(v.kind==0) {
                    Vec3 head=v.previous.lerp(v.pos,event.getPartialTick());
                    Vec3 tail=head.subtract(v.vector.normalize().scale(Math.min(12,age*4+2)));
                    bolt(b,poses.last().pose(),tail,head,camera,random,1,1);
                    Vec3 side=v.vector.cross(new Vec3(0,1,0)).normalize();
                    bolt(b,poses.last().pose(),tail.add(side.scale(0.2)),head,camera,random,0.65,0.7);
                } else if(v.kind==2) {
                    double r=Math.min(32,age*2);
                    Vec3 f=v.vector.normalize(),side=new Vec3(f.z,0,-f.x);
                    for(int i=0;i<48;i++) {
                        double a=-Math.PI/2+i*Math.PI/48,c=a+Math.PI/48;
                        Vec3 p=v.origin.add(f.scale(Math.cos(a)*r)).add(side.scale(Math.sin(a)*r));
                        Vec3 q=v.origin.add(f.scale(Math.cos(c)*r)).add(side.scale(Math.sin(c)*r));
                        bolt(b,poses.last().pose(),p,q,camera,random,0.9,0.8);
                        if(i%4==0)bolt(b,poses.last().pose(),p,p.subtract(f.scale(3)),camera,random,0.6,0.8);
                    }
                } else if(v.kind==8) {
                    bolt(b,poses.last().pose(),v.origin,v.vector,camera,random,fade,2.8);
                    for(int i=1;i<=5;i++) {
                        Vec3 fork=v.origin.lerp(v.vector,i/6.0);
                        bolt(b,poses.last().pose(),fork,fork.add((random.nextDouble()-0.5)*14,-8,(random.nextDouble()-0.5)*14),camera,random,fade*0.5,0.9);
                    }
                } else if(v.kind==5) {
                    bolt(b,poses.last().pose(),v.origin,v.vector,camera,random,fade*0.75,0.7);
                    Vec3 middle=v.origin.lerp(v.vector,0.5);
                    bolt(b,poses.last().pose(),middle,middle.add(1.3,-2,0.5),camera,random,fade*0.6,0.5);
                } else if(v.kind==6) {
                    double length=Math.min(v.scale,age*4);Vec3 f=v.vector.normalize(),side=new Vec3(f.z,0,-f.x);
                    for(int d=2;d<=length;d+=2) {
                        double width=9+Math.max(0,Math.min(1,(v.scale-72)/184.0));
                        double w=dev.flametalisman.ThunderManager.abyssWidth(d,v.scale,width),old=dev.flametalisman.ThunderManager.abyssWidth(d-2,v.scale,width);
                        for(int sign:new int[]{-1,1})bolt(b,poses.last().pose(),v.origin.add(f.scale(d-2)).add(side.scale(sign*old)),v.origin.add(f.scale(d)).add(side.scale(sign*w)),camera,random,fade*0.6,0.7);
                    }
                } else if(v.kind==4||v.kind==7) {
                    int count=v.kind==7?10:5;double radius=v.kind==7?1.4:0.55;
                    for(int i=0;i<count;i++) {
                        Vec3 p=v.pos.add((random.nextDouble()-0.5)*radius*2,(random.nextDouble()-0.5)*1.5,(random.nextDouble()-0.5)*radius*2);
                        Vec3 q=v.pos.add((random.nextDouble()-0.5)*radius*2,(random.nextDouble()-0.5)*1.5,(random.nextDouble()-0.5)*radius*2);
                        bolt(b,poses.last().pose(),p,q,camera,random,fade*0.75,0.6);
                    }
                } else if(v.kind==1) {
                    for(int i=0;i<18;i++) {
                        double a=i*Math.PI/9;
                        Vec3 end=v.origin.add(Math.cos(a)*v.scale,random.nextDouble()*1.7,Math.sin(a)*v.scale);
                        bolt(b,poses.last().pose(),v.origin,end,camera,random,fade,0.8);
                    }
                }
            }
            BufferUploader.drawWithShader(b.end());
        } finally {
            MagicCircleRenderer.color(1,0.76f,0.12f);RenderSystem.depthMask(true);RenderSystem.enableCull();RenderSystem.defaultBlendFunc();RenderSystem.disableBlend();
        }
    }
    private static void bolt(BufferBuilder b,Matrix4f m,Vec3 from,Vec3 to,Vec3 camera,Random random,double alpha,double thickness) {
        Vec3 axis=to.subtract(from);double length=axis.length();if(length<0.01||alpha<=0)return;
        Vec3 f=axis.normalize();Vec3 side=f.cross(Math.abs(f.y)>0.95?new Vec3(1,0,0):new Vec3(0,1,0)).normalize();Vec3 up=f.cross(side).normalize();
        int segments=Math.min(48,Math.max(3,(int)(length/1.2)));Vec3 last=from;
        for(int i=1;i<=segments;i++) {
            Vec3 next=from.lerp(to,i/(double)segments);
            if(i<segments)next=next.add(side.scale((random.nextDouble()-0.5)*Math.min(1.2,length*0.16))).add(up.scale((random.nextDouble()-0.5)*Math.min(1.2,length*0.16)));
            segment(b,m,last,next,camera,alpha,thickness);last=next;
        }
    }
    private static void segment(BufferBuilder b,Matrix4f m,Vec3 a,Vec3 c,Vec3 camera,double alpha,double thickness) {
        Vec3 across=c.subtract(a).cross(camera.subtract(a)).normalize();if(across.lengthSqr()<0.001)across=new Vec3(1,0,0);
        for(int layer=0;layer<2;layer++) {
            Vec3 width=across.scale((layer==0?0.055:0.014)*thickness);
            float opacity=(float)(alpha*(layer==0?0.22:0.95));
            vertex(b,m,a.add(width).subtract(camera),opacity,layer);vertex(b,m,c.add(width).subtract(camera),opacity,layer);
            vertex(b,m,c.subtract(width).subtract(camera),opacity,layer);vertex(b,m,a.subtract(width).subtract(camera),opacity,layer);
        }
    }
    private static void vertex(BufferBuilder b,Matrix4f m,Vec3 p,float alpha,int core){b.vertex(m,(float)p.x,(float)p.y,(float)p.z).color(core==0?0.3f:0.78f,core==0?0.62f:0.91f,1,alpha).endVertex();}
}
