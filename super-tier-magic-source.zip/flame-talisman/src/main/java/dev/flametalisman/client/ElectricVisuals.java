package dev.flametalisman.client;

import dev.flametalisman.SpellNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Geometry-only lightning effects: no particle substitutes. */
public final class ElectricVisuals {
    static final Map<Integer,Visual> ACTIVE=new LinkedHashMap<>();
    private static ClientLevel level;
    public static void add(SpellNetwork.ElectricEffect packet) {
        Minecraft mc=Minecraft.getInstance();if(mc.level==null)return;
        if(level!=mc.level){ACTIVE.clear();level=mc.level;}
        if(packet.kind()==9){ACTIVE.remove(packet.id());return;}
        ACTIVE.put(packet.id(),new Visual(packet));
    }
    public static void tick(Minecraft mc) {
        if(level!=mc.level){ACTIVE.clear();level=mc.level;}
        if(mc.level==null||mc.isPaused())return;
        ACTIVE.values().removeIf(v->{
            v.previous=v.pos;
            if(v.kind==0)v.pos=v.pos.add(v.vector);
            if(v.kind==4||v.kind==7) {
                var entity=mc.level.getEntity(v.entity);
                if(entity!=null){if(!entity.isAlive())return true;v.pos=entity.getBoundingBox().getCenter();}
            }
            return ++v.age>=v.end;
        });
    }
    static float darkness(Vec3 camera,float partial) {
        float amount=0;
        for(Visual v:ACTIVE.values())if(v.kind==3) {
            float distance=(float)Math.max(0,Math.min(1,(v.scale+96-Math.hypot(camera.x-v.origin.x,camera.z-v.origin.z))/64));
            float age=v.age+partial;
            amount=Math.max(amount,distance*Math.min(1,age/40)*Math.max(0,Math.min(1,(v.end-age)/(float)dev.flametalisman.DurationMath.SKY_FADE)));
        }
        return amount;
    }
    static final class Visual {
        final int kind,id,entity,end;final Vec3 origin,vector;final float scale;Vec3 pos,previous;int age;
        Visual(SpellNetwork.ElectricEffect p){kind=p.kind();id=p.id();entity=p.entityId();origin=p.origin();vector=p.vector();scale=p.scale();pos=previous=origin;age=kind==3&&entity<0?-entity:0;end=age+p.duration();}
    }
}
