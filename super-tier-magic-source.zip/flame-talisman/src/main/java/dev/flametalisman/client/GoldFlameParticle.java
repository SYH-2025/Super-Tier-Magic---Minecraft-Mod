package dev.flametalisman.client;

import dev.flametalisman.FlameTalisman;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class GoldFlameParticle extends TextureSheetParticle {
    private GoldFlameParticle(ClientLevel level, double x, double y, double z,
                              double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        xd = vx; yd = vy; zd = vz;
        rCol = 1.0f; gCol = 0.80f + random.nextFloat() * 0.17f; bCol = 0.08f;
        quadSize = 0.13f + random.nextFloat() * 0.15f;
        lifetime = vy < -1.1 ? 14 : (Math.hypot(vx, vz) > 0.1 || Math.abs(vy) > 0.75 ? 3 : 10 + random.nextInt(8));
        friction = 0.99f;
        gravity = 0;
        hasPhysics = true;
        pickSprite(sprites);
    }
    @Override public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }
    @Override protected int getLightColor(float partialTick) { return 0xF000F0; }
    @Override public void tick() {
        super.tick();
        alpha = Math.max(0, 1.0f - (float)age / lifetime);
        if (onGround) remove();
    }
    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }
        @Override public Particle createParticle(SimpleParticleType type, ClientLevel level,
                double x, double y, double z, double vx, double vy, double vz) {
            return new GoldFlameParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
    @Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        @SubscribeEvent public static void register(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(FlameTalisman.GOLD_FLAME.get(), Provider::new);
        }
    }
}
