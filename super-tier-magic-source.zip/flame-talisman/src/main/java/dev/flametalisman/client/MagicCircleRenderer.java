package dev.flametalisman.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import dev.flametalisman.FlameTalisman;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

@Mod.EventBusSubscriber(modid = FlameTalisman.MOD_ID, value = Dist.CLIENT)
public final class MagicCircleRenderer {
    private static float red=1,green=0.76f,blue=0.12f;
    static void color(float r,float g,float b){red=r;green=g;blue=b;}
    private MagicCircleRenderer() {}
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || ClientEffects.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Vec3 camera = event.getCamera().getPosition();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buffer = Tesselator.getInstance().getBuilder();
        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        PoseStack poses = event.getPoseStack();
        for (ClientEffects.Visual v : ClientEffects.ACTIVE) {
            if (!v.rain || v.origin.distanceToSqr(camera) > 128 * 128) continue;
            poses.pushPose();
            poses.translate(v.origin.x - camera.x, v.origin.y - camera.y, v.origin.z - camera.z);
            Matrix4f matrix = poses.last().pose();
            double t = v.age + event.getPartialTick();
            double growth = 0.16 + 0.84 * Math.min(1, t / 80);
            double radius = 8 * growth;
            double alpha = Math.min(1, (v.duration - t) / 12);
            double rotation = t * 0.013;
            ring(buffer, matrix, radius, rotation, alpha);
            ring(buffer, matrix, radius * 0.94, -rotation, alpha);
            ring(buffer, matrix, radius * 0.74, rotation, alpha);
            ring(buffer, matrix, radius * 0.67, -rotation, alpha);
            ring(buffer, matrix, radius * 0.22, rotation, alpha);
            polygon(buffer, matrix, 6, 2, radius * 0.65, rotation, alpha);
            polygon(buffer, matrix, 6, 1, radius * 0.65, rotation, alpha);
            polygon(buffer, matrix, 8, 3, radius * 0.36, -rotation * 1.6, alpha);
            for (int i = 0; i < 24; i++) {
                double a = -rotation * 0.8 + i * Math.PI / 12;
                double cx = Math.cos(a) * radius * 0.835;
                double cz = Math.sin(a) * radius * 0.835;
                double size = radius * 0.032;
                // Hand-designed rune strokes; different combinations around the outer ring.
                runeStroke(buffer, matrix, cx, cz, a, -size, -size, size, size, alpha);
                runeStroke(buffer, matrix, cx, cz, a, -size, size, size, -size, alpha);
                runeStroke(buffer, matrix, cx, cz, a, 0, -size * 1.6, 0, size * 1.6, alpha);
                if (i % 3 != 0) runeStroke(buffer, matrix, cx, cz, a, -size, 0, size, 0, alpha);
                if (i % 2 == 0) runeStroke(buffer, matrix, cx, cz, a, -size, -size, size, -size, alpha);
            }
            for (int i = 0; i < 12; i++) {
                double a = rotation + i * Math.PI / 6;
                line(buffer, matrix, Math.cos(a) * radius * 0.22, Math.sin(a) * radius * 0.22,
                        Math.cos(a) * radius * 0.29, Math.sin(a) * radius * 0.29, alpha);
            }
            poses.popPose();
        }
        BufferUploader.drawWithShader(buffer.end());
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }
    static void ring(BufferBuilder b, Matrix4f m, double r, double offset, double alpha) {
        for (int i = 0; i < 128; i++) {
            double a = offset + i * Math.PI / 64, c = a + Math.PI / 64;
            line(b, m, Math.cos(a) * r, Math.sin(a) * r, Math.cos(c) * r, Math.sin(c) * r, alpha);
        }
    }
    static void polygon(BufferBuilder b, Matrix4f m, int sides, int step, double r, double rotation, double alpha) {
        for (int i = 0; i < sides; i++) {
            double a = rotation + i * Math.PI * 2 / sides, c = rotation + (i + step) * Math.PI * 2 / sides;
            line(b, m, Math.cos(a) * r, Math.sin(a) * r, Math.cos(c) * r, Math.sin(c) * r, alpha);
        }
    }
    static void runeStroke(BufferBuilder b, Matrix4f m, double x, double z, double a,
                                   double x1, double z1, double x2, double z2, double alpha) {
        double c = Math.cos(a), s = Math.sin(a);
        line(b, m, x + c*x1 - s*z1, z + s*x1 + c*z1, x + c*x2 - s*z2, z + s*x2 + c*z2, alpha);
    }
    static void line(BufferBuilder b, Matrix4f m, double x1, double z1, double x2, double z2, double alpha) {
        double length = Math.hypot(x2 - x1, z2 - z1);
        if (length < 0.0001) return;
        quad(b, m, x1, z1, x2, z2, length, 0.085, alpha * 0.16, 0.004);
        quad(b, m, x1, z1, x2, z2, length, 0.022, alpha * 0.90, 0.006);
    }
    private static void quad(BufferBuilder b, Matrix4f m, double x1, double z1, double x2, double z2,
                             double length, double width, double alpha, double y) {
        double dx = -(z2-z1) / length * width, dz = (x2-x1) / length * width;
        vertex(b,m,x1+dx,y,z1+dz,alpha); vertex(b,m,x2+dx,y,z2+dz,alpha);
        vertex(b,m,x2-dx,y,z2-dz,alpha); vertex(b,m,x1-dx,y,z1-dz,alpha);
    }
    private static void vertex(BufferBuilder b, Matrix4f m, double x, double y, double z, double alpha) {
        b.vertex(m, (float)x, (float)y, (float)z).color(red,green,blue, (float)Math.max(0, alpha)).endVertex();
    }
}
