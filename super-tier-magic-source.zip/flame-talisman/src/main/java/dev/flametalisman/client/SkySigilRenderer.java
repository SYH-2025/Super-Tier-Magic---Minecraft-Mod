package dev.flametalisman.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import org.joml.Matrix4f;

/** Smaller counter-rotating seals suspended below each existing main sky sigil. */
final class SkySigilRenderer {
    static int layers(int rank){return 3+Math.max(0,Math.min(20,rank));}
    static double radiusScale(int layer,int count){return 1-.60*layer/(count-1.0);}
    static double drop(int layer,int count){return -(22+Math.max(0,count-8)*.8)*layer/(count-1.0);}
    static void render(BufferBuilder b,Matrix4f main,double radius,double time,double alpha,int rank,int theme){
        if(radius<.05||alpha<=0)return;
        int count=layers(rank);
        for(int layer=0;layer<count;layer++){
            double r=radius*radiusScale(layer,count),rotation=time*(layer%2==0?.009:-.012)+layer*.21;
            Matrix4f m=new Matrix4f(main).translate(0,(float)drop(layer,count),0);
            color(theme,layer%2==1);
            if(layer>0)seal(b,m,r,rotation,alpha*.85,theme);
            // Six independent orbiting seals accent the hexagonal corners of every tier.
            if(layer==0||count<=8||layer%3==0)for(int corner=0;corner<6;corner++){
                double a=rotation+corner*Math.PI/3;
                Matrix4f satellite=new Matrix4f(m).translate((float)(Math.cos(a)*r*.90),1.1f,(float)(Math.sin(a)*r*.90));
                color(theme,(corner+layer)%2==0);
                seal(b,satellite,r*.085,-rotation*2+corner*.3,alpha,theme);
            }
        }
        color(theme,false);
    }
    private static void color(int theme,boolean pale){
        if(theme==1)MagicCircleRenderer.color(pale?.78f:.34f,pale?.94f:.78f,1);
        else if(theme==2)MagicCircleRenderer.color(pale?.96f:1,pale?.98f:.92f,pale?1:.58f);
        else MagicCircleRenderer.color(1,pale?.92f:.78f,pale?.48f:.16f);
    }
    private static void seal(BufferBuilder b,Matrix4f m,double r,double rotation,double alpha,int theme){
        ring(b,m,r,rotation,alpha);
        ring(b,m,r*.93,-rotation,alpha*.85);
        ring(b,m,r*.63,rotation,alpha*.9);
        ring(b,m,r*.24,-rotation,alpha);
        MagicCircleRenderer.polygon(b,m,6,2,r*.80,rotation,alpha);
        MagicCircleRenderer.polygon(b,m,6,1,r*.80,rotation,alpha*.75);
        MagicCircleRenderer.polygon(b,m,8,3,r*.44,-rotation,alpha*.9);
        for(int i=0;i<12;i++){
            double a=-rotation+i*Math.PI/6,x=Math.cos(a)*r*.75,z=Math.sin(a)*r*.75,s=r*.018;
            MagicCircleRenderer.runeStroke(b,m,x,z,a,-s,-s,s,s,alpha);
            MagicCircleRenderer.runeStroke(b,m,x,z,a,-s,s,s,-s,alpha);
        }
        // Filled luminous petals distinguish the tiers without relying only on fine lines.
        for(int i=0;i<6;i++){
            double a=rotation+i*Math.PI/3;
            point(b,m,r*.12,a,alpha*.08,theme);point(b,m,r*.52,a-.14,alpha*.17,theme);
            point(b,m,r*.78,a,alpha*.03,theme);point(b,m,r*.52,a+.14,alpha*.17,theme);
        }
    }
    private static void ring(BufferBuilder b,Matrix4f m,double r,double rotation,double alpha){
        for(int i=0;i<48;i++){
            double a=rotation+i*Math.PI/24,c=a+Math.PI/24;
            MagicCircleRenderer.line(b,m,Math.cos(a)*r,Math.sin(a)*r,Math.cos(c)*r,Math.sin(c)*r,alpha);
        }
    }
    private static void point(BufferBuilder b,Matrix4f m,double r,double a,double alpha,int theme){
        b.vertex(m,(float)(Math.cos(a)*r),.015f,(float)(Math.sin(a)*r))
                .color(theme==1?.62f:1,theme==1?.88f:.92f,theme==0?.40f:theme==1?1:.72f,(float)alpha).endVertex();
    }
    private SkySigilRenderer(){}
}
