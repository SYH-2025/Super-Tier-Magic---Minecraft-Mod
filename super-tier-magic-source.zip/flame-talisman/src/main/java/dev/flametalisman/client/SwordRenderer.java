package dev.flametalisman.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.flametalisman.*;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID,value=Dist.CLIENT)
public final class SwordRenderer {
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||SwordVisuals.ACTIVE.isEmpty())return;
        Vec3 camera=event.getCamera().getPosition();PoseStack poses=event.getPoseStack();
        RenderSystem.enableBlend();RenderSystem.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE);RenderSystem.disableCull();RenderSystem.depthMask(false);RenderSystem.setShader(net.minecraft.client.renderer.GameRenderer::getPositionColorShader);
        BufferBuilder b=Tesselator.getInstance().getBuilder();b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_COLOR);
        try{
            for(SwordVisuals.Visual v:SwordVisuals.ACTIVE.values()){
                if(v.center.distanceToSqr(camera)>300*300)continue;double t=v.age+event.getPartialTick();double fade=Math.max(0,Math.min(1,(v.end-t)/(v.kind==1?(double)DurationMath.SKY_FADE:20.0)));
                if(v.kind==1){
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y+v.vector.y-camera.y,v.origin.z-camera.z);
                    circle(b,poses.last().pose(),v.coverage*Math.min(1,t/200),t,fade);SkySigilRenderer.render(b,poses.last().pose(),v.coverage*Math.min(1,t/200),t,fade,v.enchantLevel,2);if(v.enchantLevel>0)enhancedCircle(b,poses.last().pose(),v.coverage*Math.min(1,t/200),t,fade,v.enchantLevel);poses.popPose();
                    double tip=SwordMotion.swordTip(t,v.vector.y,v.enchantLevel);
                    if(t>=200&&t<200+DurationMath.fall(v.enchantLevel)){
                        for(int layer=0;layer<companionCount(v.enchantLevel);layer++){
                            poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y+tip+companionHeight(layer,v.enchantLevel)-camera.y,v.origin.z-camera.z);
                            circle(b,poses.last().pose(),companionRadius(layer,v.enchantLevel),t*(layer%2==0?2:-2),fade*Math.max(0,Math.min(1,(200+DurationMath.fall(v.enchantLevel)-t)/(DurationMath.fall(v.enchantLevel)*.6)))*.95);poses.popPose();
                        }
                        // Helical light ribbons join the travelling seal fragments along the blade.
                        for(int strand=0;strand<6+2*v.enchantLevel;strand++)for(int i=0;i<96;i++){
                            double step=SwordMotion.length(v.enchantLevel)*.88/96;
                            double a=t*.16+strand*Math.PI*2/(6+2*v.enchantLevel)+i*.17,c=a+.17,y=tip+SwordMotion.length(v.enchantLevel)*.08+i*step;
                            beam(b,poses.last().pose(),new Vec3(v.origin.x+Math.cos(a)*SwordMotion.width(v.enchantLevel)*.8,v.origin.y+y,v.origin.z+Math.sin(a)*SwordMotion.width(v.enchantLevel)*.8).subtract(camera),new Vec3(v.origin.x+Math.cos(c)*SwordMotion.width(v.enchantLevel)*.8,v.origin.y+y+step,v.origin.z+Math.sin(c)*SwordMotion.width(v.enchantLevel)*.8).subtract(camera),.17,fade*Math.max(0,Math.min(1,(200+DurationMath.fall(v.enchantLevel)-t)/(DurationMath.fall(v.enchantLevel)*.6)))*.95,strand%2==0);
                        }
                    }
                    BufferUploader.drawWithShader(b.end());
                    RenderSystem.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);RenderSystem.depthMask(true);
                    b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_COLOR);
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y+tip-camera.y,v.origin.z-camera.z);poses.mulPose(com.mojang.math.Axis.YP.rotationDegrees((float)(t*0.12)));
                    materialization=Math.max(0,Math.min(1.2,t/220));
                    double swordFade=fade*Math.max(0,Math.min(1,(200+DurationMath.fall(v.enchantLevel)-t)/(DurationMath.fall(v.enchantLevel)*.6)));
                    if(swordFade>0)sword(b,poses.last().pose(),SwordMotion.length(v.enchantLevel),SwordMotion.width(v.enchantLevel),swordFade,true,true);materialization=-1;poses.popPose();
                    BufferUploader.drawWithShader(b.end());RenderSystem.depthMask(false);RenderSystem.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE);
                    b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_COLOR);
                }else if(v.kind==2){
                    for(int i=0;i<SwordMotion.count(t,v.enchantLevel);i++){
                        var ghost=v.ghost(i,event.getPartialTick());Vec3 position=ghost.position().add(ghost.tangent().scale(ghost.size()*1.5));
                        poses.pushPose();poses.translate(position.x-camera.x,position.y-camera.y,position.z-camera.z);
                        poses.mulPose(new Quaternionf().rotationTo(new Vector3f(0,1,0),new Vector3f((float)-ghost.tangent().x,(float)-ghost.tangent().y,(float)-ghost.tangent().z)));
                        sword(b,poses.last().pose(),ghost.size()*3,ghost.size()*0.30,Math.min(1,fade*EnchantmentSpellMath.opacity(v.enchantLevel)*1.15),ghost.silver(),false);poses.popPose();
                    }
                }else if(v.kind==0){
                    Vec3 base=v.origin,f=v.vector,side=SwordMotion.waveSide(f,v.roll);double radius=Math.min(v.range,t*v.range/16.0);int segments=(v.blocked.length-1)*4;
                    for(int i=0;i<segments;i++){if(v.blocked[Math.min(v.blocked.length-1,i/4)])continue;double a=-Math.PI/2+i*Math.PI/segments,c=a+Math.PI/segments;Vec3 da=f.scale(Math.cos(a)).add(side.scale(Math.sin(a))),dc=f.scale(Math.cos(c)).add(side.scale(Math.sin(c)));
                        arcBand(b,poses.last().pose(),base,da,dc,radius,Math.max(0,radius-0.8),camera,false,.95);
                        arcBand(b,poses.last().pose(),base,da,dc,Math.max(0,radius-0.8),Math.max(0,radius-1.7),camera,true,1);
                    }
                }else if(v.kind==3||v.kind==5){
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y-camera.y,v.origin.z-camera.z);
                    MagicCircleRenderer.color(0.9f,0.92f,1);MagicCircleRenderer.ring(b,poses.last().pose(),t*(v.kind==3?v.scale/30:0.3),0,fade);
                    MagicCircleRenderer.color(1,0.84f,0.35f);MagicCircleRenderer.ring(b,poses.last().pose(),t*(v.kind==3?1.0:0.22),0,fade*0.75);poses.popPose();
                }
            }
            BufferUploader.drawWithShader(b.end());
            RenderSystem.setShader(net.minecraft.client.renderer.GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderTexture(0,new net.minecraft.resources.ResourceLocation(FlameTalisman.MOD_ID,"textures/effect/sword_calligraphy.png"));
            b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_TEX_COLOR);
            for(var v:SwordVisuals.ACTIVE.values())if(ArtifactConfig.INSCRIPTIONS.get()&&v.kind==1&&v.origin.distanceToSqr(camera)<300*300){
                double t=v.age+event.getPartialTick(),fade=Math.max(0,Math.min(1,(v.end-t)/(v.kind==1?(double)DurationMath.SKY_FADE:20.0)));
                poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y+v.vector.y+0.08-camera.y,v.origin.z-camera.z);
                inscriptions(b,poses.last().pose(),v.coverage*Math.min(1,t/200),t,fade,8,v.enchantLevel);poses.popPose();
                int tiers=SkySigilRenderer.layers(v.enchantLevel);
                for(int layer=1;layer<tiers;layer++){
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y+v.vector.y+SkySigilRenderer.drop(layer,tiers)+.08-camera.y,v.origin.z-camera.z);
                    inscriptions(b,poses.last().pose(),v.coverage*Math.min(1,t/200)*SkySigilRenderer.radiusScale(layer,tiers),t*(layer%2==0?1:-1),fade*.85,4,v.enchantLevel);poses.popPose();
                }
                if(t>=200&&t<200+DurationMath.fall(v.enchantLevel))for(int layer=0;layer<companionCount(v.enchantLevel);layer++){
                    poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y+SwordMotion.swordTip(t,v.vector.y,v.enchantLevel)+companionHeight(layer,v.enchantLevel)+0.08-camera.y,v.origin.z-camera.z);
                    inscriptions(b,poses.last().pose(),companionRadius(layer,v.enchantLevel),t*(layer%2==0?2:-2),fade*Math.max(0,Math.min(1,(200+DurationMath.fall(v.enchantLevel)-t)/(DurationMath.fall(v.enchantLevel)*.6)))*.95,4,v.enchantLevel);poses.popPose();
                }
            }
            BufferUploader.drawWithShader(b.end());
        }finally{materialization=-1;MagicCircleRenderer.color(1,0.76f,0.12f);RenderSystem.enableDepthTest();RenderSystem.depthMask(true);RenderSystem.enableCull();RenderSystem.defaultBlendFunc();RenderSystem.disableBlend();}
    }
    @SubscribeEvent public static void quake(ViewportEvent.ComputeCameraAngles event){
        double shake=0;Vec3 camera=event.getCamera().getPosition();
        for(var v:SwordVisuals.ACTIVE.values()){
            double distance=v.origin.distanceTo(camera),range=Math.max(0,1-distance/128);
            if(v.kind==1&&v.age>=200&&v.age<200+DurationMath.fall(v.enchantLevel))shake=Math.max(shake,range*(0.30+0.5*Math.min(1,(v.age-200)/(double)DurationMath.fall(v.enchantLevel))));
            if(v.kind==3)shake=Math.max(shake,range*Math.max(0,1-v.age/30.0));
        }
        if(shake>0){double time=net.minecraft.client.Minecraft.getInstance().level.getGameTime()+event.getPartialTick();event.setPitch(event.getPitch()+(float)(Math.sin(time*1.9)*shake*1.3));event.setYaw(event.getYaw()+(float)(Math.cos(time*2.4)*shake*0.6));}
    }
    private static int companionCount(int level){return 7+EnchantmentSpellMath.sharp(level);}
    private static double companionFraction(int layer,int level){return .08+.88*layer/(companionCount(level)-1.0);}
    private static double companionHeight(int layer,int level){return SwordMotion.length(level)*companionFraction(layer,level);}
    private static double companionRadius(int layer,int level){double f=companionFraction(layer,level);return SwordMotion.width(level)*(f>.70&&f<.84?2.1:.70+.12*Math.sin(f*Math.PI));}
    private static void circle(BufferBuilder b,Matrix4f m,double r,double t,double alpha){
        MagicCircleRenderer.color(1,.92f,.52f);MagicCircleRenderer.ring(b,m,r,t*0.013,alpha);MagicCircleRenderer.ring(b,m,r*0.90,-t*0.01,alpha);MagicCircleRenderer.polygon(b,m,8,3,r*0.78,t*0.009,alpha*0.75);
        MagicCircleRenderer.color(.96f,.98f,1);MagicCircleRenderer.ring(b,m,r*0.28,-t*0.011,alpha);MagicCircleRenderer.ring(b,m,r*0.34,t*0.02,alpha);
        for(double scale:new double[]{0.96,0.83,0.72,0.65,0.19})MagicCircleRenderer.ring(b,m,r*scale,t*0.007*(scale>0.7?1:-1),alpha*0.85);
        for(double scale:new double[]{1.0,0.96,0.72,0.34})MagicCircleRenderer.ring(b,m,r*(scale-0.006),t*0.007,alpha*0.80);
        doubleStar(b,m,12,5,r*0.68,-t*0.01,r*0.006,alpha*0.8);MagicCircleRenderer.polygon(b,m,6,2,r*0.82,t*0.009,alpha*0.8);
        for(int i=0;i<24;i++){double a=t*0.012+i*Math.PI/12,x=Math.cos(a)*r*0.865,z=Math.sin(a)*r*0.865,s=r*0.016;MagicCircleRenderer.runeStroke(b,m,x,z,a,-s,-s,s,s,alpha);MagicCircleRenderer.runeStroke(b,m,x,z,a,-s,s,s,-s,alpha);}
        // Broad translucent petals provide shape and contrast around the calligraphy.
        for(int i=0;i<8;i++){
            double a=-t*0.008+i*Math.PI/4;
            Vec3 inner=new Vec3(Math.cos(a)*r*0.12,0,Math.sin(a)*r*0.12),tip=new Vec3(Math.cos(a)*r*0.86,0,Math.sin(a)*r*0.86);
            Vec3 left=new Vec3(Math.cos(a-0.20)*r*0.55,0,Math.sin(a-0.20)*r*0.55),right=new Vec3(Math.cos(a+0.20)*r*0.55,0,Math.sin(a+0.20)*r*0.55);
            point(b,m,inner,alpha*0.04,i%2==0);point(b,m,left,alpha*0.17,i%2==0);point(b,m,tip,alpha*0.01,i%2==0);point(b,m,right,alpha*0.17,i%2==0);
        }
    }
    private static void enhancedCircle(BufferBuilder b,Matrix4f m,double r,double t,double alpha,int level){for(int layer=0;layer<level;layer++){double rr=r*(.11+layer*.13);MagicCircleRenderer.color(layer%2==0?.88f:1,layer%2==0?.95f:.82f,layer%2==0?1:.35f);MagicCircleRenderer.ring(b,m,rr,t*.012*(layer%2==0?1:-1),alpha*.85);doubleStar(b,m,8+layer*2,3,rr,-t*.01,r*.004,alpha*.65);}}
    private static void inscriptions(BufferBuilder b,Matrix4f m,double r,double t,double alpha,int count,int level){
        // The main sigil displays all 100 specified glyphs, with staggered radial placement.
        int[] bands=count==8?new int[]{12,16,20,24,28}:new int[]{8,12,16};
        int offset=0;
        for(int band=0;band<bands.length;band++){
            int total=bands[band]+(count==8?3:2)*level;
            for(int i=0;i<total;i++){
                int glyph=(offset+i)%100;
                double fraction=(band+.9)/(bands.length+1),jitter=.025*Math.sin(i*2.399+band);
                double a=t*(band%2==0?.010:-.014)+i*Math.PI*2/total+band*.43;
                double c=Math.cos(a),s=Math.sin(a),radius=r*(fraction+jitter),x=c*radius,z=s*radius;
                double size=r*Math.min(.105,Math.PI*2*fraction/total*.7);
                double[][]corners={{-1,-1},{1,-1},{1,1},{-1,1}};
                float u0=(glyph%16)/16f,u1=u0+1/16f,v0=(glyph/16)/8f,v1=v0+1/8f;
                for(int j=0;j<4;j++){double dx=corners[j][0]*size/2,dz=corners[j][1]*size/2;boolean silver=(i+band)%2==0;
                    b.vertex(m,(float)(x+c*dx-s*dz),0,(float)(z+s*dx+c*dz)).uv(j==0||j==3?u0:u1,j<2?v0:v1).color(silver?.96f:1,silver?.99f:.94f,silver?1:.58f,(float)alpha).endVertex();
                }
            }
            offset+=total;
        }
    }
    private static void doubleStar(BufferBuilder b,Matrix4f m,int sides,int step,double radius,double rotation,double gap,double alpha){
        for(int i=0;i<sides;i++){
            double a=rotation+i*Math.PI*2/sides,c=rotation+(i+step)*Math.PI*2/sides,x1=Math.cos(a)*radius,z1=Math.sin(a)*radius,x2=Math.cos(c)*radius,z2=Math.sin(c)*radius;
            double length=Math.hypot(x2-x1,z2-z1),dx=-(z2-z1)/length*gap/2,dz=(x2-x1)/length*gap/2;
            for(int sign:new int[]{-1,1})MagicCircleRenderer.line(b,m,x1+dx*sign,z1+dz*sign,x2+dx*sign,z2+dz*sign,alpha);
        }
    }
    private static void arcBand(BufferBuilder b,Matrix4f m,Vec3 origin,Vec3 a,Vec3 c,double outer,double inner,Vec3 camera,boolean silver,double alpha){
        point(b,m,origin.add(a.scale(outer)).subtract(camera),alpha,silver);point(b,m,origin.add(c.scale(outer)).subtract(camera),alpha,silver);point(b,m,origin.add(c.scale(inner)).subtract(camera),alpha*0.3,silver);point(b,m,origin.add(a.scale(inner)).subtract(camera),alpha*0.3,silver);
    }
    private static void sword(BufferBuilder b,Matrix4f m,double length,double width,double alpha,boolean silver,boolean mixed){
        swordLength=length;
        double z=width*0.22;
        double bladeEnd=mixed?0.76:0.82,guardEnd=mixed?0.80:0.85;
        for(int side:new int[]{-1,1})for(int face:new int[]{-1,1}){
            Vec3 tip=Vec3.ZERO,edge=new Vec3(side*width/2,length*0.16,0),ridge=new Vec3(0,length*0.16,face*z),topEdge=new Vec3(side*width/2,length*bladeEnd,0),topRidge=new Vec3(0,length*bladeEnd,face*z);
            boolean color=silver||(mixed&&side>0);float shade=face>0?(side>0?1:0.88f):(side>0?0.68f:0.76f);
            facet(b,m,tip,edge,ridge,tip,alpha,color,shade);
            facet(b,m,edge,topEdge,topRidge,ridge,alpha,color,shade);
        }
        facet(b,m,new Vec3(0,length*bladeEnd,z),new Vec3(-width/2,length*bladeEnd,0),new Vec3(0,length*bladeEnd,-z),new Vec3(width/2,length*bladeEnd,0),alpha,silver,0.9f);
        box(b,m,-width*1.9,width*1.9,length*(bladeEnd-0.02),length*guardEnd,z*0.9,alpha,mixed&&silver||!silver);
        box(b,m,-width*0.16,width*0.16,length*guardEnd,length*0.97,z*0.7,alpha,silver);
        box(b,m,-width*0.30,width*0.30,length*0.97,length,z,alpha,mixed&&silver||!silver);
    }
    private static void box(BufferBuilder b,Matrix4f m,double x1,double x2,double y1,double y2,double z,double alpha,boolean silver){
        Vec3 a=new Vec3(x1,y1,-z),c=new Vec3(x2,y1,-z),d=new Vec3(x2,y2,-z),e=new Vec3(x1,y2,-z),f=new Vec3(x1,y1,z),g=new Vec3(x2,y1,z),h=new Vec3(x2,y2,z),j=new Vec3(x1,y2,z);
        facet(b,m,f,g,h,j,alpha,silver,1);facet(b,m,c,a,e,d,alpha,silver,0.7f);facet(b,m,a,f,j,e,alpha,silver,0.8f);facet(b,m,g,c,d,h,alpha,silver,0.86f);facet(b,m,j,h,d,e,alpha,silver,0.95f);facet(b,m,a,c,g,f,alpha,silver,0.65f);
    }
    private static double materialization=-1,swordLength=1;
    private static void facet(BufferBuilder b,Matrix4f m,Vec3 a,Vec3 c,Vec3 d,Vec3 e,double alpha,boolean silver,float shade){for(Vec3 p:new Vec3[]{a,c,d,e}){double opacity=materialization<0?1:0.05+0.95*Math.max(0,Math.min(1,(materialization-(1-p.y/swordLength))/0.20));b.vertex(m,(float)p.x,(float)p.y,(float)p.z).color((silver?.96f:1)*(.5f+.5f*shade),(silver?.99f:.94f)*(.5f+.5f*shade),(silver?1:.58f)*(.5f+.5f*shade),(float)(alpha*opacity)).endVertex();}}
    private static void beam(BufferBuilder b,Matrix4f m,Vec3 a,Vec3 c,double width,double alpha,boolean silver){Vec3 perpendicular=c.subtract(a).cross(new Vec3(0,1,0)).normalize().scale(width);point(b,m,a.add(perpendicular),alpha,silver);point(b,m,c.add(perpendicular),alpha,silver);point(b,m,c.subtract(perpendicular),alpha,silver);point(b,m,a.subtract(perpendicular),alpha,silver);}
    private static void point(BufferBuilder b,Matrix4f m,Vec3 p,double alpha,boolean silver){b.vertex(m,(float)p.x,(float)p.y,(float)p.z).color(silver?.96f:1,silver?.99f:.94f,silver?1:.58f,(float)alpha).endVertex();}
}














