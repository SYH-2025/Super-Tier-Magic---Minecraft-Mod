package dev.flametalisman.client;

import dev.flametalisman.SpellNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import java.util.*;

public final class SwordVisuals {
    static final Map<Integer,Visual>ACTIVE=new LinkedHashMap<>();private static ClientLevel lastLevel;
    public static void add(SpellNetwork.SwordEffect p){var mc=Minecraft.getInstance();if(mc.level==null)return;if(lastLevel!=mc.level){ACTIVE.clear();lastLevel=mc.level;}if(p.kind()==9){ACTIVE.remove(p.id());return;}ACTIVE.put(p.id(),new Visual(p));}
    public static void swarm(SpellNetwork.SwordSwarm p){Visual v=ACTIVE.get(p.id());if(v==null||v.kind!=2)return;Vec3[]before=new Vec3[p.positions().length];for(int i=0;i<before.length;i++)before[i]=v.ghost(i,0).position();v.swarmBefore=before;v.swarmPositions=p.positions();v.swarmDirections=p.directions();v.swarmAge=0;}
    public static void tick(Minecraft mc){
        if(lastLevel!=mc.level){ACTIVE.clear();lastLevel=mc.level;}if(mc.level==null||mc.isPaused())return;
        ACTIVE.values().removeIf(v->{v.previous=v.center;
            v.swarmAge++;
            return ++v.age>=v.end;
        });
    }
    static float darkness(Vec3 camera,float partial){float strength=0;for(Visual v:ACTIVE.values())if(v.kind==1){float range=(float)Math.max(0,Math.min(1,(v.coverage+96-Math.hypot(camera.x-v.origin.x,camera.z-v.origin.z))/64));strength=Math.max(strength,range*Math.min(1,(v.age+partial)/40)*Math.max(0,Math.min(1,(v.end-v.age-partial)/(float)dev.flametalisman.DurationMath.SKY_FADE)));}return strength;}
    static final class Visual {
        final int kind,id,entity,end,enchantLevel,range;final Vec3 origin,vector;final float scale,roll,coverage;final boolean[]blocked;Vec3 center,previous;int age;
        Vec3[]swarmBefore,swarmPositions,swarmDirections;int swarmAge;
        dev.flametalisman.SwordMotion.Ghost ghost(int index,float partial){var orbit=dev.flametalisman.SwordMotion.ghost(index,age+partial,origin,enchantLevel,coverage);if(swarmPositions==null)return orbit;return new dev.flametalisman.SwordMotion.Ghost(swarmBefore[index].lerp(swarmPositions[index],Math.min(1,(swarmAge+partial)/2.0)),swarmDirections[index],orbit.size(),orbit.silver());}
        Visual(SpellNetwork.SwordEffect p){coverage=p.coverage();enchantLevel=p.enchantLevel();range=dev.flametalisman.EnchantmentSpellMath.range(enchantLevel);blocked=new boolean[dev.flametalisman.EnchantmentSpellMath.rays(enchantLevel)];kind=p.kind();id=p.id();entity=p.entityId();origin=p.origin();vector=p.vector();scale=p.scale();roll=p.roll();center=previous=origin;age=kind<=2?(int)scale:0;end=p.duration();}
    }
}








