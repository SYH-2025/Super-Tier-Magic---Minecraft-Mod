package dev.flametalisman.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import dev.flametalisman.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import java.util.*;

@Mod.EventBusSubscriber(modid=FlameTalisman.MOD_ID,value=Dist.CLIENT)
public final class WindRenderer {
    private static final Map<Integer,Visual>ACTIVE=new LinkedHashMap<>();private static ClientLevel lastLevel;
    public static void add(SpellNetwork.WindEffect p){var mc=Minecraft.getInstance();if(mc.level==null)return;if(lastLevel!=mc.level){ACTIVE.clear();lastLevel=mc.level;}if(p.kind()==9)ACTIVE.remove(p.id());else ACTIVE.put(p.id(),new Visual(p));}
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event){if(event.phase!=TickEvent.Phase.END)return;var mc=Minecraft.getInstance();if(lastLevel!=mc.level){ACTIVE.clear();lastLevel=mc.level;}if(mc.level==null||mc.isPaused())return;ACTIVE.values().removeIf(v->++v.age>=v.end);}
    @SubscribeEvent public static void render(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES||ACTIVE.isEmpty()&&!AirFlightClient.cloudVisible())return;
        Vec3 camera=event.getCamera().getPosition();var poses=event.getPoseStack();
        RenderSystem.enableBlend();RenderSystem.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE);RenderSystem.disableCull();RenderSystem.depthMask(false);RenderSystem.setShader(net.minecraft.client.renderer.GameRenderer::getPositionColorShader);
        BufferBuilder b=Tesselator.getInstance().getBuilder();b.begin(VertexFormat.Mode.QUADS,DefaultVertexFormat.POSITION_COLOR);
        try{for(Visual v:ACTIVE.values()){
            if(v.origin.distanceToSqr(camera)>300*300)continue;double t=v.age+event.getPartialTick(),fade=Math.min(1,(v.end-t)/8);
            poses.pushPose();poses.translate(v.origin.x-camera.x,v.origin.y-camera.y,v.origin.z-camera.z);Matrix4f m=poses.last().pose();
            if(v.kind==0){double r=68*AirGeometry.progress(t,8);for(int level=0;level<3;level++)ring(b,m,r,0.2+level*.7,t*.08,.18,fade*(1-level*.2));}
            else if(v.kind==1){
                double height=v.vector.y,growth=AirGeometry.progress(t,40),wide=64*(1-growth)+2.4;
                for(int layer=0;layer<15;layer++){double f=layer/14.0;ring(b,m,wide*(1-f)+1.7*f,height*f,t*.12+layer*.4,.12+f*.05,fade*.3);}
                for(int strand=0;strand<8;strand++)for(int i=0;i<80;i++){
                    double f=i/80.0,g=(i+1)/80.0,a=t*.20+strand*Math.PI/4+f*Math.PI*6,c=t*.20+strand*Math.PI/4+g*Math.PI*6;
                    double r=wide*(1-f)+1.6*f,rr=wide*(1-g)+1.6*g;
                    ribbon(b,m,new Vec3(Math.cos(a)*r,height*f,Math.sin(a)*r),new Vec3(Math.cos(c)*rr,height*g,Math.sin(c)*rr),.10,.45*fade);
                }
                double holdEnd=v.vector.x>0?v.vector.x:240;
                if(t>=holdEnd){double y=Math.max(0,height-(t-holdEnd+1)*16);ring(b,m,2.5,y,t*.2,.4,fade*.9);}
            }else if(v.kind==2){
                Vec3 forward=v.vector.normalize(),head=forward.scale(Math.min(48,t*4));double radius=AirGeometry.cloudRadius(t);
                sphere(b,m,head,radius,.10*fade);
                for(int puff=0;puff<9;puff++){double a=puff*2.3999632297+t*.07;Vec3 offset=new Vec3(Math.cos(a)*radius*.48,Math.sin(puff*1.7)*radius*.36,Math.sin(a)*radius*.48);sphere(b,m,head.add(offset),radius*(.38+.08*(puff%3)),.13*fade);}
                sphere(b,m,head.subtract(forward.scale(radius*.35)),radius*.72,.12*fade);
            }else if(v.kind==3){ring(b,m,t*.6,.06,t*.1,.28,fade);ring(b,m,t*.4,.1,-t*.1,.15,fade*.7);}
            poses.popPose();
        }if(AirFlightClient.cloudVisible()){var player=Minecraft.getInstance().player;Vec3 feet=player.getPosition(event.getPartialTick());poses.pushPose();poses.translate(feet.x-camera.x,feet.y-.22-camera.y,feet.z-camera.z);poses.scale(1,.35f,1);Matrix4f cloud=poses.last().pose();sphere(b,cloud,Vec3.ZERO,.95,.18);double t=player.tickCount+event.getPartialTick();for(int puff=0;puff<7;puff++){double a=puff*Math.PI*2/7+t*.015;Vec3 point=new Vec3(Math.cos(a)*.58,Math.sin(t*.04+puff)*.12,Math.sin(a)*.58);sphere(b,cloud,point,.45+.08*(puff%3),.16);}poses.popPose();}BufferUploader.drawWithShader(b.end());}finally{RenderSystem.depthMask(true);RenderSystem.enableCull();RenderSystem.defaultBlendFunc();RenderSystem.disableBlend();}
    }
    private static void ring(BufferBuilder b,Matrix4f m,double radius,double y,double offset,double width,double alpha){for(int i=0;i<96;i++){double a=offset+i*Math.PI/48,c=a+Math.PI/48;Vec3 p=new Vec3(Math.cos(a)*radius,y,Math.sin(a)*radius),q=new Vec3(Math.cos(c)*radius,y,Math.sin(c)*radius);band(b,m,p,q,new Vec3(Math.cos(a)*width,0,Math.sin(a)*width),alpha);}}
    private static void sphere(BufferBuilder b,Matrix4f m,Vec3 center,double r,double alpha){
        for(int layer=0;layer<8;layer++)for(int slice=0;slice<16;slice++){
            double p=-Math.PI/2+layer*Math.PI/8,q=p+Math.PI/8,a=slice*Math.PI/8,c=a+Math.PI/8;
            point(b,m,center.add(Math.cos(p)*Math.cos(a)*r,Math.sin(p)*r,Math.cos(p)*Math.sin(a)*r),alpha*.7);
            point(b,m,center.add(Math.cos(p)*Math.cos(c)*r,Math.sin(p)*r,Math.cos(p)*Math.sin(c)*r),alpha*.7);
            point(b,m,center.add(Math.cos(q)*Math.cos(c)*r,Math.sin(q)*r,Math.cos(q)*Math.sin(c)*r),alpha);
            point(b,m,center.add(Math.cos(q)*Math.cos(a)*r,Math.sin(q)*r,Math.cos(q)*Math.sin(a)*r),alpha);
        }
    }
    private static void ribbon(BufferBuilder b,Matrix4f m,Vec3 a,Vec3 c,double width,double alpha){Vec3 delta=c.subtract(a),side=delta.cross(new Vec3(0,1,0)).normalize().scale(width);if(side.lengthSqr()<1e-6)side=new Vec3(width,0,0);band(b,m,a,c,side,alpha);}
    private static void band(BufferBuilder b,Matrix4f m,Vec3 a,Vec3 c,Vec3 side,double alpha){point(b,m,a.add(side),alpha);point(b,m,c.add(side),alpha);point(b,m,c.subtract(side),alpha);point(b,m,a.subtract(side),alpha);}
    private static void point(BufferBuilder b,Matrix4f m,Vec3 p,double alpha){b.vertex(m,(float)p.x,(float)p.y,(float)p.z).color(.94f,.97f,1,(float)Math.max(0,alpha)).endVertex();}
    private static final class Visual{final int kind,end;final Vec3 origin,vector;final float roll;int age;Visual(SpellNetwork.WindEffect p){kind=p.kind();end=p.duration();origin=p.origin();vector=p.vector();roll=p.roll();age=p.age();}}
}



