$ErrorActionPreference = 'Stop'
$target = Join-Path $PSScriptRoot 'flame-talisman/src/main/resources/data/flametalisman/structures'
New-Item -ItemType Directory -Force -Path $target | Out-Null
$file = [System.IO.File]::Create((Join-Path $target 'empty.nbt'))
$gz = [System.IO.Compression.GZipStream]::new($file,[System.IO.Compression.CompressionMode]::Compress)
function NbtInt([int]$value) {
    $bytes = [BitConverter]::GetBytes($value)
    [Array]::Reverse($bytes)
    $gz.Write($bytes,0,4)
}
function NbtString([string]$value) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($value)
    $gz.WriteByte([byte]($bytes.Length -shr 8)); $gz.WriteByte([byte]($bytes.Length -band 255))
    $gz.Write($bytes,0,$bytes.Length)
}
function NbtTag([byte]$type,[string]$name) { $gz.WriteByte($type); NbtString $name }
NbtTag 10 ''
NbtTag 3 'DataVersion'; NbtInt 3465
NbtTag 9 'size'; $gz.WriteByte(3); NbtInt 3; NbtInt 16; NbtInt 12; NbtInt 16
NbtTag 9 'palette'; $gz.WriteByte(10); NbtInt 1
NbtTag 8 'Name'; NbtString 'minecraft:air'; $gz.WriteByte(0)
NbtTag 9 'blocks'; $gz.WriteByte(10); NbtInt 0
NbtTag 9 'entities'; $gz.WriteByte(10); NbtInt 0
$gz.WriteByte(0)
$gz.Dispose(); $file.Dispose()
