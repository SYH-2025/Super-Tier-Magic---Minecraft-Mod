$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$release = Join-Path $taskRoot 'release'
New-Item -ItemType Directory -Force -Path $release | Out-Null
$version = ((Get-Content -LiteralPath "$taskRoot/flame-talisman/gradle.properties" | Where-Object { $_ -match '^mod_version=' }) -split '=',2)[1]
$archiveBase = ((Get-Content -LiteralPath "$taskRoot/flame-talisman/gradle.properties" | Where-Object { $_ -match '^archive_base_name=' }) -split '=',2)[1]
if(-not $archiveBase) { $archiveBase='flametalisman' }
$jarName = "$archiveBase-$version.jar"
Copy-Item -LiteralPath "$taskRoot/flame-talisman/build/libs/$jarName" -Destination $release
if (-not (Test-Path -LiteralPath "$release/README.md")) { throw 'Missing release/README.md' }
if(Test-Path -LiteralPath "$taskRoot/downloads/talisman-preview.png") { Copy-Item -LiteralPath "$taskRoot/downloads/talisman-preview.png" -Destination $release }
Copy-Item -LiteralPath "$taskRoot/TEST-REPORT.md" -Destination $release
if(Test-Path -LiteralPath "$taskRoot/flame-talisman/run/screenshots") { Get-ChildItem -LiteralPath "$taskRoot/flame-talisman/run/screenshots" -Filter '*.png' | Copy-Item -Destination $release }
$zipPath = Join-Path $release "$archiveBase-source.zip"
$stream = [System.IO.File]::Create($zipPath)
$archive = [System.IO.Compression.ZipArchive]::new($stream,[System.IO.Compression.ZipArchiveMode]::Create)
try {
    $sourceRoot = Join-Path $taskRoot 'flame-talisman'
    $files = @('build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','LICENSE-MOD.txt','LICENSE.txt','.gitignore','.gitattributes')
    foreach ($relative in $files) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $sourceRoot $relative),"flame-talisman/$relative") | Out-Null
    }
    foreach ($folder in @('src','gradle','checks')) {
        foreach ($file in Get-ChildItem -LiteralPath (Join-Path $sourceRoot $folder) -File -Recurse) {
            $relative = $file.FullName.Substring($sourceRoot.Length+1).Replace('\','/')
            if ($relative -like 'src/main/java/com/example/*') { continue }
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,"flame-talisman/$relative") | Out-Null
        }
    }
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $release 'README.md'),'README.md') | Out-Null
    foreach ($relative in @('TEST-REPORT.md','build-mod.ps1','check-geometry.ps1','draw-textures.ps1','draw-blade.ps1','draw-lightning.ps1','draw-sword-intent.ps1','draw-sigil-script.ps1','draw-air-talisman.ps1','make-test-template.ps1','package-mod.ps1')) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $taskRoot $relative),$relative) | Out-Null
    }
} finally { $archive.Dispose(); $stream.Dispose() }
Get-FileHash -LiteralPath "$release/$jarName",$zipPath -Algorithm SHA256 |
    ForEach-Object { '{0}  {1}' -f $_.Hash,[System.IO.Path]::GetFileName($_.Path) } |
    Set-Content -LiteralPath (Join-Path $release 'SHA256.txt') -Encoding utf8
Write-Output "Release packaged: $release"
